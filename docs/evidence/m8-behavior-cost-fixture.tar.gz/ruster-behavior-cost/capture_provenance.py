from pathlib import Path
import datetime,hashlib,json,platform,subprocess
root=Path('/home/akilf/Projects/Ruster')
paths=[root/'crates/ruster-behavior/src/lib.rs',root/'crates/ruster-behavior/src/tests.rs',root/'crates/ruster-behavior/templates/follower.lua',root/'crates/ruster-behavior/Cargo.toml',root/'crates/ruster-scene/src/lib.rs',root/'crates/ruster-scene/src/authoring.rs',root/'crates/ruster-scene/src/strict_json.rs',root/'third_party/mlua/src/debug.rs',root/'docs/evidence/M8-behavior-cost-harness.rs',root/'Cargo.lock',Path('/tmp/ruster-behavior-cost/Cargo.lock')]
cpu=next((s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),None)
governor=Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor')
result={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.system()+' '+platform.release()+' '+platform.machine(),'cpu':cpu,'cpu0_governor':governor.read_text().strip() if governor.exists() else None,'rustc':subprocess.check_output(['/home/akilf/.cargo/bin/rustc','-Vv'],text=True),'cargo':subprocess.check_output(['/home/akilf/.cargo/bin/cargo','-V'],text=True).strip(),'sha256':{str(p.relative_to(root)) if p.is_relative_to(root) else str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'conditions':'Root granted sole Cargo/release sampling window; no other project Cargo or sampling. Desktop/user activity not isolated, no CPU pinning, no forced GC. One quiet production baseline matrix, no cross-engine/trial comparison.'}
print(json.dumps(result,indent=2))

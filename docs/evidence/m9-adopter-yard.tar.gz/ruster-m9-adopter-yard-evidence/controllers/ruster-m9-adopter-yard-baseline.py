from ruster_m9_adopter_support import run
run('02-yard-baseline', '''set -eu
cd /work/m9-adopter-yard
cargo run --locked --offline -p ruster-yard -- --headless --resources examples/yard-app/resources
''')

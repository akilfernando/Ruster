import pathlib,json,hashlib,sys
base=pathlib.Path('/HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs/work/m9-adopter-yard')
m=json.loads((base/'source-manifest.json').read_text()); entries={x['path']:x for x in m['files']}
actual={p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}
missing=set(entries)-actual; extra=actual-set(entries)-{'source-manifest.json'}
bad=[]
for rel,e in entries.items():
 p=base/rel
 if not p.is_file() or p.is_symlink() or p.stat().st_size!=e['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']: bad.append(rel)
forbidden=[p for p in actual if any(t in pathlib.PurePosixPath(p).parts for t in ['.git','.env','target','ruster-editor','ruster-mcp','ruster-viewer','ruster-cli'])]
resources=sorted(p for p in actual if '/resources/' in p)
result=dict(application=m['application'],files=len(entries),missing=sorted(missing),extra=sorted(extra),hash_failures=bad,forbidden=forbidden,resources=resources)
assert not (missing or extra or bad or forbidden)
assert resources==['examples/yard-app/resources/truck.obj']
assert (base/'third_party/wgpu-hal/RUSTER-PATCH.md').is_file()
assert (base/'LICENSE-MIT').is_file() and (base/'LICENSE-APACHE').is_file()
pathlib.Path('/tmp/ruster-m9-adopter-results/yard-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

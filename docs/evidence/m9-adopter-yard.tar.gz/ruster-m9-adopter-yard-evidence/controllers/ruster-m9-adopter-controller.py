import json,pathlib,subprocess,time,sys,hashlib
OUT=pathlib.Path('/tmp/ruster-m9-adopter-results'); OUT.mkdir(exist_ok=True)
ROOT=pathlib.Path('/HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs')
SRC='/HOST_HOME/.local/state/ruster-candidates/m9-eval-1/adopter-extraction/ruster-m9-eval-1'
BASE=['bwrap','--unshare-user','--uid','1000','--gid','1000','--unshare-pid','--unshare-uts','--unshare-net','--bind',str(ROOT),'/', '--ro-bind','/HOST_HOME/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu','/opt/rust-toolchain','--ro-bind','/HOST_HOME/.cargo/registry','/opt/cargo-registry','--ro-bind',SRC,'/work/source','--dev','/dev','--proc','/proc','--clearenv','--setenv','PATH','/opt/rust-toolchain/bin:/usr/sbin:/usr/bin:/sbin:/bin','--setenv','HOME','/work/home','--setenv','CARGO_HOME','/work/cargo','--setenv','CARGO_TARGET_DIR','/work/target','--setenv','CARGO_NET_OFFLINE','true','--setenv','CARGO_BUILD_JOBS','4','--setenv','LC_ALL','C.UTF-8','--cap-drop','ALL','--chdir','/work/source','--die-with-parent']
def run(name,script,base=BASE):
    (OUT/(name+'.sh')).write_text(script)
    argv=base+['/bin/sh','-c',script]
    start=time.monotonic()
    with (OUT/(name+'.log')).open('w') as log:
        proc=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
    result={'name':name,'argv':argv,'script_sha256':hashlib.sha256(script.encode()).hexdigest(),'exit':proc.returncode,'seconds':time.monotonic()-start,'log':str(OUT/(name+'.log'))}
    (OUT/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    print((OUT/(name+'.log')).read_text()[-7000:],flush=True)
    if proc.returncode: sys.exit(proc.returncode)
if __name__=='__main__':
    run('01-export-baselines', '''set -eu
python3 scripts/new_app.py /work/m9-adopter-yard
python3 scripts/new_app.py --app motion-lab /work/m9-adopter-motion
cd /work/m9-adopter-yard
cargo run --locked --offline -p ruster-yard -- --headless --resources examples/yard-app/resources
cd /work/m9-adopter-motion
cargo run --locked --offline -p ruster-motion-lab -- --generic-demo --headless --ticks 10
cargo run --locked --offline -p ruster-motion-lab -- --scene examples/motion-lab/resources/generic.scene.json --headless --ticks 10
''')

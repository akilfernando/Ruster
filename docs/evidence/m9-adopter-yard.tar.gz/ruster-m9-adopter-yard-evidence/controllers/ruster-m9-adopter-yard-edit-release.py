from ruster_m9_adopter_support import run
run('03-yard-app-edit-and-run', '''set -eu
cd /work/m9-adopter-yard
python3 - <<'EDIT'
from pathlib import Path
p=Path('examples/yard-app/src/lib.rs')
s=p.read_text()
assert s.count('            capacity: 2,')==1
p.write_text(s.replace('            capacity: 2,','            capacity: 3,',1))
EDIT
cargo run --locked --offline -p ruster-yard -- --headless --resources examples/yard-app/resources
''')
run('04-yard-remapped-release-package', '''set -eu
cd /work/m9-adopter-yard
RUSTFLAGS="--remap-path-prefix=$PWD=/ruster-source --remap-path-prefix=$HOME=/ruster-build -C debuginfo=0" cargo build --locked --offline --release -p ruster-yard
python3 scripts/package_app.py --binary /work/target/release/ruster-yard --output /work/m9-adopter-yard-linux-x86_64.tar.gz
sha256sum /work/target/release/ruster-yard /work/m9-adopter-yard-linux-x86_64.tar.gz
''')

import json,pathlib,hashlib,difflib,tarfile,subprocess
OUT=pathlib.Path('/tmp/ruster-m9-adopter-results')
ROOT=pathlib.Path('/HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs')
BASE=ROOT/'work/m9-adopter-yard'
manifest=json.loads((BASE/'source-manifest.json').read_text())
changed=[]; missing=[]
for entry in manifest['files']:
 p=BASE/entry['path']
 if not p.is_file(): missing.append(entry['path'])
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=entry['sha256']: changed.append(entry['path'])
assert not missing and changed==['examples/yard-app/src/lib.rs'], (missing,changed)
known={e['path'] for e in manifest['files']}|{'source-manifest.json'}
extra={p.relative_to(BASE).as_posix() for p in BASE.rglob('*') if p.is_file()}-known
legit=sorted(p for p in extra if p.startswith('scripts/__pycache__/') and p.endswith('.pyc'))
assert set(legit)==extra,extra
src=pathlib.Path('/HOST_HOME/.local/state/ruster-candidates/m9-eval-1/adopter-extraction/ruster-m9-eval-1')
old=(src/changed[0]).read_text();new=(BASE/changed[0]).read_text()
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=changed[0]+'.original',tofile=changed[0]+'.authored'))
assert '-            capacity: 2,\n+            capacity: 3,' in diff
(OUT/'yard-app-only.diff').write_text(diff)
source_audit={'changed_source_files':changed,'missing':missing,'legitimate_generated_artifacts':legit,'source_manifest_sha256':hashlib.sha256((BASE/'source-manifest.json').read_bytes()).hexdigest(),'application_source_sha256':hashlib.sha256((BASE/changed[0]).read_bytes()).hexdigest()}
(OUT/'yard-app-only-audit.json').write_text(json.dumps(source_audit,indent=2)+'\n')
archive=ROOT/'work/m9-adopter-yard-linux-x86_64.tar.gz'
with tarfile.open(archive) as tf:
 members=tf.getmembers()
 assert all(m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts and m.name.startswith('ruster-yard/') for m in members)
 payload={m.name[len('ruster-yard/'):]:tf.extractfile(m).read() for m in members}
manifest=json.loads(payload['manifest.json'])
assert manifest['application']=='ruster-yard'
assert manifest['target']=='x86_64-unknown-linux-gnu'
for ent in manifest['files']:
 data=payload[ent['path']]
 assert len(data)==ent['bytes'] and hashlib.sha256(data).hexdigest()==ent['sha256']
assert set(payload)=={e['path'] for e in manifest['files']}|{'manifest.json'}
assert sorted(p for p in payload if p.startswith('resources/'))==['resources/truck.obj']
assert all(x in payload for x in ['LICENSE-MIT','LICENSE-APACHE','THIRD_PARTY_NOTICES.txt','SUPPLEMENTAL_NOTICES.txt','ruster-yard','README.txt'])
assert len(manifest['dependencies'])>0
for name,data in payload.items():
 for prefix in [b'/work/m9-adopter-yard',b'/work/home',b'/HOST_HOME']:
  assert prefix not in data,(name,prefix)
result={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'binary_sha256':hashlib.sha256(payload['ruster-yard']).hexdigest(),'binary_bytes':len(payload['ruster-yard']),'application':manifest['application'],'target':manifest['target'],'payload_files':sorted(payload),'dependencies':len(manifest['dependencies']),'elf':manifest.get('elf'),'regular_safe_members':len(members),'all_payload_hashes_valid':True,'current_source_home_prefix_absent':True}
(OUT/'yard-package-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(source_audit));print(json.dumps(result))

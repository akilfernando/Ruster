from ruster_m9_adopter_support import run, ROOT
run('05-yard-extract', '''set -eu
mkdir /work/m9-adopter-relocated-yard
tar -xzf /work/m9-adopter-yard-linux-x86_64.tar.gz -C /work/m9-adopter-relocated-yard
''')
base=['bwrap','--unshare-user','--uid','1000','--gid','1000','--unshare-pid','--unshare-uts','--unshare-net','--unshare-ipc','--ro-bind',str(ROOT),'/', '--tmpfs','/work','--tmpfs','/tmp','--ro-bind',str(ROOT/'work/m9-adopter-relocated-yard/ruster-yard'),'/app','--dev','/dev','--proc','/proc','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp/m9-adopter-runtime-home','--setenv','LC_ALL','C.UTF-8','--cap-drop','ALL','--chdir','/tmp','--die-with-parent']
run('06-yard-isolated-runtime', '''set -eu
test ! -e /work/source
test ! -e /work/m9-adopter-yard
test ! -e /work/target
test ! -e /opt/rust-toolchain
test ! -e /opt/cargo-registry
test -z "${DISPLAY-}${WAYLAND_DISPLAY-}${XDG_RUNTIME_DIR-}"
id
/app/ruster-yard --headless
/app/ruster-yard --headless --capacity 2
sha256sum /app/ruster-yard /app/resources/truck.obj
''', base=base)

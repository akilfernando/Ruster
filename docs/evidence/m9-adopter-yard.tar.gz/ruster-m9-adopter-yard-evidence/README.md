# Yard partial agent adopter evidence

Frozen m9-eval-1 source5247d2ac1703a9a3de2a18aedc7865d21a3e7668. Product instructions: candidate Quickstart, distribution guide, both app guides and generated Yard README. Parent supplied private Ubuntu24.04.5 userspace, Rust1.99.1, cached readonly registry and existing target, disclosed checker/.git defect, and granted serialized Cargo max4jobs. Immutable source defects received no workaround.

Yard export passed142-file inventory/hash/allowlist checks. Baseline tick10 delivered20 capacity2; guide's only app-owned edit capacity2 to3 rebuilt to tick8 delivered24. App-only diff/audit preserves the exact line and a legitimate generated pycache exclusion. No engine/vendor/exporter edit.

Documented Rust remapping and explicit --binary packaging passed, including selected248-version readable-notice gate.9 safe regular relative package members with matching hashes; app identity ruster-yard, target x86_64-unknown-linux-gnu. Source inventory, full package manifest and selected dependency versions are metadata only. Actual executable/package/source files are omitted. ARTIFACT-HASHES.json identifies originals.

Final runtime08 RO-binds private rootfs and relocated package, hides entire /work and /opt using tmpfs, clears environment, unshares network/PID/UTS/IPC, drops all capabilities, uses uid1000 and unrelated /tmp cwd. No host toolchain/registry/source/socket binds; no display environment. Guards assert source/export/target/toolchain/registry absent. Default packaged run: tick8 delivered24 capacity3. Override2: tick10 delivered20 capacity2. All extracted payload hashes/file set unchanged afterward; no cache created. Harness06/07 failed before app and remain preserved separately.

Wall times: baseline build/run50.8135s; app edit/build/run3.2064s; remapped release/package213.2240s combined (Cargo reported3m26s cold remapped optimized build); extraction0.2853s; final preflight/two headless runs/hashes0.0667s. These durations are not performance comparisons. Records contain exact unrounded timings, argv, scripts and logs.

Motion export failed on missing third_party/mlua/Cargo.lock in frozen candidate; no Motion build/edit/package. Known checker/.git defect belongs to parent. No new Cargo/app runs during curation; immutable source untouched. This is partial agent headless evidence with supplied cached prerequisites, not fresh-machine registry/toolchain onboarding, external-human/fullUI/GPU acceptance, another-machine support or public distribution/legal clearance. See records/HANDOFF.md and SANITIZATION.md.

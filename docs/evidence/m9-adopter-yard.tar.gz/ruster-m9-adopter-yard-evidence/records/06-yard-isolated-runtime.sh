set -eu
test ! -e /work/source
test ! -e /work/m9-adopter-yard
test ! -e /work/target
test ! -e /opt/rust-toolchain
test ! -e /opt/cargo-registry
test -z "${DISPLAY-}${WAYLAND_DISPLAY-}${XDG_RUNTIME_DIR-}"
id
/app/ruster-yard --headless
/app/ruster-yard --headless --capacity 2
sha256sum /app/ruster-yard /app/resources/truck.obj

# m9-eval-1 partial agent adopter: export/app/package leg

Frozen source 5247d2ac1703a9a3de2a18aedc7865d21a3e7668; source archive SHA256 4dd44eded71e0f85cf2079f50c89c5fbd78e3e061c27ea381bafe29a1a7dedb6 independently matched manifest. Immutable candidate/archive untouched. No repository docs or commits changed by this worker.

## Outcome

Yard passed independent source export, baseline headless, application-owned edit/rebuild, remapped optimized build/package, relocated headless with original source/export/build/cache/toolchain unavailable, and payload integrity audits. Motion Lab is blocked at documented source export (missing third_party/mlua/Cargo.lock); its build/edit/package not attempted. Known archive checker/.git blocker is outside this leg and owned by root. This is a partial agent rehearsal, not independent external-human/fullUI acceptance.

Product instructions: frozen README Quickstart; docs/DISTRIBUTION.md; both example guides; generated Yard README. Root supplied sandbox environment and disclosed checker blocker (coaching). No workaround for either candidate defect.

## Exact commands and timings

Numbered .json files contain full namespace argv, shell scripts, script SHA256, exit, monotonic wallseconds and log path; matching .sh/.log files preserve execution. Commands are serial, max4 Cargojobs, no network, no host HOME/Cargo config/credentials mounts.

- 01-export-baselines: Yard export created142 sourcefiles, then Motion export failed exit2 missing /work/source/third_party/mlua/Cargo.lock, 0.7834s. Baselines in this grouped script did not execute due set-e.
- 02-yard-baseline: cargo run --locked --offline -p ruster-yard -- --headless --resources examples/yard-app/resources; 50.8135s using existing target/registry; missedtarget tick10 delivered20 capacity2.
- 03-yard-app-edit-and-run: guide's one-line Settings::default capacity2→3, same headless command; 3.2064s; success tick8 delivered24 capacity3.
- 04-yard-remapped-release-package: exact documented Rust remap flags; cargo build --locked --offline --release -p ruster-yard; package helper with explicit --binary /work/target/release/ruster-yard and own fresh archive output; 213.2240s combined wall. Cargo reported3m26s optimized build. This is cold remapped release/dependency work in an existing target/registry environment, not a performance comparison; individual packaging walltime not separately instrumented.
- 05: fresh archive extraction 0.2853s.
- 06/07: namespace harness preflight failures before application execution: /app absent on ROroot; then directory-existence assertions rejected empty preexisting /opt mountpointdirs. Preserved as harness failures. Actual package not implicated.
- 08: corrected stronger namespace hides entire /work and /opt with tmpfs, ROroot/package, package mounted at existing /mnt, cwd/tmp, no display env or network. Assertions prove source/export/target/toolchain/cache absent. Default packaged run success tick8 delivered24 capacity3; --capacity2 misses tick10 delivered20. Stage0.0667s includes preflight/twoheadlessruns/hashcapture; not a benchmark.

## Artifact identities/audits

Private Ubuntu base rootfs: /HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs
Editable Yard export: rootfs/work/m9-adopter-yard
Package: rootfs/work/m9-adopter-yard-linux-x86_64.tar.gz
Relocated package: rootfs/work/m9-adopter-relocated-yard/ruster-yard

Final release binary SHA256 2846f3fd770896c175bcecef786167ad3fa0293befd018b364072265bc396edf (26,170,200bytes).
Package SHA256 b711b9c4fd88a72e554c8deee2cfab394cfb9fbad2f2b461744aea6a6d2a6488 (8,535,360bytes).
Changed application source SHA256 60fe484cb7ef6a12c8e829dab1d62a68fe187d37eec298c16a75c93c34dac0e6.
Original source-manifest SHA256 ce6f2ebb242375bff70943c7c297342a2fbbc374931fbba7039910ea015e1035.
Edited debug binary identity also captured separately; baseline binary hash was not captured before replacement.

All142 initial export hashes/lengths matched, no extra/forbidden files, sole truck.obj resource, HAL provenance/licenses present. After iteration, only examples/yard-app/src/lib.rs differs from source-manifest; one generated Python pycache excluded explicitly. See yard-app-only.diff/audit.
Package has9 regular safe relative members: executable, truck.obj, README, two original licenses, fullworkspace notices, supplemental selected notices, licenseprovenance, manifest. All payload hashes/lengths match, app/target identity ruster-yard/x86_64-unknown-linux-gnu;248 selected externaldependencyversions. Packager readability coverage check succeeded. No current exported source/home/hosthome prefix in any payload. ELFmanifest lists interpreter /lib64/ld-linux-x86-64.so.2 and required ld-linux/libc/libgcc_s/libm, references through GLIBC2.39 (not asserted as hard nonweak minimum). All extracted payload hashes and file set unchanged after isolated runs; no cache written.

## Limits/prerequisites

Private Ubuntu24.04.5 userspace shares hostkernel; no nativeGUI/GPU or another-machine acceptance, no fresh-registry/toolchain-install path, no publicdistribution/legalclearance assertion. Parent prepared prerequisites; readonly hostregistry and Rust1.99.1 supplied; existing private target reused. Offline export requires cached pinned dependencies as documented. Shared CARGO_TARGET_DIR needs supported --binary explicit path because packager default is exportlocal target/release. No engine/vendor/exporter edits or original source/archive mutations; no suite replay, clipboard/focus/window actions, network, install, email/push/publication.

Next: root corrected candidate eval2 for Motion, preserving eval1 failure. Cargo writer slot released after04 and no later Cargo commands.

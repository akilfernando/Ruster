set -eu
cd /work/m9-adopter-yard
python3 - <<'EDIT'
from pathlib import Path
p=Path('examples/yard-app/src/lib.rs')
s=p.read_text()
assert s.count('            capacity: 2,')==1
p.write_text(s.replace('            capacity: 2,','            capacity: 3,',1))
EDIT
cargo run --locked --offline -p ruster-yard -- --headless --resources examples/yard-app/resources

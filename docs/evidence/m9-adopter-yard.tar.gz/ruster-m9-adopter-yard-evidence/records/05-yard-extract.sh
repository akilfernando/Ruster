set -eu
mkdir /work/m9-adopter-relocated-yard
tar -xzf /work/m9-adopter-yard-linux-x86_64.tar.gz -C /work/m9-adopter-relocated-yard

set -eu
cd /work/m9-adopter-yard
RUSTFLAGS="--remap-path-prefix=$PWD=/ruster-source --remap-path-prefix=$HOME=/ruster-build -C debuginfo=0" cargo build --locked --offline --release -p ruster-yard
python3 scripts/package_app.py --binary /work/target/release/ruster-yard --output /work/m9-adopter-yard-linux-x86_64.tar.gz
sha256sum /work/target/release/ruster-yard /work/m9-adopter-yard-linux-x86_64.tar.gz

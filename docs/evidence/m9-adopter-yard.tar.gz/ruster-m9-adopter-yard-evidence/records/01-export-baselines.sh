set -eu
python3 scripts/new_app.py /work/m9-adopter-yard
python3 scripts/new_app.py --app motion-lab /work/m9-adopter-motion
cd /work/m9-adopter-yard
cargo run --locked --offline -p ruster-yard -- --headless --resources examples/yard-app/resources
cd /work/m9-adopter-motion
cargo run --locked --offline -p ruster-motion-lab -- --generic-demo --headless --ticks 10
cargo run --locked --offline -p ruster-motion-lab -- --scene examples/motion-lab/resources/generic.scene.json --headless --ticks 10

from ruster_m9_stock_support import run,ROOT
run('05-stock-extract-both', '''set -eu
mkdir /work/m9-eval2-stock-relocated-yard /work/m9-eval2-stock-relocated-motion
tar -xzf /work/m9-eval2-stock-yard-linux-x86_64.tar.gz -C /work/m9-eval2-stock-relocated-yard
tar -xzf /work/m9-eval2-stock-motion-linux-x86_64.tar.gz -C /work/m9-eval2-stock-relocated-motion
''')
def base(app,package):
 return ['bwrap','--unshare-user','--uid','1000','--gid','1000','--unshare-pid','--unshare-uts','--unshare-net','--unshare-ipc','--ro-bind',str(ROOT),'/', '--tmpfs','/work','--tmpfs','/opt','--tmpfs','/tmp','--ro-bind',str(ROOT/f'work/m9-eval2-stock-relocated-{app}'/package),'/mnt','--dev','/dev','--proc','/proc','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp/m9-stock-runtime-home','--setenv','LC_ALL','C.UTF-8','--cap-drop','ALL','--chdir','/tmp','--die-with-parent']
guards='''set -eu
test ! -e /work/source
test ! -e /work/m9-adopter-yard
test ! -e /work/m9-adopter-eval2-motion
test ! -e /work/target
test ! -e /opt/rust-toolchain
test ! -e /opt/cargo-registry
test -z "${DISPLAY-}${WAYLAND_DISPLAY-}${XDG_RUNTIME_DIR-}"
'''
run('06-stock-yard-default',guards+'/mnt/ruster-yard --headless\n',base=base('yard','ruster-yard'))
run('07-stock-yard-capacity3',guards+'/mnt/ruster-yard --headless --capacity 3\n',base=base('yard','ruster-yard'))
run('08-stock-motion-embedded',guards+'/mnt/ruster-motion-lab --generic-demo --headless --ticks 10\n',base=base('motion','ruster-motion-lab'))
run('09-stock-motion-scene',guards+'/mnt/ruster-motion-lab --scene /mnt/resources/generic.scene.json --headless --ticks 10\n',base=base('motion','ruster-motion-lab'))

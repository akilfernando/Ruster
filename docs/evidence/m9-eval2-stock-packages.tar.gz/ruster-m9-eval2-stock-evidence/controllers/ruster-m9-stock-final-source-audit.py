from ruster_m9_stock_support import ROOT,SRC,OUT
import json,hashlib
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results={}
for app,ws,rel in [('yard','m9-adopter-yard','examples/yard-app/src/lib.rs'),('motion','m9-adopter-eval2-motion','examples/motion-lab/resources/generic.scene.json')]:
 b=ROOT/'work'/ws;m=json.loads((b/'source-manifest.json').read_text());expected={e['path'] for e in m['files']};actual={p.relative_to(b).as_posix() for p in b.rglob('*') if p.is_file()}
 for e in m['files']:
  p=b/e['path'];assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256']
 extra=actual-expected-{'source-manifest.json'};assert all(p.startswith('scripts/__pycache__/') and p.endswith('.pyc') for p in extra)
 assert (b/rel).read_bytes()==(SRC/rel).read_bytes()
 results[app]={'source_files':len(m['files']),'all_initial_source_hashes_match':True,'only_generated_extras':sorted(extra),'stock_input_sha256':sha(b/rel),'frozen_eval2_input_byte_equal':True}
(OUT/'final-stock-source-audit.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))

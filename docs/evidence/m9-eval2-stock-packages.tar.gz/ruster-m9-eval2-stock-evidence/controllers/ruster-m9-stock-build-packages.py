from ruster_m9_stock_support import run
run('01-stock-yard-warm-build', '''set -eu
cd /work/m9-adopter-yard
RUSTFLAGS="--remap-path-prefix=$PWD=/ruster-source --remap-path-prefix=$HOME=/ruster-build -C debuginfo=0" cargo build --locked --offline --release -p ruster-yard
sha256sum /work/target/release/ruster-yard
''')
run('02-stock-yard-package', '''set -eu
cd /work/m9-adopter-yard
python3 scripts/package_app.py --binary /work/target/release/ruster-yard --output /work/m9-eval2-stock-yard-linux-x86_64.tar.gz
sha256sum /work/m9-eval2-stock-yard-linux-x86_64.tar.gz
''')
run('03-stock-motion-warm-build', '''set -eu
cd /work/m9-adopter-eval2-motion
CFLAGS="-ffile-prefix-map=$PWD=/ruster-source -ffile-prefix-map=$HOME=/ruster-build" RUSTFLAGS="--remap-path-prefix=$PWD=/ruster-source --remap-path-prefix=$HOME=/ruster-build -C debuginfo=0" cargo build --locked --offline --release -p ruster-motion-lab
sha256sum /work/target/release/ruster-motion-lab
''')
run('04-stock-motion-package', '''set -eu
cd /work/m9-adopter-eval2-motion
python3 scripts/package_app.py --app motion-lab --binary /work/target/release/ruster-motion-lab --output /work/m9-eval2-stock-motion-linux-x86_64.tar.gz
sha256sum /work/m9-eval2-stock-motion-linux-x86_64.tar.gz
''')

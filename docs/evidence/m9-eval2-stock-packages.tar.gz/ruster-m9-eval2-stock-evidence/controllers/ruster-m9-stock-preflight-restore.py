from ruster_m9_stock_support import ROOT,SRC,OUT
import hashlib,json,shutil
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
specs=[('yard','m9-adopter-yard','examples/yard-app/src/lib.rs','60fe484cb7ef6a12c8e829dab1d62a68fe187d37eec298c16a75c93c34dac0e6','m9-adopter-yard-linux-x86_64.tar.gz','b711b9c4fd88a72e554c8deee2cfab394cfb9fbad2f2b461744aea6a6d2a6488'),('motion','m9-adopter-eval2-motion','examples/motion-lab/resources/generic.scene.json','927f3f422e6d623814c4ff1ac6a09c2bf1b1160dc3573a3d0952178526b0ee21','m9-adopter-eval2-motion-linux-x86_64.tar.gz','1283ffd4e1f0b3b3cde7e97a838121e5b17671d40a91858531e5d00b9f9c960c')]
results=[]
# All validations precede any app input mutation or new archive creation.
for name,workspace,rel,edited,pkg,pkghash in specs:
 b=ROOT/'work'/workspace;m=json.loads((b/'source-manifest.json').read_text());entries={e['path']:e for e in m['files']};actual={p.relative_to(b).as_posix() for p in b.rglob('*') if p.is_file()};missing=set(entries)-actual;assert not missing
 changed=[]
 for path,e in entries.items():
  p=b/path;assert not p.is_symlink()
  if p.stat().st_size!=e['bytes'] or sha(p)!=e['sha256']:changed.append(path)
 assert changed==[rel] and sha(b/rel)==edited,(name,changed)
 extra=actual-set(entries)-{'source-manifest.json'};assert all(p.startswith('scripts/__pycache__/') and p.endswith('.pyc') for p in extra),extra
 assert sha(ROOT/'work'/pkg)==pkghash
 assert sha(SRC/rel)==entries[rel]['sha256'] and (SRC/rel).stat().st_size==entries[rel]['bytes']
 assert not (ROOT/'work'/f'm9-eval2-stock-{name}-linux-x86_64.tar.gz').exists()
 results.append({'app':name,'workspace':workspace,'restored_path':rel,'source_files':len(entries),'edited_input_sha256':edited,'stock_input_sha256':entries[rel]['sha256'],'initial_manifest_sha256':sha(b/'source-manifest.json'),'only_pre_restore_changed_file':changed,'generated_extras':sorted(extra),'modified_package':pkg,'modified_package_sha256':pkghash})
owned=ROOT/'work/m9-eval2-stock-evidence';assert not owned.exists();(owned/'edited-inputs').mkdir(parents=True)
for r in results:
 b=ROOT/'work'/r['workspace'];p=b/r['restored_path'];shutil.copy2(p,owned/'edited-inputs'/('yard-lib.rs' if r['app']=='yard' else 'motion-generic.scene.json'));p.write_bytes((SRC/r['restored_path']).read_bytes())
 m=json.loads((b/'source-manifest.json').read_text())
 for e in m['files']:
  q=b/e['path'];assert q.stat().st_size==e['bytes'] and sha(q)==e['sha256']
 r['all_initial_source_manifest_hashes_match_after_restore']=True
(OUT/'preflight-restore-audit.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))

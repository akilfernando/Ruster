from ruster_m9_stock_support import ROOT,OUT
from pathlib import Path
import hashlib,json,tarfile,sys
sha=lambda b:hashlib.sha256(b).hexdigest()
results={}
for app,package,depcount in [('yard','ruster-yard',248),('motion','ruster-motion-lab',264)]:
 a=ROOT/f'work/m9-eval2-stock-{app}-linux-x86_64.tar.gz'
 with tarfile.open(a) as tf:
  members=tf.getmembers();assert all(m.isfile() and m.name.startswith(package+'/') and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
  payload={m.name.removeprefix(package+'/'):tf.extractfile(m).read() for m in members}
 m=json.loads(payload['manifest.json']);assert m['application']==package and m['target']=='x86_64-unknown-linux-gnu' and len(m['dependencies'])==depcount
 prior=ROOT/('work/m9-adopter-relocated-yard/ruster-yard/manifest.json' if app=='yard' else 'work/m9-adopter-eval2-motion-relocated/ruster-motion-lab/manifest.json');assert m['dependencies']==json.loads(prior.read_text())['dependencies']
 assert set(payload)=={e['path'] for e in m['files']}|{'manifest.json'}
 for e in m['files']:assert len(payload[e['path']])==e['bytes'] and sha(payload[e['path']])==e['sha256']
 for name,data in payload.items():
  for prefix in [b'/HOST_HOME',b'/work/home',b'/work/m9-adopter-yard',b'/work/m9-adopter-eval2-motion']:assert prefix not in data,(name,prefix)
 expected_resources={'resources/truck.obj'} if app=='yard' else {'resources/motion.rhai','resources/generic.scene.json'}
 assert {p for p in payload if p.startswith('resources/')}==expected_resources
 if app=='motion':assert json.loads(payload['resources/generic.scene.json'])['authoring']['bindings']['motion-fast']['properties']['speed']['value']==2
 result={'application':package,'archive':str(a),'archive_sha256':sha(a.read_bytes()),'archive_bytes':a.stat().st_size,'binary_sha256':sha(payload[package]),'binary_bytes':len(payload[package]),'runtime_manifest_sha256':sha(payload['manifest.json']),'regular_safe_members':len(members),'dependencies':len(m['dependencies']),'selected_readable_notices_gate':'actual package command exit0','all_payload_hashes_valid':True,'elf':m['elf']}
 if len(sys.argv)>1 and sys.argv[1]=='post-runtime':
  b=ROOT/f'work/m9-eval2-stock-relocated-{app}'/package;actual={p.relative_to(b).as_posix() for p in b.rglob('*') if p.is_file()};assert actual==set(payload)
  for name,data in payload.items():assert (b/name).read_bytes()==data
  result['post_runtime_payload_file_set_bytes_unchanged_no_cache']=True
 results[app]=result
# Prior creator-iteration packages are immutable delivery evidence.
for name,h in [('m9-adopter-yard-linux-x86_64.tar.gz','b711b9c4fd88a72e554c8deee2cfab394cfb9fbad2f2b461744aea6a6d2a6488'),('m9-adopter-eval2-motion-linux-x86_64.tar.gz','1283ffd4e1f0b3b3cde7e97a838121e5b17671d40a91858531e5d00b9f9c960c')]:assert sha((ROOT/'work'/name).read_bytes())==h
(OUT/('stock-package-audit'+('-post-runtime' if len(sys.argv)>1 else '')+'.json')).write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
if len(sys.argv)>1:
 yard=(OUT/'06-stock-yard-default.log').read_text();win=(OUT/'07-stock-yard-capacity3.log').read_text();assert 'tick=10 delivered=20 target=24 source=10 capacity=2' in yard and 'tick=8 delivered=24 target=24 source=0 capacity=3' in win
 embedded=json.loads((OUT/'08-stock-motion-embedded.log').read_text());scene=json.loads((OUT/'09-stock-motion-scene.log').read_text());assert embedded==scene and str(embedded['tick'])=='10' and embedded['runtime_speed_override'] is None
 runtime={x['id']:x['transform']['translation'][0] for x in embedded['runtime_scene']['objects']};authored={x['id']:x['transform']['translation'][0] for x in embedded['authored_scene']['objects']}
 assert abs(runtime['sample-fast'])<1e-5 and abs(runtime['sample-slow']+1)<1e-5 and runtime['target']==2 and authored=={'sample-fast':-2,'sample-slow':-2,'target':2}
 outcome={'yard_default':yard.strip(),'yard_capacity3':win.strip(),'motion_runtime_x':runtime,'motion_authored_x':authored,'motion_embedded_explicit_complete_outputs_equal':True};(OUT/'stock-outcomes.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))

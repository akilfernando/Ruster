# Sanitization and reproduction

Host account path prefix becomes `/HOST_HOME` in copied records/controllers; reversing this substitution was verified to recover original bytes. Namespace paths remain unchanged. Exact command structure, scripts, all numeric outputs/exit codes/wall seconds remain. Original script hashes identify unsanitized executed scripts; SHA256SUMS identifies curated bytes. Restore `/HOST_HOME` only to an authorized host mount path when reconstructing commands.

Source/package/candidate manifests remain byte-for-byte metadata copies. Null dependency metadata becomes an empty TSV field; authoritative JSON retains null. Python controllers are new verification harnesses; no engine/application source exports, preserved edited input bodies, compiled binaries/packages, cache, credentials or sockets are included. Actual source-matching packages remain local outside this evidence archive.

Initial interrupted Yard attempt is retained separately, controller exit143 and146 observed compile lines. Exact interrupted walltime was not captured before controller termination. Root explicitly clarified/approved one resume in the same populated cache; all successful resumed command durations are separate. No product failure, cache cause, caching optimization or warm-budget pass claimed. Original stage names containing warm-build record initial intent, not a verified result.

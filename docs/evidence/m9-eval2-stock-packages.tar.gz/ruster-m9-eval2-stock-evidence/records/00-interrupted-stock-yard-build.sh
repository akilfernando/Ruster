set -eu
cd /work/m9-adopter-yard
RUSTFLAGS="--remap-path-prefix=$PWD=/ruster-source --remap-path-prefix=$HOME=/ruster-build -C debuginfo=0" cargo build --locked --offline --release -p ruster-yard
sha256sum /work/target/release/ruster-yard

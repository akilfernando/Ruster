set -eu
cd /work/m9-adopter-eval2-motion
python3 scripts/package_app.py --app motion-lab --binary /work/target/release/ruster-motion-lab --output /work/m9-eval2-stock-motion-linux-x86_64.tar.gz
sha256sum /work/m9-eval2-stock-motion-linux-x86_64.tar.gz

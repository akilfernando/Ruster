set -eu
mkdir /work/m9-eval2-stock-relocated-yard /work/m9-eval2-stock-relocated-motion
tar -xzf /work/m9-eval2-stock-yard-linux-x86_64.tar.gz -C /work/m9-eval2-stock-relocated-yard
tar -xzf /work/m9-eval2-stock-motion-linux-x86_64.tar.gz -C /work/m9-eval2-stock-relocated-motion

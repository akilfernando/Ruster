set -eu
cd /work/m9-adopter-yard
python3 scripts/package_app.py --binary /work/target/release/ruster-yard --output /work/m9-eval2-stock-yard-linux-x86_64.tar.gz
sha256sum /work/m9-eval2-stock-yard-linux-x86_64.tar.gz

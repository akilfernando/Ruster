# Eval2 source-matching stock application delivery

Both stock Linux x86_64 development packages passed build/package and readonly relocated headless verification. They match the application/copied-source closure in frozen m9-eval-2 commit c0eb45130d27f63da17e8128da11f4bb53f474f8, source archive SHA2563f10048944ee65250526ce3edb7a8dd1ebc5a6c4bd88c9392e5599c6354b8e5f. These are stock source-matching deliverables, separate from the preserved modified creator-iteration packages.

## Source and artifact safeguards

Before mutation, both known edited inputs matched recorded hashes; every other142/355 export source entry matched its initial manifest, only legitimate helper pycache extras existed, and both modified-package hashes matched. Edited inputs were preserved privately under /work/m9-eval2-stock-evidence/edited-inputs. Restored only owned Yard lib.rs and Motion generic.scene.json from frozen eval2 originals. Full source manifest hashes matched immediately afterward and after builds/packages. Independent source-closure comparison verified139 Yard/352 Motion files byte-identical to frozen eval2 at same relative paths; only generated root Cargo.toml/Cargo.lock/README intentionally differ. No immutable candidate, root repository, engine/vendor files or user projects were changed.

Distinct stock archive names were required fresh and packager no-overwrite guard retained. Prior modified packages remained unchanged after final audits: Yard b711b9c4fd88a72e554c8deee2cfab394cfb9fbad2f2b461744aea6a6d2a6488; Motion1283ffd4e1f0b3b3cde7e97a838121e5b17671d40a91858531e5d00b9f9c960c. Both stock selected dependency inventories exactly equal their corresponding modified package inventories:248 Yard/264 Motion. Actual package helper exit0/readable-selected-notice checks passed; all payload lengths/hashes and safe regular member paths valid. Binary payloads omit tested current source/home prefixes. Legal clearance is a separate review.

## Delivery compilation and interruption

Same existing populated /work/target, original owned workspace paths and identical documented remap flags were reused; max4 serialized Cargo jobs, offline readonly registry/toolchain. Cargo nevertheless recompiled many dependencies. The first Yard attempt was stopped because worker interpreted initial no-new-cold-build bound narrowly; controller exited143,146 compile lines retained. No package existed yet. Exact interrupted walltime was not captured before controller termination, and none is inferred. Root clarified necessary delivery recompilation in the same populated cache was allowed and explicitly authorized one resume. It completed with no product failure. No new empty cache, caching optimization, cause of invalidation, warm-budget pass or performance comparison is asserted. Stage filenames retaining 'warm-build' describe initial intent only.

Measured completed command seconds (resumed Yard attempt is separately measured; excludes unmeasured interrupted work):

{
  "01-stock-yard-warm-build.json": 156.9575965499971,
  "02-stock-yard-package.json": 5.931522127008066,
  "03-stock-motion-warm-build.json": 230.51099357800558,
  "04-stock-motion-package.json": 7.128815189003944,
  "05-stock-extract-both.json": 0.6196003549848683,
  "06-stock-yard-default.json": 0.007607489998918027,
  "07-stock-yard-capacity3.json": 0.0077278340177144855,
  "08-stock-motion-embedded.json": 0.009715002990560606,
  "09-stock-motion-scene.json": 0.010569034988293424
}

## Stock outcomes and isolation

Yard default: Time up — target missed | tick=10 delivered=20 target=24 source=10 capacity=2
Yard capacity3: Target delivered! | tick=8 delivered=24 target=24 source=0 capacity=3
Motion ten-tick runtimeX: {"sample-slow": -0.9999997615814209, "sample-fast": 1.4603138254187797e-07, "target": 2.0}
Motion authoredX: {"sample-slow": -2.0, "sample-fast": -2.0, "target": 2.0}
Embedded and explicit packaged Scene5 outputs completely equal. Stock Motion speed2 is packaged, no runtime override. Both package payload file sets/bytes unchanged after runs and no caches created.

Exact runtime controllers RO-bind private rootfs/package; tmpfs hides entire /work and /opt, unrelated /tmp cwd, clearenv/no desktop environment, uid1000/all capabilities dropped, unshared network/PID/UTS/IPC. Guards assert original source/exports/target/toolchain/registry absent. No host toolchain/registry/source/socket mounts. Package extraction fresh; no GUI/globalinput/clipboard or expensive suite/native replay. Cargo slot released immediately after final package; subsequent work only audits/headless runs/curation.

## Actual stock deliverables

{
  "yard": {
    "application": "ruster-yard",
    "archive": "/HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs/work/m9-eval2-stock-yard-linux-x86_64.tar.gz",
    "archive_sha256": "ed3195643798438dd02cf5244fedbfc6802386deda00174778a5fbf5ecdfcece",
    "archive_bytes": 8535379,
    "binary_sha256": "efbf109763bae393e77d77b2bd8c1e5c86d99a72909e14e4ddb3a129458539bd",
    "binary_bytes": 26170200,
    "runtime_manifest_sha256": "2830ece139e7ff4fc60df60a1a64a12ee8513e77799f3a87d78931ee74605754",
    "regular_safe_members": 9,
    "dependencies": 248,
    "selected_readable_notices_gate": "actual package command exit0",
    "all_payload_hashes_valid": true,
    "elf": {
      "needed": [
        "ld-linux-x86-64.so.2",
        "libc.so.6",
        "libgcc_s.so.1",
        "libm.so.6"
      ],
      "interpreter": "/lib64/ld-linux-x86-64.so.2",
      "glibc_symbols": [
        "GLIBC_2.14",
        "GLIBC_2.15",
        "GLIBC_2.16",
        "GLIBC_2.17",
        "GLIBC_2.18",
        "GLIBC_2.2.5",
        "GLIBC_2.25",
        "GLIBC_2.27",
        "GLIBC_2.28",
        "GLIBC_2.29",
        "GLIBC_2.3",
        "GLIBC_2.3.4",
        "GLIBC_2.30",
        "GLIBC_2.32",
        "GLIBC_2.33",
        "GLIBC_2.34",
        "GLIBC_2.35",
        "GLIBC_2.39",
        "GLIBC_2.9"
      ]
    },
    "post_runtime_payload_file_set_bytes_unchanged_no_cache": true
  },
  "motion": {
    "application": "ruster-motion-lab",
    "archive": "/HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs/work/m9-eval2-stock-motion-linux-x86_64.tar.gz",
    "archive_sha256": "4d559f9c94dbd93c10e4bfc1a416638d8c037e775a215083688166c9ccd7e22a",
    "archive_bytes": 10417830,
    "binary_sha256": "ff83754d83cbfca2e2491e6b0d1e11d9f15effd5424e7b9fc4705e94f51ca3ef",
    "binary_bytes": 33083952,
    "runtime_manifest_sha256": "34c021a926a82c48bd751d0d6beef2cf5ce0ee0420192c97771282c7f3af3c6d",
    "regular_safe_members": 10,
    "dependencies": 264,
    "selected_readable_notices_gate": "actual package command exit0",
    "all_payload_hashes_valid": true,
    "elf": {
      "needed": [
        "ld-linux-x86-64.so.2",
        "libc.so.6",
        "libgcc_s.so.1",
        "libm.so.6"
      ],
      "interpreter": "/lib64/ld-linux-x86-64.so.2",
      "glibc_symbols": [
        "GLIBC_2.11",
        "GLIBC_2.14",
        "GLIBC_2.15",
        "GLIBC_2.16",
        "GLIBC_2.17",
        "GLIBC_2.18",
        "GLIBC_2.2.5",
        "GLIBC_2.25",
        "GLIBC_2.27",
        "GLIBC_2.28",
        "GLIBC_2.29",
        "GLIBC_2.3",
        "GLIBC_2.3.4",
        "GLIBC_2.30",
        "GLIBC_2.32",
        "GLIBC_2.33",
        "GLIBC_2.34",
        "GLIBC_2.35",
        "GLIBC_2.39",
        "GLIBC_2.4",
        "GLIBC_2.9"
      ]
    },
    "post_runtime_payload_file_set_bytes_unchanged_no_cache": true
  }
}

Actual packages remain local under private rootfs/work for root to bundle outside Git; curated evidence contains metadata only. Package manifests record interpreter /lib64/ld-linux-x86-64.so.2 and ld-linux/libc/libgcc_s/libm with symbol references through GLIBC2.39; this is not a hard nonweak minimum or broad Linux support claim.

## Limits and stop state

Private Ubuntu24.04.5 userspace shares host kernel and supplied Rust1.99.1/cache prerequisites. This is source-matching stock/headless delivery evidence; previous creator-iteration evidence remains separate. No external-human/fullUI/GPU/fresh-machine acceptance or public distribution/legal clearance is inferred. No repository edits, hosted actions, system installations or publication. No further Cargo/application runs after final runtime audits. Root owns the concrete local bundle and project documentation.

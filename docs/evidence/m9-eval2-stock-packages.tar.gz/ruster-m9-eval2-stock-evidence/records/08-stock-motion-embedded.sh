set -eu
test ! -e /work/source
test ! -e /work/m9-adopter-yard
test ! -e /work/m9-adopter-eval2-motion
test ! -e /work/target
test ! -e /opt/rust-toolchain
test ! -e /opt/cargo-registry
test -z "${DISPLAY-}${WAYLAND_DISPLAY-}${XDG_RUNTIME_DIR-}"
/mnt/ruster-motion-lab --generic-demo --headless --ticks 10

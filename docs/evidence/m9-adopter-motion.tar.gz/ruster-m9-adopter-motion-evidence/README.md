# Motion partial agent adopter evidence

Read records/HANDOFF.md for the full result, instructions/coaching/prerequisites, actual commands/timings, namespace guards and limits. Frozen corrected m9-eval-2 source commit c0eb45130d27f63da17e8128da11f4bb53f474f8; archive hash independently verified. Immutable source untouched; no Git initialization/workaround. Yard not repeated.

355 source export files initially matched hashes/lengths, ignored mlua lock absent. Only application-owned generic.scene.json motion-fast speed2 to3 changed, verified by full JSON comparison and one-line diff. No engine/vendor/exporter edits. The resource is compile-time embedded; app rebuild changes both embedded demo and packaged external scene. At ten100ms ticks fastX approximately0 to approximately1; slowX approximately-1 and target2 unchanged; authored positions unchanged. Final embedded/explicit-scene outputs agree completely.

C+Rust remapped release/package passed;264 selected dependency versions/readability gate passed,10 safe regular relative payload members including manifest, all hashes/lengths valid. Source/package/candidate manifest inventories and selected-version TSV are metadata. Actual binaries/source export trees omitted; identities in ARTIFACT-HASHES.json.

Both relocated modes use readonly rootfs/package; tmpfs hides entire /work and /opt, clearenv, unshared network/PID/UTS/IPC, uid1000/capabilities dropped and unrelated /tmp cwd. Explicit guards prove source/export/target/toolchain/registry absent; no host toolchain/registry/source/socket binds or display environment. Final payload bytes/file set unchanged and no cache. No new Motion product/harness failures or app retries.

Partial agent/headless/supplied-cached-prerequisite evidence, not external-human/fullUI/GPU/fresh-machine/another-machine acceptance or redistribution/legal clearance. Parent prepared environment and disclosed corrected candidate defects. No full suite replay, GUI/global input/clipboard/system install/network/email/push/publication/repository edits. No further Cargo/app runs during curation. Descriptive wall times in records are not performance comparisons.

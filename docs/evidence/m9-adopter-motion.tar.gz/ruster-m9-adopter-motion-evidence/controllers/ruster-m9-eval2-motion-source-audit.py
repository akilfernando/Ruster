from pathlib import Path
import hashlib,json,sys,difflib
OUT=Path('/tmp/ruster-m9-adopter-eval2-motion-results');BASE=Path('/HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs/work/m9-adopter-eval2-motion');SRC=Path('/HOST_HOME/.local/state/ruster-candidates/m9-eval-2/adopter-extraction/ruster-m9-eval-2')
m=json.loads((BASE/'source-manifest.json').read_text());assert m['application']=='ruster-motion-lab'
entries={e['path']:e for e in m['files']};actual={p.relative_to(BASE).as_posix() for p in BASE.rglob('*') if p.is_file()};missing=set(entries)-actual;extra=actual-set(entries)-{'source-manifest.json'}
assert not missing
changed=[]
for rel,e in entries.items():
 p=BASE/rel;assert not p.is_symlink()
 if p.stat().st_size!=e['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:changed.append(rel)
forbidden=[p for p in actual if any(x in Path(p).parts for x in ['.git','.env','target','ruster-editor','ruster-mcp','ruster-viewer','ruster-cli','yard-app'])];assert not forbidden
resources=sorted(p for p in actual if '/resources/' in p);assert resources==['examples/motion-lab/resources/generic.scene.json','examples/motion-lab/resources/motion.rhai']
assert not (BASE/'third_party/mlua/Cargo.lock').exists()
assert (BASE/'third_party/mlua/RUSTER-PATCH.md').is_file() and (BASE/'third_party/wgpu-hal/RUSTER-PATCH.md').is_file()
phase=sys.argv[1]
if phase=='baseline':assert not changed and not extra
elif phase=='edited':
 assert changed==['examples/motion-lab/resources/generic.scene.json']
 assert all(p.startswith('scripts/__pycache__/') and p.endswith('.pyc') for p in extra)
 old=(SRC/changed[0]).read_text();new=(BASE/changed[0]).read_text();a=json.loads(old);b=json.loads(new)
 assert a['authoring']['bindings']['motion-fast']['properties']['speed']['value']==2
 a['authoring']['bindings']['motion-fast']['properties']['speed']['value']=3;assert a==b
 (OUT/'motion-app-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=changed[0]+'.original',tofile=changed[0]+'.authored')))
else:raise ValueError(phase)
r={'application':m['application'],'files':len(entries),'missing':sorted(missing),'changed':changed,'extra_generated':sorted(extra),'forbidden':forbidden,'resources':resources,'ignored_vendor_lock_absent':True,'source_manifest_sha256':hashlib.sha256((BASE/'source-manifest.json').read_bytes()).hexdigest(),'app_resource_sha256':hashlib.sha256((BASE/'examples/motion-lab/resources/generic.scene.json').read_bytes()).hexdigest()}
(OUT/('source-audit-'+phase+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

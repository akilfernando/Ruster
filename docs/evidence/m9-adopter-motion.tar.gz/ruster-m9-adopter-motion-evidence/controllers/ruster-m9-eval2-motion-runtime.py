from ruster_m9_eval2_motion_support import run,ROOT
# PREPARED ONLY: Execute after approved package/audits; these stages contain no Cargo.
run('05-motion-extract', '''set -eu
mkdir /work/m9-adopter-eval2-motion-relocated
tar -xzf /work/m9-adopter-eval2-motion-linux-x86_64.tar.gz -C /work/m9-adopter-eval2-motion-relocated
''')
base=['bwrap','--unshare-user','--uid','1000','--gid','1000','--unshare-pid','--unshare-uts','--unshare-net','--unshare-ipc','--ro-bind',str(ROOT),'/', '--tmpfs','/work','--tmpfs','/opt','--tmpfs','/tmp','--ro-bind',str(ROOT/'work/m9-adopter-eval2-motion-relocated/ruster-motion-lab'),'/mnt','--dev','/dev','--proc','/proc','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp/m9-adopter-runtime-home','--setenv','LC_ALL','C.UTF-8','--cap-drop','ALL','--chdir','/tmp','--die-with-parent']
guards='''set -eu
test ! -e /work/source
test ! -e /work/m9-adopter-eval2-motion
test ! -e /work/target
test ! -e /opt/rust-toolchain
test ! -e /opt/cargo-registry
test -z "${DISPLAY-}${WAYLAND_DISPLAY-}${XDG_RUNTIME_DIR-}"
'''
run('06-motion-isolated-embedded',guards+'/mnt/ruster-motion-lab --generic-demo --headless --ticks 10\n',base=base)
run('07-motion-isolated-packaged-scene',guards+'/mnt/ruster-motion-lab --scene /mnt/resources/generic.scene.json --headless --ticks 10\n',base=base)

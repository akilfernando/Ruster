from pathlib import Path
import hashlib,json,tarfile,sys
ROOT=Path('/HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs');OUT=Path('/tmp/ruster-m9-adopter-eval2-motion-results')
a=ROOT/'work/m9-adopter-eval2-motion-linux-x86_64.tar.gz'
with tarfile.open(a) as tf:
 members=tf.getmembers();assert all(m.isfile() and m.name.startswith('ruster-motion-lab/') and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
 payload={m.name.removeprefix('ruster-motion-lab/'):tf.extractfile(m).read() for m in members}
m=json.loads(payload['manifest.json']);assert m['application']=='ruster-motion-lab' and m['target']=='x86_64-unknown-linux-gnu'
expected={'ruster-motion-lab','resources/motion.rhai','resources/generic.scene.json','README.txt','LICENSE-MIT','LICENSE-APACHE','THIRD_PARTY_NOTICES.txt','SUPPLEMENTAL_NOTICES.txt','LICENSE-SOURCES.json','manifest.json'};assert set(payload)==expected
assert set(payload)=={e['path'] for e in m['files']}|{'manifest.json'}
for e in m['files']:
 data=payload[e['path']];assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
for name,data in payload.items():
 for prefix in [b'/work/m9-adopter-eval2-motion',b'/work/home',b'/HOST_HOME']:assert prefix not in data,(name,prefix)
resource=json.loads(payload['resources/generic.scene.json']);assert resource['authoring']['bindings']['motion-fast']['properties']['speed']['value']==3
assert len(m['dependencies'])>0
r={'application':m['application'],'target':m['target'],'archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'archive_bytes':a.stat().st_size,'binary_sha256':hashlib.sha256(payload['ruster-motion-lab']).hexdigest(),'binary_bytes':len(payload['ruster-motion-lab']),'runtime_manifest_sha256':hashlib.sha256(payload['manifest.json']).hexdigest(),'regular_safe_members':len(members),'files':sorted(payload),'all_payload_hashes_lengths_valid':True,'packaged_fast_speed':3,'dependencies':len(m['dependencies']),'selected_readable_notices_gate':'package helper exit0; tool coverage check not independent legal clearance','elf':m['elf'],'current_source_home_prefix_absent':True}
(OUT/'package-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
if len(sys.argv)>1 and sys.argv[1]=='post-runtime':
 b=ROOT/'work/m9-adopter-eval2-motion-relocated/ruster-motion-lab';actual={p.relative_to(b).as_posix() for p in b.rglob('*') if p.is_file()};assert actual==expected
 for name,data in payload.items():assert (b/name).read_bytes()==data
 post={'payload_hashes_file_set_unchanged_after_runtime':True,'no_cache_created':True,'files':sorted(actual)};(OUT/'post-runtime-audit.json').write_text(json.dumps(post,indent=2)+'\n');print(json.dumps(post))

from pathlib import Path
import json,sys
ROOT=Path('/HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs');OUT=Path('/tmp/ruster-m9-adopter-eval2-motion-results')
def validate(path,fast):
 doc=json.loads(path.read_text());assert doc['mode']=='generic_motion_comparison' and str(doc['tick'])=='10' and doc['fixed_dt']==0.1 and doc['runtime_speed_override'] is None
 authored={x['id']:x for x in doc['authored_scene']['objects']};runtime={x['id']:x for x in doc['runtime_scene']['objects']}
 assert set(authored)==set(runtime)=={'sample-slow','sample-fast','target'}
 expected={'sample-slow':-1,'sample-fast':fast,'target':2}
 for ident,x in expected.items():
  assert abs(runtime[ident]['transform']['translation'][0]-x)<1e-5,(ident,runtime[ident],x)
  assert authored[ident]['transform']['translation'][0]==(-2 if ident!='target' else 2)
 return {'path':str(path),'mode':doc['mode'],'tick':doc['tick'],'runtime_x':{i:runtime[i]['transform']['translation'][0] for i in sorted(runtime)},'authored_x':{i:authored[i]['transform']['translation'][0] for i in sorted(authored)}}
which=sys.argv[1]
if which=='baseline':result=validate(ROOT/'work/m9-adopter-eval2-motion-evidence/baseline.json',0)
elif which=='edited':result=validate(ROOT/'work/m9-adopter-eval2-motion-evidence/edited.json',1)
elif which=='packaged':
 embedded=OUT/'06-motion-isolated-embedded.log';scene=OUT/'07-motion-isolated-packaged-scene.log';a=validate(embedded,1);b=validate(scene,1);assert json.loads(embedded.read_text())==json.loads(scene.read_text());result={'embedded':a,'packaged_scene':b,'complete_outputs_equal':True}
else:raise ValueError(which)
(OUT/('outcome-'+which+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

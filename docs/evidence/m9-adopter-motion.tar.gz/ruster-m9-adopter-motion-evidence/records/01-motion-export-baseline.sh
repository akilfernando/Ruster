set -eu
python3 scripts/new_app.py --app motion-lab /work/m9-adopter-eval2-motion
mkdir /work/m9-adopter-eval2-motion-evidence
cd /work/m9-adopter-eval2-motion
cargo run --locked --offline -p ruster-motion-lab -- --generic-demo --headless --ticks 10 > /work/m9-adopter-eval2-motion-evidence/baseline.json
cat /work/m9-adopter-eval2-motion-evidence/baseline.json
sha256sum /work/target/debug/ruster-motion-lab

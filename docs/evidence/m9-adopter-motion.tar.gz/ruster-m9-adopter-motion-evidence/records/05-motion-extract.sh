set -eu
mkdir /work/m9-adopter-eval2-motion-relocated
tar -xzf /work/m9-adopter-eval2-motion-linux-x86_64.tar.gz -C /work/m9-adopter-eval2-motion-relocated

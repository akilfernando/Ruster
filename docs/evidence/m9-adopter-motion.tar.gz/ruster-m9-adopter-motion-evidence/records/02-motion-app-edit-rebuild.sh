set -eu
cd /work/m9-adopter-eval2-motion
python3 - <<'EDIT'
from pathlib import Path
import json
p=Path('examples/motion-lab/resources/generic.scene.json');old=p.read_text();doc=json.loads(old)
assert doc['authoring']['bindings']['motion-fast']['properties']['speed']=={'type':'number','value':2}
start=old.index('"motion-fast": {');prefix=old[:start];tail=old[start:]
assert tail.count('"value": 2')==1
new=prefix+tail.replace('"value": 2','"value": 3',1)
expected=json.loads(old);expected['authoring']['bindings']['motion-fast']['properties']['speed']['value']=3
assert json.loads(new)==expected
p.write_text(new)
EDIT
cargo run --locked --offline -p ruster-motion-lab -- --generic-demo --headless --ticks 10 > /work/m9-adopter-eval2-motion-evidence/edited.json
cat /work/m9-adopter-eval2-motion-evidence/edited.json
sha256sum /work/target/debug/ruster-motion-lab

# Motion partial agent adopter handoff

Frozen corrected m9-eval-2 source commit c0eb45130d27f63da17e8128da11f4bb53f474f8, tree b89f10bfd01f3942c3ebf77fc0c60690992d6c34, archive SHA2563f10048944ee65250526ce3edb7a8dd1ebc5a6c4bd88c9392e5599c6354b8e5f independently verified against manifest. Immutable archive/extraction untouched, no Git initialization/workaround. Previous eval1 Motion missing-vendor-lock failure remains preserved in prior evidence; Yard not repeated.

## Result

Documented Motion source export succeeded with355 files and omitted ignored mlua development Cargo.lock. All initial355 hashes/lengths matched; only two documented resources; no history/editor/MCP/viewer/CLI/Yard/build/cache/private configuration extras. Application-owned generic.scene.json motion-fast speed2 to3 was the only changed source file. Complete JSON semantic comparison proves exactly that property differs; byte diff retains one changed value line. Because the application include_bytes! embeds this resource, rebuilding changed both embedded demo and packaged scene behavior. No engine/vendor/exporter modifications. Generated package-helper pycache excluded explicitly.

At ten100ms ticks baseline fastX1.4603138254187797e-7 (approximately0), slowX-0.9999997615814209, targetX2. After edit/rebuild fastX0.9999998807907104 (approximately1), slow and target unchanged. Authored X positions remain slow/fast-2 and target2. No speed override. Two relocated modes, --generic-demo and --scene /mnt/resources/generic.scene.json, both reproduce edited result with complete parsed output equality. This proves embedded and external packaged resource coherence.

Remapped release passed documented CFLAGS and RUSTFLAGS. Packaging exit0 passed selected264 dependency-version/readable-notice gate; app identity ruster-motion-lab, target x86_64-unknown-linux-gnu,10 safe regular relative members including manifest. Every payload SHA/length matched; no current source/home prefix. ELF inventory lists loader /lib64/ld-linux-x86-64.so.2 and ld-linux/libc/libgcc_s/libm, symbols through GLIBC2.39; no hard nonweak minimum or support matrix inferred. Both relocated modes run with readonly private rootfs/package; tmpfs hides entire /work and /opt, including old/current source/export/target/cache/toolchain. Clearenv, no display/runtime env, unshared network/PID/UTS/IPC, uid1000/all capabilities dropped, unrelated /tmp cwd, no hostsource/toolchain/registry/socket mounts. Explicit guards assert absence. Afterward all10 extracted file bytes/hash identities unchanged and no cache created. No new failures/retries in this Motion leg.

## Commands and durations

Numbered .json/.sh/.log files preserve exact full argv, script SHA256, shell content, exit, monotonic wallseconds and original output. Captured command durations (not performance comparisons):

{
  "07-motion-isolated-packaged-scene.json": 0.008873551996657625,
  "06-motion-isolated-embedded.json": 0.008762537996517494,
  "05-motion-extract.json": 0.35409640200668946,
  "04-motion-package.json": 7.19055484799901,
  "03-motion-c-rust-remapped-release.json": 232.7904295680055,
  "02-motion-app-edit-rebuild.json": 3.8880367040110286,
  "01-motion-export-baseline.json": 35.71619020399521
}

The remapped release is cold remapped dependency/build work using supplied cached registry/existing target; packaging has its own7.1906s duration. Cargo reports3m52s release compile. No full Rustsuite replay. Cargo slot released after packaging; later work only audits/headless runtime/curation.

## Artifacts

Private rootfs: /HOST_HOME/.local/state/ruster-ubuntu-eval-pv1cpdiq/rootfs
Export: rootfs/work/m9-adopter-eval2-motion
Package: rootfs/work/m9-adopter-eval2-motion-linux-x86_64.tar.gz
Relocated: rootfs/work/m9-adopter-eval2-motion-relocated/ruster-motion-lab
Raw evidence: /tmp/ruster-m9-adopter-eval2-motion-results
Package SHA256 1283ffd4e1f0b3b3cde7e97a838121e5b17671d40a91858531e5d00b9f9c960c (10417833bytes)
Binary SHA256 03c67227f66f254012f9dd754611c95c3565cda8ccc88f6a21dddf0397f5f203 (33083952bytes)
Runtime manifest SHA256 e7ec3a28366312b7de4c24ae9c3a34d4a3dd24c30cd18ab5eb0914992fac4855
Source manifest SHA25694935a146cb86e541e42d2b8e3da70db77a5d55e3e86fb965aa3d3b8d4a5d52c
Edited app resource SHA256927f3f422e6d623814c4ff1ac6a09c2bf1b1160dc3573a3d0952178526b0ee21
Both baseline/edited debug binary hashes captured separately in debug-binary-identities.json.

## Instructions, supplied prerequisites and limits

Read frozen Quickstart/distribution/Motion guide and generated workspace README as product instructions. Parent supplied private Ubuntu24.04.5 userspace on hostkernel, Rust1.99.1, readonly registry, preexisting target and namespace template, disclosed candidate defect correction, approved chosen property edit and serialized max4-job Cargo slot. Actual package helper's supported --binary argument selects shared target output. Registry/toolchain install/network paths were not tested. No system installs, original source changes, GUI/globalinput/clipboard, emails/push/publication, or repo documentation/commits. Agent partial/headless/cached prerequisites, not external-human/fullUI/GPU/freshmachine/anothermachine acceptance or distribution/legal clearance. Root owns broader acceptance and documentation. Stop after curated evidence handoff; no further Cargo/runtime commands.

M9 release-editor resource observations, recorded 2026-11-05 local time.
This is a curated evidence archive, not an executable test bundle.

idle-3.json / idle-256.json: independent process observations under default
compositor occlusion, inspection/MCP/validation disabled.
runtime-memory.json: one process observed before lazy VM initialization and
after Reset -> one committed Step -> Stop, MCP enabled and a unique-window-tag
render_unfocused=true rule active throughout both phases.
runtime-fixture-manifest.json: counts/hash and prior existing-CLI validation,
including initial lock-contention failures; no project/source bodies included.

All numeric sample fields retain their original JSON values. Context and runtime
receipts are whitelisted; full MCP/object trace, private bridge/session/socket
identifiers, home/project paths, PIDs/window addresses, hostname, desktop config
and backups, config hashes, state/recovery, binaries and project content are
excluded. Monitor context retains only approved geometry fields. Runtime
snapshot equality summaries were recomputed from all 48 captured scene pages;
raw object bodies were then omitted. source_result_sha256 identifies each local
uncurated result without including its sensitive content. Device/quality facts
were cross-checked against each original editor.log; no socket-bearing log is
included. Operation/run IDs are bounded non-secret receipt identifiers.

The archived samples concern only the editor PID: adapter/client/compositor/GPU
memory and build processes are outside their scope. No focused-frame, latency,
allocator attribution, leak, near-cap, platform-certification or optimization
claim follows. See M9-editor-resources.md for methods and limitations.

not valid wgsl for last-good warning

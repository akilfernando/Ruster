#!/usr/bin/env python3
"""Exact-PID app inspection; root grants launch. No global input or focus spoof."""
import argparse, importlib.util
from pathlib import Path
spec = importlib.util.spec_from_file_location('chrome_driver', '/tmp/m9-chrome-native/driver.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.base.BASE = Path('/tmp/m9-content-restore')

class Driver(module.BehaviorDriver):
    def action(self, a, i):
        if a['op'] == 'settled_drag':
            start = self.center(a['selector'])
            self.event([{'PointerMoved': start}])
            self.pointer(start, 'Primary', True)
            self.event([{'PointerMoved': {'x': start['x'], 'y': start['y'] - 4}}])
            self.event([{'PointerMoved': {'x': start['x'], 'y': start['y'] - 60}}])
            self.pointer({'x': start['x'], 'y': start['y'] - 60}, 'Primary', False)
            return {'start': start, 'dy': -60}
        if a['op'] == 'drag_delta':
            dy = float(a['dy'])
            assert 0 < abs(dy) <= 400
            start = self.center(a['selector'])
            self.pointer(start, 'Primary', True)
            for step in range(1, 9):
                self.event([{'PointerMoved': {'x': start['x'], 'y': start['y'] + dy * step / 8}}])
            self.pointer({'x': start['x'], 'y': start['y'] + dy}, 'Primary', False)
            return {'start': start, 'dy': dy}
        return super().action(a, i)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage', choices=['prepare','run']);p.add_argument('name')
    p.add_argument('--pid',type=int);p.add_argument('--instance');p.add_argument('--port',type=int);p.add_argument('--actions')
    args=p.parse_args();path=module.base.runpath(args.name)
    if args.stage=='prepare': module.base.prepare(path)
    else:
        assert path.is_dir() and args.pid and args.instance and args.port and args.actions
        module.base.Driver=Driver;module.base.execute(args,path)
if __name__=='__main__':main()

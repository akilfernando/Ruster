import os,sys,json,time,subprocess,socket,hashlib
from pathlib import Path
ROOT=Path('/home/akilf/Projects/Ruster')
BASE=Path('/tmp/m9-content-restore/intel')
INSTANCE='0aa6745f705f2c4b0a5004eb019ef76e5bbdb426_1793690289_1133262353'
PORT=5750
CONF=Path('/home/akilf/.config/hypr/hyprland.lua')
def hypr(command): return json.loads(subprocess.check_output(['hyprctl','-i',INSTANCE,'-j',command]))
def hidden(): assert hypr('activeworkspace')['id']!=2,'User is using workspace2; pause the test'
hidden()
assert all(c['pid']==717774 for c in hypr('clients') if c['class']=='org.ruster.editor')
with socket.socket() as probe: probe.bind(('127.0.0.1',PORT))
original=CONF.read_bytes()
(BASE/'hyprland-before.lua').write_bytes(original)
rule='''
-- BEGIN RUSTER M9 INTEL NATIVE
hl.window_rule({name="ruster-m9-intel-native",match={class="^org[.]ruster[.]editor$"},render_unfocused=true})
-- END RUSTER M9 INTEL NATIVE
'''
assert b'BEGIN RUSTER M9 INTEL NATIVE' not in original
CONF.write_bytes(original+rule.encode())
subprocess.run(['hyprctl','-i',INSTANCE,'reload','config-only'],check=True,stdout=subprocess.DEVNULL)
assert subprocess.check_output(['hyprctl','-i',INSTANCE,'configerrors']).strip() in (b'',b'ok')
env=dict(os.environ,VK_DRIVER_FILES="/usr/share/vulkan/icd.d/intel_icd.json",RUSTER_MCP_ENABLE="1",XDG_RUNTIME_DIR='/run/user/1000',WAYLAND_DISPLAY='wayland-1',HYPRLAND_INSTANCE_SIGNATURE=INSTANCE,
LD_LIBRARY_PATH='/home/akilf/.local/share/ruster-tools/vulkan-validation/usr/lib',VK_LAYER_PATH='/home/akilf/.local/share/ruster-tools/vulkan-validation/usr/share/vulkan/explicit_layer.d',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='layer',
EGUI_INSPECTION=f'127.0.0.1:{PORT}',RUSTER_EDITOR_STATE=str(BASE/'state/editor.json'),RUSTER_RECOVERY_DIR=str(BASE/'recovery'))
process=None; log=None; launches=0; records=[]
def record(value):
    records.append(value);(BASE/'process-records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(value),flush=True)
def launch(resume=False,scene=None):
    global process,log,launches
    hidden(); assert process is None or process.poll() is not None
    launches+=1
    log=(BASE/f'native-{launches}.log').open('wb')
    args=[str(ROOT/'target/debug/ruster-editor')]
    if not resume: args+=['--scene',scene or str(BASE/'project/scene.json')]
    if scene is not None:
        assert Path(scene).resolve().is_relative_to(BASE)
    before=hypr('activeworkspace')['id']
    process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    deadline=time.monotonic()+30
    while True:
        clients=[c for c in hypr('clients') if c['pid']==process.pid]
        if clients:
            assert len(clients)==1 and clients[0]['workspace']['id']==2 and clients[0]['class']=='org.ruster.editor',clients
            break
        assert process.poll() is None; assert time.monotonic()<deadline; time.sleep(.1)
    while True:
        try:
            with socket.create_connection(('127.0.0.1',PORT),timeout=1): pass
            break
        except OSError:
            assert time.monotonic()<deadline;time.sleep(.1)
    assert hypr('activeworkspace')['id']==before
    record(dict(event='launch',index=launches,pid=process.pid,args=args,port=PORT,window=clients[0],active_workspace=before))
launch()
for line in sys.stdin:
    try:
        value=json.loads(line);op=value['op']
        if op=='status': record(dict(event='status',pid=process.pid,poll=process.poll(),active_workspace=hypr('activeworkspace')['id']))
        elif op=='crash':
            hidden();assert value['pid']==process.pid and process.poll() is None
            checkpoint=Path(value['checkpoint']).resolve();assert checkpoint.is_relative_to(BASE/'recovery')
            assert hashlib.sha256(checkpoint.read_bytes()).hexdigest()==value['sha256']
            process.kill();code=process.wait(timeout=15);log.close();assert code==-9
            record(dict(event='intentional_crash',index=launches,pid=process.pid,exit=code,checkpoint=str(checkpoint),verified_sha256=value['sha256']))
        elif op=='launch': launch(bool(value.get('resume')),value.get('scene'))
        elif op=='wait':
            assert value['pid']==process.pid
            code=process.wait(timeout=min(30,int(value.get('timeout',20))));log.close()
            record(dict(event='normal_exit' if code==0 else 'exit',index=launches,pid=process.pid,exit=code))
        elif op=='finish':
            assert process.poll() is not None
            assert not any(c['pid']==process.pid for c in hypr('clients'))
            for p in BASE.glob('native-*.log'):
                assert 'Inserted device layer "VK_LAYER_KHRONOS_validation"' in p.read_text()
                subprocess.run(['python3',str(ROOT/'scripts/check_vulkan_log.py'),str(p)],check=True)
            current=CONF.read_bytes(); assert current.count(rule.encode())==1
            CONF.write_bytes(current.replace(rule.encode(),b'',1))
            subprocess.run(['hyprctl','-i',INSTANCE,'reload','config-only'],check=True,stdout=subprocess.DEVNULL)
            assert subprocess.check_output(['hyprctl','-i',INSTANCE,'configerrors']).strip() in (b'',b'ok')
            record(dict(event='cleanup',config_equal=CONF.read_bytes()==original,config_sha256=hashlib.sha256(CONF.read_bytes()).hexdigest(),active_workspace=hypr('activeworkspace')['id'],windows=[]))
            break
        else: raise ValueError('Unsupported controller operation')
    except Exception as error: record(dict(event='controller_error',message=str(error)))

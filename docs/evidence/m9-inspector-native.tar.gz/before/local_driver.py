import importlib.util,json,sys
from pathlib import Path
p=Path('/home/akilf/Projects/Ruster/docs/evidence/M8-behavior-native.py');spec=importlib.util.spec_from_file_location('behavior',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Driver(m.BehaviorDriver):
 def action(self,a,i):
  if a['op']=='modified_click':
   pos=self.center(a['selector']);mods={**m.base.MODS,**a['modifiers']}
   self.event([{'ModifiersChanged':mods}])
   for pressed in (True,False):self.event([{'PointerMoved':pos},{'PointerButton':{'pos':pos,'button':'Primary','pressed':pressed,'modifiers':mods}}])
   self.event([{'ModifiersChanged':m.base.MODS}])
   return {}
  return super().action(a,i)
m.base.Driver=Driver
class Args: pass
args=Args();args.pid=727273;args.instance='0aa6745f705f2c4b0a5004eb019ef76e5bbdb426_1793690289_1133262353';args.port=5750;args.actions=sys.argv[1]
m.base.execute(args,Path('/tmp/ruster-behavior-native/m9-inspector-20261105'))

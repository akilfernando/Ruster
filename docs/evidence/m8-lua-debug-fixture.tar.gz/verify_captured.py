"""Check retained protocol/runtime/cost claims without compiling or timing again."""
import json,pathlib
p=pathlib.Path(__file__).parent
r=json.loads((p/'result.json').read_text())
assert r['accessor']['normal_and_coroutine_stops']==129
assert r['accessor']['nested_cross_coroutine_outer_debug_rejected']
assert r['runtime']['committed_state']==[.5,.5] and r['runtime']['time']==1
assert r['runtime']['later_object_failure_atomic'] and r['runtime']['retry_matches_fresh']
assert r['runtime']['authored_binary_rejected']
assert r['worker']['break_8_step_9_continue_x']==.5
assert r['worker']['paused_ui_heartbeats']>0 and r['worker']['running_ui_heartbeats']>0
rows=json.loads((p/'cost-final.json').read_text());assert len(rows)==24
assert {(r['objects'],r['distinct_sources'],r['cache'],r['debug_line_hooks']) for r in rows}=={(n,d,c,h) for n in (1,32,256) for d in (False,True) for c in ('compiled_main_fresh_closure','trusted_debug_bytecode_reload') for h in (False,True)}
assert all(len(r['raw_tick_us'])==20 and r['tick_p95_us']>=r['tick_median_us']>0 for r in rows)
transcript=json.loads((p/'dap-transcript.json').read_text())
commands={i['send']['command'] for i in transcript if 'send'in i}
assert {'initialize','launch','setBreakpoints','configurationDone','stackTrace','scopes','variables','next','continue','disconnect'}<=commands
received=[i['receive']for i in transcript if 'receive'in i]
assert any(i.get('event')=='output' and i.get('body',{}).get('output')=='x=0.5\n' for i in received)
assert any(i.get('command')=='variables' and i.get('success') is False for i in received)
assert any(i.get('message','').startswith('Reply exceeds') and i.get('request_seq') for i in received)
assert 'PASS:' in (p/'protocol-check.log').read_text()
print('PASS: captured runtime, nested-state regression, DAP and24-row cost claims')

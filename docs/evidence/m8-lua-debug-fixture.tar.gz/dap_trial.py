import subprocess, json, time, pathlib, threading, queue
root=pathlib.Path(__file__).parent
binary='/home/akilf/Projects/Ruster/target/release/ruster-lua-debug-trial'
p=subprocess.Popen([binary,'--dap'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
messages=queue.Queue(); transcript=[]
def reader(proc, output_queue):
    while True:
        length=None
        while True:
            line=proc.stdout.readline()
            if not line:return
            if line==b'\r\n':break
            if line.lower().startswith(b'content-length:'):length=int(line.split(b':')[1])
        assert length<=65536,length
        value=json.loads(proc.stdout.read(length));transcript.append({'receive':value});output_queue.put(value)
threading.Thread(target=reader,args=(p,messages),daemon=True).start()
seq=0; events=[]
def receive(predicate):
    deadline=time.monotonic()+4
    while time.monotonic()<deadline:
        for i,item in enumerate(events):
            if predicate(item):return events.pop(i)
        item=messages.get(timeout=max(.01,deadline-time.monotonic()))
        if predicate(item):return item
        events.append(item)
    raise TimeoutError()
def request(command,arguments=None,success=True):
    global seq
    seq+=1
    value={'seq':seq,'type':'request','command':command,'arguments':arguments or {}}
    transcript.append({'send':value});body=json.dumps(value).encode();p.stdin.write(f'Content-Length: {len(body)}\r\n\r\n'.encode()+body);p.stdin.flush()
    reply=receive(lambda v:v.get('type')=='response' and v['request_seq']==seq)
    assert reply['success']==success,reply
    return reply.get('body',{})
def stopped():return receive(lambda v:v.get('event')=='stopped')
request('initialize',{'adapterID':'ruster-trial','linesStartAt1':True,'columnsStartAt1':True})
request('launch',{'program':'follower.lua'})
assert request('setBreakpoints',{'source':{'path':'follower.lua'},'breakpoints':[{'line':8}]})['breakpoints'][0]['verified']
request('configurationDone');stopped()
frame=request('stackTrace',{'threadId':1})['stackFrames'][0];assert frame['line']==8
scope=request('scopes',{'frameId':frame['id']})['scopes'][0]['variablesReference']
variables=request('variables',{'variablesReference':scope})['variables']
assert request('variables',{'variablesReference':scope})['variables']==variables
old_scope=scope
v={x['name']:x for x in variables};assert v['dt']['value']=='0.25'
props=request('variables',{'variablesReference':v['props']['variablesReference']})['variables']
props={x['name']:x for x in props};assert props['speed']['value']=='2';assert props['enabled']['value']=='true';assert props['target']['value']=='target-2'
request('next',{'threadId':1});stopped()
frame=request('stackTrace',{'threadId':1})['stackFrames'][0];assert frame['line']==9
request('variables',{'variablesReference':old_scope},success=False)
scope=request('scopes',{'frameId':frame['id']})['scopes'][0]['variablesReference']
variables=request('variables',{'variablesReference':scope})['variables'];assert next(x for x in variables if x['name']=='step')['value']=='0.5'
request('continue',{'threadId':1});output=receive(lambda v:v.get('event')=='output');assert output['body']['output']=='x=0.5\n'
receive(lambda v:v.get('event')=='terminated');request('disconnect');p.wait(timeout=3);assert p.returncode==0,p.stderr.read()
# A second actual transport session disconnects while paused. No Lua handle
# passes through this process boundary, and worker join must finish promptly.
p=subprocess.Popen([binary,'--dap'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
messages=queue.Queue();events=[];seq=0
threading.Thread(target=reader,args=(p,messages),daemon=True).start()
request('initialize',{'adapterID':'ruster-trial'})
request('launch',{'program':'follower.lua'})
request('setBreakpoints',{'source':{'path':'follower.lua'},'breakpoints':[{'line':8}]})
request('configurationDone');stopped();request('disconnect');p.wait(timeout=3);assert p.returncode==0,p.stderr.read()
# Control-character snapshot expansion must return a bounded error, retaining
# the real paused VM. Stepping after that error must still work.
p=subprocess.Popen([binary,'--dap','--dap-control-fixture'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
messages=queue.Queue();events=[];seq=0
threading.Thread(target=reader,args=(p,messages),daemon=True).start()
request('initialize',{'adapterID':'ruster-trial'});request('launch',{'program':'follower.lua'})
request('setBreakpoints',{'source':{'path':'follower.lua'},'breakpoints':[{'line':8}]})
request('configurationDone');stopped()
frame=request('stackTrace',{'threadId':1})['stackFrames'][0]
scope=request('scopes',{'frameId':frame['id']})['scopes'][0]['variablesReference']
request('variables',{'variablesReference':scope},success=False)
assert request('stackTrace',{'threadId':1})['stackFrames'][0]['line']==8
request('next',{'threadId':1});stopped();assert request('stackTrace',{'threadId':1})['stackFrames'][0]['line']==9
request('continue',{'threadId':1});receive(lambda v:v.get('event')=='terminated')
request('disconnect');p.wait(timeout=3);assert p.returncode==0,p.stderr.read()
(root/'dap-transcript.json').write_text(json.dumps(transcript,indent=2)+'\n')
print('PASS: framed DAP initialize/launch/setBreakpoints/configurationDone/stackTrace/scopes/variables/next/continue/disconnect; x=0.5')

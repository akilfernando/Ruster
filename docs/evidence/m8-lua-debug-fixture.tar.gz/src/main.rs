#![forbid(unsafe_code)]
use mlua::chunk::ChunkMode;
use mlua::debug::{Debug, DebugEvent};
use mlua::{Error, Function, HookTriggers, Lua, LuaOptions, Result, StdLib, Table, Value, VmState};
use serde::{Deserialize, Serialize};
use serde_json::{Value as Json, json};
use std::{
    cell::{Cell, RefCell},
    collections::{BTreeMap, HashSet},
    io::{self, BufRead, Read, Write},
    rc::Rc,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
        mpsc::{self, Receiver, SyncSender},
    },
    thread,
    time::{Duration, Instant},
};

const SOURCE: &str = include_str!("../follower.lua");
fn err(s: &str) -> Error {
    Error::runtime(s)
}
#[derive(Debug, Clone, Serialize, Deserialize)]
struct Var {
    name: String,
    value: String,
    children: Vec<Var>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
struct Frame {
    line: usize,
    source: String,
    locals: Vec<Var>,
}
fn short(s: impl AsRef<str>) -> String {
    s.as_ref().chars().take(256).collect()
}
struct Budget {
    locals: usize,
    nodes: usize,
    bytes: usize,
}
impl Budget {
    fn new() -> Self {
        Self {
            locals: 64,
            nodes: 2048,
            bytes: 65536,
        }
    }
    fn text(&mut self, s: impl AsRef<str>) -> String {
        let mut out = String::new();
        for c in s.as_ref().chars().take(256) {
            if c.len_utf8() > self.bytes {
                break;
            }
            out.push(c);
            self.bytes -= c.len_utf8();
        }
        out
    }
}
fn dto(
    name: String,
    v: Value,
    depth: usize,
    seen: &mut HashSet<usize>,
    budget: &mut Budget,
) -> Result<Var> {
    if budget.nodes == 0 {
        return Ok(Var {
            name: String::new(),
            value: String::new(),
            children: vec![],
        });
    }
    budget.nodes -= 1;
    let mut children = Vec::new();
    let value = match v {
        Value::Nil => "nil".into(),
        Value::Boolean(b) => b.to_string(),
        Value::Integer(n) => n.to_string(),
        Value::Number(n) => n.to_string(),
        Value::String(s) => short(s.to_string_lossy()),
        Value::Table(t) => {
            let id = t.to_pointer() as usize;
            if seen.contains(&id) {
                "<cycle>".into()
            } else if depth >= 2 {
                "<depth limit>".into()
            } else {
                seen.insert(id);
                // Table::pairs uses lua_next, does not invoke __pairs or __index.
                for pair in t.pairs::<Value, Value>().take(16) {
                    if budget.nodes == 0 || budget.bytes == 0 {
                        break;
                    }
                    let (k, v) = pair?;
                    let key = match k {
                        Value::String(s) => short(s.to_string_lossy()),
                        Value::Integer(i) => i.to_string(),
                        _ => "<key>".into(),
                    };
                    children.push(dto(key, v, depth + 1, seen, budget)?);
                }
                seen.remove(&id);
                "table".into()
            }
        }
        _ => "<opaque>".into(),
    };
    Ok(Var {
        name: budget.text(name),
        value: budget.text(value),
        children,
    })
}
fn frame(d: &Debug, budget: &mut Budget) -> Result<Frame> {
    let mut locals = Vec::new();
    for i in 1..=64 {
        if budget.locals == 0 || budget.nodes == 0 || budget.bytes == 0 {
            break;
        }
        match d.local(i)? {
            Some((n, v)) => {
                budget.locals -= 1;
                locals.push(dto(n, v, 0, &mut HashSet::new(), budget)?)
            }
            None => break,
        }
    }
    Ok(Frame {
        line: d.current_line().unwrap_or(0),
        source: short(d.source().source.unwrap_or_default()),
        locals,
    })
}
fn snapshot(lua: &Lua, d: &Debug) -> Result<Vec<Frame>> {
    let mut budget = Budget::new();
    let mut frames = vec![frame(d, &mut budget)?];
    for i in 1..8 {
        match lua.inspect_stack(i, |d| frame(d, &mut budget)) {
            Some(f) => frames.push(f?),
            None => break,
        }
    }
    Ok(frames)
}
fn vm() -> Result<Lua> {
    let lua = Lua::new_with(StdLib::MATH, LuaOptions::default())?;
    lua.set_memory_limit(2 * 1024 * 1024)?;
    Ok(lua)
}
fn env(lua: &Lua, target: f64) -> Result<Table> {
    let e = lua.create_table()?;
    let math = lua.create_table()?;
    let originals: Table = lua.globals().get("math")?;
    math.set("min", originals.get::<Function>("min")?)?;
    e.set("math", math)?;
    let host = lua.create_table()?;
    host.set(
        "resolve",
        lua.create_function(move |l, id: String| {
            if id == "target-2" {
                let t = l.create_table()?;
                t.set("x", target)?;
                Ok(Some(t))
            } else {
                Ok(None)
            }
        })?,
    )?;
    e.set("host", host)?;
    Ok(e)
}
fn evaluate(lua: &Lua, main: &Function, x: f64, fail: bool) -> Result<f64> {
    main.set_environment(env(lua, 10.0)?)?;
    let update: Function = main.call(())?;
    let object = lua.create_table()?;
    object.set("x", x)?;
    let props = lua.create_table()?;
    props.set("speed", 2.0)?;
    props.set("enabled", true)?;
    props.set("target", "target-2")?;
    props.set("fail", fail)?;
    let out: Table = update.call((object, props, 0.25))?;
    let x: f64 = out.raw_get("x")?;
    if !x.is_finite() {
        return Err(err("nonfinite"));
    }
    Ok(x)
}
#[derive(Debug)]
enum Cmd {
    Next,
    Continue,
    Stop,
}
#[derive(Debug, Serialize)]
#[serde(tag = "event")]
enum Event {
    Stopped { frames: Vec<Frame> },
    Done { x: f64 },
    Failed { error: String },
}
struct Worker {
    commands: SyncSender<Cmd>,
    events: Receiver<Event>,
    stop: Arc<AtomicBool>,
    join: thread::JoinHandle<()>,
}
fn spawn(source: String, breakline: usize) -> Worker {
    let (tx, rx) = mpsc::sync_channel(8);
    let (etx, erx) = mpsc::sync_channel(8);
    let stop = Arc::new(AtomicBool::new(false));
    let flag = stop.clone();
    let join = thread::spawn(move || {
        let result = (|| -> Result<f64> {
            let lua = vm()?;
            let main = lua
                .load(&source)
                .set_mode(ChunkMode::Text)
                .set_name("@follower.lua")
                .into_function()?;
            let step = Rc::new(Cell::new(false));
            let first = Rc::new(Cell::new(true));
            let count = Cell::new(0u32);
            let events = etx.clone();
            let stop = flag.clone();
            lua.set_hook(
                HookTriggers::new().every_line().every_nth_instruction(100),
                move |lua, d| {
                    if stop.load(Ordering::Relaxed) {
                        return Err(err("cancelled"));
                    }
                    if d.event() == DebugEvent::Count {
                        count.set(count.get() + 100);
                        if count.get() > 100_000_000 {
                            return Err(err("instruction budget"));
                        }
                    }
                    if d.event() == DebugEvent::Line
                        && ((first.get() && d.current_line() == Some(breakline)) || step.get())
                    {
                        first.set(false);
                        step.set(false);
                        events
                            .try_send(Event::Stopped {
                                frames: snapshot(lua, d)?,
                            })
                            .map_err(|_| err("event queue full/disconnected"))?;
                        loop {
                            if stop.load(Ordering::Relaxed) {
                                return Err(err("cancelled while paused"));
                            }
                            match rx.recv_timeout(Duration::from_millis(5)) {
                                Ok(Cmd::Next) => {
                                    step.set(true);
                                    break;
                                }
                                Ok(Cmd::Continue) => break,
                                Ok(Cmd::Stop) | Err(mpsc::RecvTimeoutError::Disconnected) => {
                                    return Err(err("stopped/disconnected"));
                                }
                                Err(mpsc::RecvTimeoutError::Timeout) => {}
                            }
                        }
                    }
                    Ok(VmState::Continue)
                },
            )?;
            evaluate(&lua, &main, 0.0, false)
        })();
        let event = match result {
            Ok(x) => Event::Done { x },
            Err(e) => Event::Failed {
                error: e.to_string(),
            },
        };
        let _ = etx.try_send(event);
    });
    Worker {
        commands: tx,
        events: erx,
        stop,
        join,
    }
}
fn wait(w: &Worker) -> Event {
    w.events
        .recv_timeout(Duration::from_secs(3))
        .expect("bounded worker response")
}
fn cmd(w: &Worker, c: Cmd) {
    w.commands.try_send(c).unwrap()
}
fn find<'a>(vars: &'a [Var], name: &str) -> &'a Var {
    vars.iter()
        .find(|v| v.name == name)
        .unwrap_or_else(|| panic!("missing {name}: {vars:?}"))
}
fn access_tests() -> Result<Json> {
    let lua = vm()?;
    let captured = Rc::new(RefCell::new(None::<Table>));
    let hold = captured.clone();
    let hits = Rc::new(Cell::new(0));
    let hc = hits.clone();
    let hook = move |lua: &Lua, d: &Debug| {
        if d.current_line() == Some(5) {
            // Keep outer Debug borrowed while a scoped callback runs on another
            // coroutine. RawLua now selects that coroutine; outer local must
            // reject before touching either stack, then work after restoration.
            if hc.get() == 0 {
                lua.scope(|scope| {
                    let callback = scope.create_function(|_, ()| {
                        assert!(d.local(1).is_err());
                        Ok(())
                    })?;
                    let environment = lua.create_table()?;
                    environment.set("invoke", callback)?;
                    let function = lua
                        .load("return invoke()")
                        .set_environment(environment)
                        .into_function()?;
                    let other = lua.create_thread(function)?;
                    other.resume::<()>(())?;
                    Ok(())
                })?;
                assert!(d.local(1)?.is_some());
            }
            assert!(d.local(0).is_err());
            assert!(d.local(u32::MAX).is_err());
            assert!(d.local(1_000_000)?.is_none());
            let mut all = Vec::new();
            for i in 1..64 {
                if let Some((n, v)) = d.local(i)? {
                    all.push((n, v))
                } else {
                    break;
                }
            }
            assert!(
                all.iter()
                    .any(|(n, v)| n == "empty" && matches!(v, Value::Nil))
            );
            assert_eq!(all.iter().filter(|(n, _)| n == "shadow").count(), 2);
            for (n, v) in all {
                if n == "kept" {
                    if let Value::Table(t) = v {
                        *hold.borrow_mut() = Some(t);
                    }
                }
            }
            hc.set(hc.get() + 1);
        }
        Ok(VmState::Continue)
    };
    let src = "local empty = nil\nlocal shadow=1\nlocal kept={answer=42}; kept.self=kept\ndo local shadow=2\n local marker=shadow\nend\nreturn kept";
    lua.set_hook(HookTriggers::new().every_line(), hook.clone())?;
    for _ in 0..128 {
        let _: Table = lua.load(src).eval()?;
    }
    lua.remove_hook();
    lua.gc_collect()?;
    assert_eq!(
        captured.borrow().as_ref().unwrap().get::<i64>("answer")?,
        42
    );
    let co = lua.create_thread(lua.load(src).into_function()?)?;
    co.set_hook(HookTriggers::new().every_line(), hook)?;
    let _: Table = co.resume(())?;
    assert_eq!(hits.get(), 129);
    let meta = lua.create_table()?;
    meta.set(
        "__pairs",
        lua.create_function(|_, ()| -> Result<()> { Err(err("metamethod executed")) })?,
    )?;
    captured
        .borrow()
        .as_ref()
        .unwrap()
        .set_metatable(Some(meta))?;
    let val = dto(
        "cycle".into(),
        Value::Table(captured.borrow().as_ref().unwrap().clone()),
        0,
        &mut HashSet::new(),
        &mut Budget::new(),
    )?;
    assert!(val.children.iter().any(|v| v.value == "<cycle>"));
    let leaf = lua.create_table()?;
    let text = lua.create_string("x".repeat(4096))?;
    for i in 1..=16 {
        leaf.raw_set(i, text.clone())?
    }
    let wide = lua.create_table()?;
    for i in 1..=16 {
        wide.raw_set(i, leaf.clone())?
    }
    let mut budget = Budget::new();
    let mut bounded = Vec::new();
    for i in 0..64 {
        if budget.nodes == 0 || budget.bytes == 0 {
            break;
        }
        bounded.push(dto(
            format!("v{i}"),
            Value::Table(wide.clone()),
            0,
            &mut HashSet::new(),
            &mut budget,
        )?);
    }
    assert!(budget.bytes < 65536);
    assert!(serde_json::to_vec(&bounded).unwrap().len() < 256 * 1024);
    Ok(
        json!({"normal_and_coroutine_stops":hits.get(),"gc_root_survived":true,"nil_shadow_bad_index_cycle":true,"nested_cross_coroutine_outer_debug_rejected":true,"aggregate_dto_bytes_nodes_tested":true,"stack_balance":"128 calls + coroutine successful; no raw stack API in trial"}),
    )
}
fn runtime_tests() -> Result<Json> {
    let lua = vm()?;
    let count = Rc::new(Cell::new(0u64));
    let tick = Rc::new(Cell::new(0u64));
    let c = count.clone();
    let t = tick.clone();
    lua.set_hook(
        HookTriggers::new().every_nth_instruction(100),
        move |_, _| {
            c.set(c.get() + 100);
            t.set(t.get() + 100);
            if c.get() > 20_000 || t.get() > 100_000 {
                Err(err("budget"))
            } else {
                Ok(VmState::Continue)
            }
        },
    )?;
    let source = "local calls=0\nreturn function(object,props,dt)\n calls=calls+1; seen=(seen or 0)+1; local old=math.min; math.min=nil\n local a=host.resolve(props.target); a.x=-100; local b=host.resolve(props.target)\n object.x=object.x+old(props.speed*dt,b.x)+calls-1+seen-1\n props.speed=999\n if props.fail then local bad=nil+1 end\n return object\nend";
    let main = lua.load(source).set_mode(ChunkMode::Text).into_function()?;
    assert!(
        lua.load(main.dump(false))
            .set_mode(ChunkMode::Text)
            .into_function()
            .is_err()
    );
    let mut state = vec![0.0, 0.0];
    let mut time = 0;
    let mut tick_fn = |fail: bool| -> Result<()> {
        tick.set(0);
        let mut staged = Vec::new();
        for (i, x) in state.iter().enumerate() {
            count.set(0);
            staged.push(evaluate(&lua, &main, *x, fail && i == 1)?)
        }
        state = staged;
        time += 1;
        Ok(())
    };
    assert!(tick_fn(true).is_err());
    tick_fn(false)?;
    drop(tick_fn);
    assert_eq!(state, vec![0.5, 0.5]);
    assert_eq!(time, 1);
    let fresh = vm()?;
    let freshmain = fresh
        .load(source)
        .set_mode(ChunkMode::Text)
        .into_function()?;
    assert_eq!(evaluate(&fresh, &freshmain, 0.0, false)?, state[0]);
    for forbidden in [
        "io",
        "os",
        "debug",
        "package",
        "load",
        "loadfile",
        "dofile",
        "coroutine",
        "setmetatable",
        "getmetatable",
        "pcall",
        "_G",
    ] {
        assert!(matches!(
            env(&lua, 10.0)?.raw_get::<Value>(forbidden)?,
            Value::Nil
        ));
    }
    let e = env(&lua, 10.0)?;
    assert!(matches!(
        e.get::<Table>("math")?.raw_get::<Value>("random")?,
        Value::Nil
    ));
    count.set(0);
    tick.set(0);
    assert!(
        evaluate(
            &lua,
            &lua.load("while true do end").into_function()?,
            0.0,
            false
        )
        .is_err()
    );
    count.set(0);
    tick.set(0);
    assert!(
        evaluate(
            &lua,
            &lua.load("return function() while true do end end")
                .into_function()?,
            0.0,
            false
        )
        .is_err()
    );
    // One tick budget across individually bounded evaluations.
    let work = lua
        .load("local x=0 for i=1,1000 do x=x+i end; return function(o) return o end")
        .into_function()?;
    tick.set(0);
    let mut tick_failed = false;
    for _ in 0..256 {
        count.set(0);
        if evaluate(&lua, &work, 0.0, false).is_err() {
            tick_failed = true;
            break;
        }
    }
    assert!(tick_failed);
    lua.remove_hook();
    let before = lua.used_memory();
    lua.set_memory_limit(before + 64 * 1024)?;
    assert!(
        lua.load("local t={} for i=1,100000 do t[i]=i end return t")
            .eval::<Table>()
            .is_err()
    );
    Ok(
        json!({"later_object_failure_atomic":true,"retry_matches_fresh":true,"committed_state":state,"time":time,"fresh_module_closure_environment":true,"authored_binary_rejected":true,"immutable_tick_host_snapshot_copies":true,"module_update_tick_instruction_and_memory_limits":true}),
    )
}
fn framing_tests() {
    let escaped = encoded_body(
        json!({"seq":1,"type":"response","request_seq":17,"command":"variables","body":{"variables":[{"name":"control","value":"\u{1}".repeat(16384)}]}}),
    );
    assert!(escaped.len() <= 65536);
    let parsed: Json = serde_json::from_str(&escaped).unwrap();
    assert_eq!(parsed["request_seq"], 17);
    assert_eq!(parsed["success"], false);
    for bad in [
        b"Content-Length: 999999\r\n\r\n".as_slice(),
        b"Content-Length: 1\r\nContent-Length: 1\r\n\r\n0".as_slice(),
        b"Bad: x\r\n\r\n".as_slice(),
        b"Content-Length: 1\n\n0".as_slice(),
    ] {
        assert!(read_message(&mut io::Cursor::new(bad)).is_err());
    }
    let giant = vec![b'x'; 8192];
    assert!(read_message(&mut io::Cursor::new(giant)).is_err());
}
fn worker_tests() -> Json {
    framing_tests();
    let w = spawn(SOURCE.into(), 8);
    let a = wait(&w);
    let Event::Stopped { frames } = a else {
        panic!("{a:?}")
    };
    let v = &frames[0].locals;
    assert_eq!(find(v, "dt").value, "0.25");
    assert_eq!(find(&find(v, "props").children, "speed").value, "2");
    let heartbeat = Instant::now();
    let mut beats = 0;
    while heartbeat.elapsed() < Duration::from_millis(30) {
        thread::sleep(Duration::from_millis(1));
        beats += 1;
    }
    cmd(&w, Cmd::Next);
    let b = wait(&w);
    let Event::Stopped { frames } = b else {
        panic!("{b:?}")
    };
    assert_eq!(frames[0].line, 9);
    assert_eq!(find(&frames[0].locals, "step").value, "0.5");
    cmd(&w, Cmd::Continue);
    assert!(matches!(wait(&w),Event::Done{x} if x==0.5));
    w.join.join().unwrap();
    let w = spawn(SOURCE.into(), 8);
    assert!(matches!(wait(&w), Event::Stopped { .. }));
    cmd(&w, Cmd::Stop);
    assert!(matches!(wait(&w), Event::Failed { .. }));
    w.join.join().unwrap();
    let w = spawn(SOURCE.into(), 8);
    assert!(matches!(wait(&w), Event::Stopped { .. }));
    w.stop.store(true, Ordering::Relaxed);
    assert!(matches!(wait(&w), Event::Failed { .. }));
    w.join.join().unwrap();
    let w = spawn("while true do end".into(), 999);
    let mut running_beats = 0;
    let start = Instant::now();
    while start.elapsed() < Duration::from_millis(20) {
        assert!(w.events.try_recv().is_err());
        thread::sleep(Duration::from_millis(1));
        running_beats += 1;
    }
    w.stop.store(true, Ordering::Relaxed);
    assert!(matches!(wait(&w), Event::Failed { .. }));
    w.join.join().unwrap();
    let w = spawn(SOURCE.into(), 8);
    assert!(matches!(wait(&w), Event::Stopped { .. }));
    drop(w.commands);
    assert!(matches!(
        w.events.recv_timeout(Duration::from_secs(3)).unwrap(),
        Event::Failed { .. }
    ));
    w.join.join().unwrap();
    json!({"break_8_step_9_continue_x":0.5,"paused_ui_heartbeats":beats,"running_ui_heartbeats":running_beats,"stop_paused_cancel_running_disconnect":true,"channels_capacity":8})
}
fn bench() -> Result<Json> {
    let mut rows = Vec::new();
    for n in [1usize, 32, 256] {
        for distinct in [false, true] {
            for bytecode in [false, true] {
                for debug_hooks in [false, true] {
                    let lua = vm()?;
                    lua.set_memory_limit(64 * 1024 * 1024)?;
                    let instruction_count = Rc::new(Cell::new(0u64));
                    let counter = instruction_count.clone();
                    let eval_count = Rc::new(Cell::new(0u64));
                    let eval_counter = eval_count.clone();
                    let hook_calls = Rc::new(Cell::new(0u64));
                    let calls = hook_calls.clone();
                    let triggers = HookTriggers::new().every_nth_instruction(100);
                    let triggers = if debug_hooks {
                        triggers.every_line()
                    } else {
                        triggers
                    };
                    lua.set_hook(triggers, move |_, d| {
                        calls.set(calls.get() + 1);
                        if d.event() == DebugEvent::Count {
                            counter.set(counter.get() + 100);
                            eval_counter.set(eval_counter.get() + 100);
                        }
                        if counter.get() > 100_000 || eval_counter.get() > 20_000 {
                            Err(err("benchmark instruction budget"))
                        } else {
                            Ok(VmState::Continue)
                        }
                    })?;
                    let sources: Vec<String> = (0..if distinct { n } else { 1 })
                        .map(|i| format!("-- source {i}\n{SOURCE}"))
                        .collect();
                    let mains: Vec<Function> = sources
                        .iter()
                        .map(|s| lua.load(s).set_mode(ChunkMode::Text).into_function())
                        .collect::<Result<_>>()?;
                    let codes: Vec<Vec<u8>> = mains.iter().map(|f| f.dump(false)).collect();
                    let bytecode_bytes: usize = codes.iter().map(Vec::len).sum();
                    let mem_before = lua.used_memory();
                    let mut samples = Vec::new();
                    for repeat in 0..27 {
                        instruction_count.set(0);
                        hook_calls.set(0);
                        let start = Instant::now();
                        for i in 0..n {
                            eval_count.set(0);
                            let idx = if distinct { i } else { 0 };
                            let main = if bytecode {
                                lua.load(&codes[idx])
                                    .set_mode(ChunkMode::Binary)
                                    .into_function()?
                            } else {
                                mains[idx].clone()
                            };
                            assert_eq!(evaluate(&lua, &main, 0.0, false)?, 0.5);
                        }
                        if repeat >= 7 {
                            samples.push(start.elapsed().as_secs_f64() * 1e6);
                        }
                    }
                    let mem_after = lua.used_memory();
                    let gc_start = Instant::now();
                    lua.gc_collect()?;
                    let gc_us = gc_start.elapsed().as_secs_f64() * 1e6;
                    let mem_gc = lua.used_memory();
                    samples.sort_by(|a, b| a.total_cmp(b));
                    rows.push(json!({"objects":n,"distinct_sources":distinct,"debug_line_hooks":debug_hooks,"hook_callbacks_last_tick":hook_calls.get(),"cache":if bytecode{"trusted_debug_bytecode_reload"}else{"compiled_main_fresh_closure"},"tick_median_us":samples[10],"tick_p95_us":samples[18],"vm_memory_before":mem_before,"vm_memory_after":mem_after,"vm_memory_after_gc":mem_gc,"explicit_gc_us":gc_us,"trusted_bytecode_bytes":bytecode_bytes,"raw_tick_us":samples}));
                }
            }
        }
    }
    Ok(json!(rows))
}
fn read_message(reader: &mut impl BufRead) -> io::Result<Option<Json>> {
    let mut line = String::new();
    let mut size = None;
    let mut total = 0;
    loop {
        line.clear();
        let bytes = (&mut *reader).take(1025).read_line(&mut line)?;
        if bytes == 0 {
            return if total == 0 {
                Ok(None)
            } else {
                Err(io::Error::other("truncated header"))
            };
        }
        total += bytes;
        if bytes > 1024 || total > 4096 || !line.ends_with("\r\n") {
            return Err(io::Error::other("oversized/malformed header"));
        }
        if line == "\r\n" {
            break;
        }
        if let Some(s) = line.strip_prefix("Content-Length:") {
            if size.is_some() {
                return Err(io::Error::other("duplicate length"));
            }
            let n = s.trim().parse::<usize>().map_err(io::Error::other)?;
            if n > 65536 {
                return Err(io::Error::other("oversized body"));
            }
            size = Some(n);
        } else {
            return Err(io::Error::other("unknown header"));
        }
    }
    let size = size.ok_or_else(|| io::Error::other("missing length"))?;
    let mut bytes = vec![0; size];
    reader.read_exact(&mut bytes)?;
    Ok(Some(serde_json::from_slice(&bytes)?))
}
fn encoded_body(v: Json) -> String {
    let body = v.to_string();
    if body.len() <= 65536 {
        return body;
    }
    let sequence = v["seq"].as_u64().unwrap_or(0);
    if v["type"] == "response" {
        let command = match v["command"].as_str() {
            Some("variables") => "variables",
            Some("stackTrace") => "stackTrace",
            _ => "unknown",
        };
        json!({"seq":sequence,"type":"response","request_seq":v["request_seq"].as_u64().unwrap_or(0),"command":command,"success":false,"message":"Reply exceeds the 65536-byte encoded budget; inspect a smaller scope."}).to_string()
    } else {
        json!({"seq":sequence,"type":"event","event":"output","body":{"category":"stderr","output":"Debug reply exceeds the encoded byte budget.\n"}}).to_string()
    }
}
fn send_message(v: Json) {
    let body = encoded_body(v);
    debug_assert!(body.len() <= 65536);
    let mut out = io::stdout().lock();
    write!(out, "Content-Length: {}\r\n\r\n{}", body.len(), body).unwrap();
    out.flush().unwrap();
}
fn dap_source() -> String {
    if std::env::args().any(|a| a == "--dap-control-fixture") {
        let names = (0..64)
            .map(|i| format!("controls{i}"))
            .collect::<Vec<_>>()
            .join(",");
        let literal = format!("\"{}\"", "\\1".repeat(256));
        let values = vec![literal; 64].join(",");
        SOURCE.replace(
            "    if not props.enabled",
            &format!("    local {names} = {values}; if not props.enabled"),
        )
    } else {
        SOURCE.into()
    }
}
fn encode_vars(values: &[Var], map: &mut BTreeMap<u64, Vec<Json>>, next: &mut u64) -> Vec<Json> {
    values
        .iter()
        .map(|v| {
            let id = if v.children.is_empty() {
                0
            } else {
                let id = *next;
                *next += 1;
                let children = encode_vars(&v.children, map, next);
                map.insert(id, children);
                id
            };
            json!({"name":v.name,"value":v.value,"variablesReference":id})
        })
        .collect()
}
fn dap() -> Result<()> {
    let (tx, rx) = mpsc::sync_channel(8);
    thread::spawn(move || {
        let mut input = io::stdin().lock();
        while let Ok(Some(v)) = read_message(&mut input) {
            if tx.send(v).is_err() {
                break;
            }
        }
    });
    let mut worker = None::<Worker>;
    let mut line = 8;
    let mut vars = BTreeMap::<u64, Vec<Json>>::new();
    let mut frames = Vec::<Frame>::new();
    let mut seq = 1;
    let mut epoch = 0u64;
    loop {
        if let Some(w) = &worker {
            while let Ok(e) = w.events.try_recv() {
                match e {
                    Event::Stopped { frames: f } => {
                        frames = f;
                        vars.clear();
                        epoch += 1;
                        if epoch > 1024 {
                            return Err(err("pause epoch budget"));
                        }
                        let mut next = epoch * 10000 + 100;
                        for (i, f) in frames.iter().enumerate() {
                            let values = encode_vars(&f.locals, &mut vars, &mut next);
                            vars.insert(epoch * 10000 + (i + 1) as u64, values);
                        }
                        send_message(
                            json!({"seq":seq,"type":"event","event":"stopped","body":{"reason":"breakpoint","threadId":1,"allThreadsStopped":true}}),
                        );
                        seq += 1;
                    }
                    Event::Done { x } => {
                        send_message(
                            json!({"seq":seq,"type":"event","event":"output","body":{"output":format!("x={x}\n")}}),
                        );
                        seq += 1;
                        send_message(json!({"seq":seq,"type":"event","event":"terminated"}));
                        seq += 1;
                    }
                    Event::Failed { error } => {
                        send_message(
                            json!({"seq":seq,"type":"event","event":"output","body":{"output":error}}),
                        );
                        seq += 1;
                    }
                }
            }
        }
        let request = match rx.recv_timeout(Duration::from_millis(2)) {
            Ok(v) => v,
            Err(mpsc::RecvTimeoutError::Timeout) => continue,
            Err(_) => break,
        };
        let command = request["command"].as_str().unwrap_or("");
        let mut success = true;
        let body = match command {
            "initialize" => {
                json!({"supportsConfigurationDoneRequest":true,"supportsTerminateRequest":true})
            }
            "launch" => json!({}),
            "setBreakpoints" => {
                line = request["arguments"]["breakpoints"][0]["line"]
                    .as_u64()
                    .unwrap_or(8) as usize;
                json!({"breakpoints":[{"verified":true,"line":line}]})
            }
            "configurationDone" => {
                if worker.is_some() {
                    success = false
                } else {
                    worker = Some(spawn(dap_source(), line));
                }
                json!({})
            }
            "threads" => json!({"threads":[{"id":1,"name":"Owned Lua VM"}]}),
            "stackTrace" => {
                json!({"stackFrames":frames.iter().enumerate().map(|(i,f)|json!({"id":epoch*10000+i as u64+1,"name":"update","line":f.line,"column":1,"source":{"name":"follower.lua","path":"follower.lua"}})).collect::<Vec<_>>(),"totalFrames":frames.len()})
            }
            "scopes" => {
                let id = request["arguments"]["frameId"].as_u64().unwrap_or(0);
                if id <= epoch * 10000 || id > epoch * 10000 + frames.len() as u64 {
                    success = false;
                    json!({})
                } else {
                    json!({"scopes":[{"name":"Locals","variablesReference":id,"expensive":false}]})
                }
            }
            "variables" => {
                let id = request["arguments"]["variablesReference"]
                    .as_u64()
                    .unwrap_or(0);
                match vars.get(&id) {
                    Some(values) => json!({"variables":values}),
                    None => {
                        success = false;
                        json!({})
                    }
                }
            }
            "next" | "continue" => {
                if let Some(w) = &worker {
                    if frames.is_empty() {
                        success = false
                    } else {
                        frames.clear();
                        vars.clear();
                        cmd(
                            w,
                            if command == "next" {
                                Cmd::Next
                            } else {
                                Cmd::Continue
                            },
                        );
                    }
                } else {
                    success = false
                }
                json!({"allThreadsContinued":true})
            }
            "disconnect" | "terminate" => {
                if let Some(w) = &worker {
                    w.stop.store(true, Ordering::Relaxed);
                }
                json!({})
            }
            _ => {
                success = false;
                json!({})
            }
        };
        send_message(
            json!({"seq":seq,"type":"response","request_seq":request["seq"],"command":command,"success":success,"body":body}),
        );
        seq += 1;
        if command == "initialize" {
            send_message(json!({"seq":seq,"type":"event","event":"initialized"}));
            seq += 1;
        }
        if command == "disconnect" || command == "terminate" {
            break;
        }
    }
    if let Some(w) = worker {
        w.stop.store(true, Ordering::Relaxed);
        w.join.join().unwrap();
    }
    Ok(())
}
fn main() -> Result<()> {
    if std::env::args().any(|s| s == "--protocol-check") {
        framing_tests();
        println!("PASS: input framing and escaped outgoing encoded-byte cap");
        return Ok(());
    }
    if std::env::args().any(|s| s == "--dap") {
        return dap();
    }
    if std::env::args().any(|s| s == "--bench") {
        println!("{}", serde_json::to_string_pretty(&bench()?).unwrap());
        return Ok(());
    }
    let result =
        json!({"accessor":access_tests()?,"runtime":runtime_tests()?,"worker":worker_tests()});
    println!("{}", serde_json::to_string_pretty(&result).unwrap());
    Ok(())
}

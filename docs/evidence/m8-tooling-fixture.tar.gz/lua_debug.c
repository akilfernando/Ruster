#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
static int stops=0;
static void inspect(lua_State* L,lua_Debug* ar) {
 const char* name; lua_getinfo(L,"Sl",ar);
 printf("%s %s:%d\n",stops==0?"BREAK":"STEP",ar->short_src,ar->currentline);
 for(int i=1;(name=lua_getlocal(L,ar,i));i++) {
  printf(" local %s:%s",name,luaL_typename(L,-1));
  if(lua_isnumber(L,-1)) printf("=%.3f",lua_tonumber(L,-1));
  if(lua_istable(L,-1)) {
   for(const char** f=(const char*[]){"speed","enabled","target","x",NULL};*f;f++) {
    lua_getfield(L,-1,*f);
    if(lua_isnumber(L,-1)) printf(" %s=%.3f",*f,lua_tonumber(L,-1));
    else if(lua_isboolean(L,-1)) printf(" %s=%s",*f,lua_toboolean(L,-1)?"true":"false");
    else if(lua_isstring(L,-1)) printf(" %s=%s",*f,lua_tostring(L,-1));
    lua_pop(L,1);
   }
  }
  puts(""); lua_pop(L,1);
 }
}
static void hook(lua_State* L,lua_Debug* ar) {
 if((stops==0 && ar->currentline==8)||(stops==1 && ar->currentline==9)) {inspect(L,ar);stops++;}
}
static int resolve(lua_State* L) {
 const char* id=luaL_checkstring(L,1);
 if(strcmp(id,"target-2")) {lua_pushnil(L);return 1;}
 lua_newtable(L);lua_pushstring(L,id);lua_setfield(L,-2,"id");lua_pushnumber(L,10);lua_setfield(L,-2,"x");return 1;
}
static void number_field(lua_State* L,const char* k,double v){lua_pushnumber(L,v);lua_setfield(L,-2,k);}
static void tick(lua_State* L,int fn,int enabled,const char* target,double expected) {
 lua_rawgeti(L,LUA_REGISTRYINDEX,fn);lua_newtable(L);number_field(L,"x",0);
 lua_pushstring(L,"follower-1");lua_setfield(L,-2,"id");
 lua_newtable(L);number_field(L,"speed",2);lua_pushboolean(L,enabled);lua_setfield(L,-2,"enabled");
 lua_pushstring(L,target);lua_setfield(L,-2,"target");lua_pushnumber(L,.25);
 assert(lua_pcall(L,3,1,0)==LUA_OK);lua_getfield(L,-1,"x");double x=lua_tonumber(L,-1);assert(x==expected);lua_pop(L,2);
 printf("TICK enabled=%d target=%s result=%.3f expected=%.3f\n",enabled,target,x,expected);
}
int main(int argc,char** argv) {
 assert(argc==2);lua_State* L=luaL_newstate();assert(L);luaL_openlibs(L);
 lua_newtable(L);lua_pushcfunction(L,resolve);lua_setfield(L,-2,"resolve");lua_setglobal(L,"host");
 assert(luaL_dofile(L,argv[1])==LUA_OK);int fn=luaL_ref(L,LUA_REGISTRYINDEX);
 lua_sethook(L,hook,LUA_MASKLINE,0);tick(L,fn,1,"target-2",.5);lua_sethook(L,NULL,0,0);
 assert(stops==2);tick(L,fn,0,"target-2",0);tick(L,fn,1,"missing",0);lua_close(L);puts("PASS embedded C hook: breakpoint locals step continue and data exchange");
}

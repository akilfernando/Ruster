// Uncompiled comparison contract: no .NET SDK is installed in this environment.
namespace RusterFixture;
public readonly record struct ObjectRef(string Id);
public record ObjectState(ObjectRef Id, double X);
public record FollowerProps(double Speed, bool Enabled, ObjectRef Target);
public interface IRusterHost
{
    ObjectState? Resolve(ObjectRef id);
}
public static class Follower
{
    public static ObjectState Update(ObjectState current, FollowerProps props,
                                     double dt, IRusterHost host)
    {
        if (!props.Enabled) return current;
        var target = host.Resolve(props.Target);
        if (target is null) return current;
        var step = props.Speed * dt;
        return current with { X = System.Math.Min(current.X + step, target.X) };
    }
}

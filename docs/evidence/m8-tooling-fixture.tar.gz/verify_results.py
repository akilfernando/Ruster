import json,pathlib
p=pathlib.Path(__file__).resolve().parent
for name in ['lua','luau','luau-module','rhai']:
 r=json.loads((p/name/'result.json').read_text());assert 'error'not in r,(name,r.get('error'))
 def labels(key):
  v=r[key]['result'];v=v.get('items',[]) if isinstance(v,dict) else v
  return {x['label'].split('(')[0] for x in (v or [])}
 if name!='rhai':
  assert labels('props_completion')=={'speed','enabled','target'}
  assert 'resolve'in labels('host_completion')
  assert r['local_definition']['result']
 else:
  assert r['props_completion']['result'] is None
  assert labels('host_completion')=={'resolve'}
  assert r['resolve_definition']['result']
  initial=len(r['valid_diagnostics']);mid=len(r['type_error_diagnostics'])
  assert all(not x['diagnostics'] for x in r['type_error_diagnostics'][initial:])
  assert any(x['diagnostics'] for x in r['all_diagnostics'][mid:])
 if name=='lua':
  assert r['speed_definition']['result'] and r['resolve_definition']['result']
  assert any(d.get('code')=='assign-type-mismatch' for x in r['all_diagnostics'] if x['uri'].endswith('/follower.lua') for d in x['diagnostics'])
 if name.startswith('luau'):
  assert r['pull_diagnostics']['result']['items'][0]['code']==1000
  if name=='luau':assert r['speed_definition']['result']==[] and r['resolve_definition']['result']==[]
  else:assert r['speed_definition']['result'] and r['resolve_definition']['result']
 print('PASS',name,'captured protocol contracts')
assert 'PASS embedded C hook'in(p/'lua-debug.log').read_text()
print('PASS embedded C hook captured output')

---@meta
---@alias ObjectRef string
---@class ObjectState
---@field id ObjectRef
---@field x number
---@class FollowerProps
---@field speed number
---@field enabled boolean
---@field target ObjectRef
---@class RusterHost
host = {}
---@param id ObjectRef
---@return ObjectState?
function host.resolve(id) end

---@param object ObjectState
---@param props FollowerProps
---@param dt number
local function update(object, props, dt)
    if not props.enabled then return object end
    local target = host.resolve(props.target)
    if not target then return object end
    local step = props.speed * dt
    object.x = math.min(object.x + step, target.x)
    return object
end
return update

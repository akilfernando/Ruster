from lsp_trial import BASE,run
root=BASE/'luau-module';root.mkdir(exist_ok=True)
(root/'host.luau').write_text('''--!strict
export type ObjectRef = string
export type ObjectState = { id: ObjectRef, x: number }
export type FollowerProps = { speed: number, enabled: boolean, target: ObjectRef }
local host = {}
-- Generated editor stub. Runtime supplies this API; this file is not a game implementation.
function host.resolve(id: ObjectRef): ObjectState?
    return nil
end
return host
''')
source='''--!strict
local host = require("./host")
local function update(object: host.ObjectState, props: host.FollowerProps, dt: number): host.ObjectState
    if not props.enabled then return object end
    local target = host.resolve(props.target)
    if not target then return object end
    local step = props.speed * dt
    object.x = math.min(object.x + step, target.x)
    return object
end
return update
'''
run('luau-module',[str(BASE/'luau-lsp/luau-lsp'),'lsp'],{'luau-lsp':{'platform':{'type':'standard'},'sourcemap':{'enabled':False},'diagnostics':{'workspace':False}}},source,'luau')

import pathlib,json,time
from lsp_trial import Lsp,pos,BASE
root=BASE/'rhai';root.mkdir(exist_ok=True)
(root/'Rhai.toml').write_text('[source]\ninclude = ["**/*.rhai"]\n')
(root/'host.d.rhai').write_text('''module host;
type ObjectRef = String;
type ObjectState = #{ id: String, x: float };
/// Resolve a stable object ID; missing targets return unit.
fn resolve(id: ObjectRef) -> ObjectState | ();
''')
(root/'follower.d.rhai').write_text('''module;
type Props = #{ speed: float, enabled: bool, target: String };
fn update(object: #{ id: String, x: float }, props: Props, dt: float) -> #{ id: String, x: float };
''')
source='''fn properties() { #{ speed: 2.0, enabled: true, target: "target-2" } }
fn update(object, props, dt) {
    if !props.enabled { return object; }
    let target = host::resolve(props.target);
    if target == () { return object; }
    let step = props.speed * dt;
    object.x = min(object.x + step, target.x);
    object
}
let result = update(#{ id: "follower-1", x: 0.0 }, properties(), 0.25);
'''
(root/'static.d.rhai').write_text('module static;\nfn min(a: float, b: float) -> float;\n')
p=root/'follower.rhai';p.write_text(source);uri=p.as_uri();l=Lsp(['/home/akilf/Projects/Ruster/target/release/rhai','lsp','stdio'],root,{});r={};t=time.monotonic()
try:
 r['initialize']=l.start(root);r['initialize_seconds']=time.monotonic()-t;l.notify('textDocument/didOpen',{'textDocument':{'uri':uri,'languageId':'rhai','version':1,'text':source}});l.drain(2)
 for key,needle,after in [('props','props.speed',6),('host','host::resolve',6),('target','props.target',6)]:
  st=time.monotonic();r[key+'_completion']=l.request('textDocument/completion',{'textDocument':{'uri':uri},'position':pos(source,needle,after),'context':{'triggerKind':1}});r[key+'_completion_seconds']=time.monotonic()-st
 for key,needle,after in [('speed','props.speed',8),('resolve','host::resolve',8),('local','result = update',10)]:r[key+'_definition']=l.request('textDocument/definition',{'textDocument':{'uri':uri},'position':pos(source,needle,after)})
 r['valid_diagnostics']=[x['message']['params'] for x in l.all if x['direction']=='recv' and x['message'].get('method')=='textDocument/publishDiagnostics']
 bad=source.replace('let step = props.speed * dt;','let step = props.speed * dt;\n    props.speed = "fast";')
 l.notify('textDocument/didChange',{'textDocument':{'uri':uri,'version':2},'contentChanges':[{'text':bad}]});l.drain(2)
 r['type_error_diagnostics']=[x['message']['params'] for x in l.all if x['direction']=='recv' and x['message'].get('method')=='textDocument/publishDiagnostics']
 bad=source.replace('let step = props.speed * dt;','let step = ;')
 l.notify('textDocument/didChange',{'textDocument':{'uri':uri,'version':3},'contentChanges':[{'text':bad}]});l.drain(2)
 r['all_diagnostics']=[x['message']['params'] for x in l.all if x['direction']=='recv' and x['message'].get('method')=='textDocument/publishDiagnostics']
except Exception as e:r['error']=repr(e)
finally:l.close();r['total_seconds']=time.monotonic()-t;(root/'result.json').write_text(json.dumps(r,indent=2));(root/'transcript.json').write_text(json.dumps(l.all,indent=2))
print(json.dumps(r,indent=2))

//! Lua thread (coroutine) handling.
//!
//! This module provides types for creating and working with Lua coroutines from Rust.
//! Coroutines allow cooperative multitasking within a single Lua state by suspending and
//! resuming execution at well-defined yield points.
//!
//! # Basic Usage
//!
//! Threads are created via [`Lua::create_thread`] and driven by calling [`Thread::resume`]:
//!
//! ```rust
//! # use mlua::{Lua, Result, Thread};
//! # fn main() -> Result<()> {
//! let lua = Lua::new();
//! let thread: Thread = lua.load(r#"
//!     coroutine.create(function(a, b)
//!         coroutine.yield(a + b)
//!         return a * b
//!     end)
//! "#).eval()?;
//!
//! assert_eq!(thread.resume::<i32>((3, 4))?, 7);
//! assert_eq!(thread.resume::<i32>(())?,    12);
//! # Ok(())
//! # }
//! ```
//!
//! # Async Support
//!
//! When the `async` feature is enabled, a [`Thread`] can be converted into an [`AsyncThread`]
//! via [`Thread::into_async`], which implements both [`Future`] and [`Stream`].
//! This integrates Lua coroutines naturally with Rust async runtimes such as Tokio.
//!
//! [`Lua::create_thread`]: crate::Lua::create_thread
//! [`Future`]: std::future::Future
//! [`Stream`]: futures_util::stream::Stream

use std::fmt;
use std::os::raw::{c_int, c_void};

use crate::error::{Error, Result};
use crate::function::Function;
use crate::state::{RawLua, WeakLua};
use crate::traits::{FromLuaMulti, IntoLuaMulti};
use crate::types::{LuaType, ValueRef};
use crate::util::{StackGuard, check_stack, error_traceback_thread, pop_error};

#[cfg(not(feature = "luau"))]
use crate::{
    debug::{Debug, HookTriggers},
    types::HookKind,
};

#[cfg(feature = "async")]
use {
    futures_util::stream::Stream,
    std::{
        future::Future,
        marker::PhantomData,
        pin::Pin,
        ptr::NonNull,
        task::{Context, Poll, Waker},
    },
};

/// Controls which thread lifecycle events trigger the callback.
#[derive(Clone, Copy, Debug, Default)]
#[non_exhaustive]
pub struct ThreadTriggers {
    /// Trigger the callback when a new thread is created.
    ///
    /// On Luau this fires for every thread creation, on other Lua versions only for threads created
    /// via [`Lua::create_thread`](crate::Lua::create_thread).
    pub on_create: bool,
    /// Trigger the callback before a thread is resumed via [`Thread::resume`] (or an async resume
    /// driven by mlua). It does not fire for a `coroutine.resume` performed inside Lua code.
    pub on_resume: bool,
    /// Trigger the callback after a thread yields back to a [`Thread::resume`] driven by mlua.
    /// It does not fire for a yield consumed by a `coroutine.resume` inside Lua code.
    pub on_yield: bool,
}

impl ThreadTriggers {
    /// An instance of [`ThreadTriggers`] with `on_create` trigger set.
    pub const ON_CREATE: Self = Self::new().on_create();

    /// An instance of [`ThreadTriggers`] with `on_resume` trigger set.
    pub const ON_RESUME: Self = Self::new().on_resume();

    /// An instance of [`ThreadTriggers`] with `on_yield` trigger set.
    pub const ON_YIELD: Self = Self::new().on_yield();

    /// Returns a new instance of `ThreadTriggers` with all triggers disabled.
    pub const fn new() -> Self {
        Self {
            on_create: false,
            on_resume: false,
            on_yield: false,
        }
    }

    /// Returns an instance of `ThreadTriggers` with `on_create` trigger set.
    #[must_use]
    pub const fn on_create(mut self) -> Self {
        self.on_create = true;
        self
    }

    /// Returns an instance of `ThreadTriggers` with `on_resume` trigger set.
    #[must_use]
    pub const fn on_resume(mut self) -> Self {
        self.on_resume = true;
        self
    }

    /// Returns an instance of `ThreadTriggers` with `on_yield` trigger set.
    #[must_use]
    pub const fn on_yield(mut self) -> Self {
        self.on_yield = true;
        self
    }
}

impl std::ops::BitOr for ThreadTriggers {
    type Output = Self;

    fn bitor(mut self, rhs: Self) -> Self::Output {
        self.on_create |= rhs.on_create;
        self.on_resume |= rhs.on_resume;
        self.on_yield |= rhs.on_yield;
        self
    }
}

impl std::ops::BitOrAssign for ThreadTriggers {
    fn bitor_assign(&mut self, rhs: Self) {
        *self = *self | rhs;
    }
}

/// Represents a thread (coroutine) event.
#[derive(Debug, Clone)]
#[non_exhaustive]
pub enum ThreadEvent {
    /// A new thread was created.
    Create(Thread),
    /// A thread is about to be resumed via [`Thread::resume`].
    Resume(Thread),
    /// A thread has just yielded.
    Yield(Thread),
}

/// Status of a Lua thread (coroutine).
#[derive(Debug, Copy, Clone, Eq, PartialEq)]
pub enum ThreadStatus {
    /// The thread was just created or is suspended (yielded).
    ///
    /// If a thread is in this state, it can be resumed by calling [`Thread::resume`].
    Resumable,
    /// The thread is currently running.
    Running,
    /// The thread is active but not running.
    ///
    /// This is the case when the thread has resumed another thread (which has not yet
    /// returned or yielded).
    Normal,
    /// The thread has finished executing.
    Finished,
    /// The thread has raised a Lua error during execution.
    Error,
}

/// Internal representation of a Lua thread status.
///
/// The number in `New` and `Yielded` variants is the number of arguments pushed
/// to the thread stack.
#[derive(Clone, Copy)]
enum ThreadStatusInner {
    New(c_int),
    Running,
    Normal,
    Yielded(c_int),
    Finished,
    Error,
}

impl ThreadStatusInner {
    #[inline(always)]
    fn is_yielded(self) -> bool {
        matches!(self, ThreadStatusInner::Yielded(_))
    }
}

/// Handle to an internal Lua thread (coroutine).
#[derive(Clone, PartialEq)]
pub struct Thread(pub(crate) ValueRef, pub(crate) *mut ffi::lua_State);

#[cfg(feature = "send")]
unsafe impl Send for Thread {}
#[cfg(feature = "send")]
unsafe impl Sync for Thread {}

/// Thread (coroutine) representation as an async [`Future`] or [`Stream`].
///
/// [`Future`]: std::future::Future
/// [`Stream`]: futures_util::stream::Stream
#[cfg(feature = "async")]
#[cfg_attr(docsrs, doc(cfg(feature = "async")))]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct AsyncThread<R> {
    thread: Thread,
    ret: PhantomData<fn() -> R>,
    recycle: bool,
}

pub(crate) struct ThreadEventGuard<'a> {
    lua: &'a RawLua,
    prev_state: *mut ffi::lua_State,
}

impl<'a> ThreadEventGuard<'a> {
    #[inline]
    pub(crate) unsafe fn new(lua: &'a RawLua, thread_state: *mut ffi::lua_State) -> Self {
        let guard = ThreadEventGuard {
            lua,
            prev_state: lua.thread_event_state(),
        };
        lua.set_thread_event_state(thread_state);
        guard
    }
}

impl Drop for ThreadEventGuard<'_> {
    #[inline]
    fn drop(&mut self) {
        unsafe { self.lua.set_thread_event_state(self.prev_state) };
    }
}

#[inline]
fn check_thread_reentrancy(thread_state: *mut ffi::lua_State, lua: &RawLua) -> Result<()> {
    if thread_state == unsafe { lua.thread_event_state() } {
        let err = "cannot resume or reset a thread from within its own event callback";
        return Err(Error::runtime(err));
    }
    Ok(())
}

#[inline]
unsafe fn exec_thread_event(
    lua: &RawLua,
    enabled: bool,
    thread_state: *mut ffi::lua_State,
    event: impl FnOnce() -> ThreadEvent,
) -> Result<bool> {
    if enabled
        && lua.thread_event_state().is_null()
        && let Some(cb) = lua.thread_event_callback()
    {
        let _guard = ThreadEventGuard::new(lua, thread_state);
        cb(lua.lua(), event())?;
        return Ok(true);
    }
    Ok(false)
}

impl Thread {
    /// Returns the raw pointer to the Lua state that this thread is associated with.
    ///
    /// The pointer is valid only while this [`Thread`] is alive.
    #[inline(always)]
    pub fn state(&self) -> *mut ffi::lua_State {
        self.1
    }

    /// Resumes execution of this thread.
    ///
    /// Equivalent to [`coroutine.resume`].
    ///
    /// Passes `args` as arguments to the thread. If the coroutine has called [`coroutine.yield`],
    /// it will return these arguments. Otherwise, the coroutine wasn't yet started, so the
    /// arguments are passed to its main function.
    ///
    /// If the thread is no longer resumable (meaning it has finished execution or encountered an
    /// error), this will return [`Error::CoroutineUnresumable`], otherwise will return `Ok` as
    /// follows:
    ///
    /// If the thread calls [`coroutine.yield`], returns the values passed to `yield`. If the thread
    /// `return`s values from its main function, returns those.
    ///
    /// # Examples
    ///
    /// ```
    /// # use mlua::{Error, Lua, Result, Thread};
    /// # fn main() -> Result<()> {
    /// # let lua = Lua::new();
    /// let thread: Thread = lua.load(r#"
    ///     coroutine.create(function(arg)
    ///         assert(arg == 42)
    ///         local yieldarg = coroutine.yield(123)
    ///         assert(yieldarg == 43)
    ///         return 987
    ///     end)
    /// "#).eval()?;
    ///
    /// assert_eq!(thread.resume::<u32>(42)?, 123);
    /// assert_eq!(thread.resume::<u32>(43)?, 987);
    ///
    /// // The coroutine has now returned, so `resume` will fail
    /// match thread.resume::<u32>(()) {
    ///     Err(Error::CoroutineUnresumable) => {},
    ///     unexpected => panic!("unexpected result {:?}", unexpected),
    /// }
    /// # Ok(())
    /// # }
    /// ```
    ///
    /// [`coroutine.resume`]: https://www.lua.org/manual/5.4/manual.html#pdf-coroutine.resume
    /// [`coroutine.yield`]: https://www.lua.org/manual/5.4/manual.html#pdf-coroutine.yield
    pub fn resume<R>(&self, args: impl IntoLuaMulti) -> Result<R>
    where
        R: FromLuaMulti,
    {
        let lua = self.0.lua.lock();
        check_thread_reentrancy(self.state(), &lua)?;
        let (mut pushed_nargs, mut hook_yielded) = self.resumable_state(&lua)?;

        let state = lua.state();
        let thread_state = self.state();
        unsafe {
            let _sg = StackGuard::new(state);

            // If the resume callback runs, it may touch this thread, so re-read the argument count
            let on_resume = lua.thread_event_triggers().on_resume;
            if exec_thread_event(&lua, on_resume, thread_state, || {
                ThreadEvent::Resume(self.clone())
            })? {
                (pushed_nargs, hook_yielded) = self.resumable_state(&lua)?;
            }

            if !hook_yielded {
                let nargs = args.push_into_stack_multi(&lua)?;
                if nargs > 0 {
                    check_stack(thread_state, nargs)?;
                    ffi::lua_xmove(state, thread_state, nargs);
                    pushed_nargs += nargs;
                }
            }

            let mut thread_sg = StackGuard::with_top(thread_state, 0);
            let (status, nresults) = self.resume_inner(&lua, pushed_nargs)?;
            if status.is_yielded() && self.is_hook_yielded(&lua) {
                debug_assert_eq!(nresults, 0);
                thread_sg.keep(ffi::lua_gettop(thread_state));
            }

            check_stack(state, nresults + 1)?;
            ffi::lua_xmove(thread_state, state, nresults);

            // Exec thread yield callback
            let on_yield = lua.thread_event_triggers().on_yield && status.is_yielded();
            exec_thread_event(&lua, on_yield, thread_state, || ThreadEvent::Yield(self.clone()))?;

            R::from_stack_multi(nresults, &lua)
        }
    }

    /// Resumes execution of this thread, immediately raising an error.
    ///
    /// This is a Luau specific extension.
    #[cfg(any(feature = "luau", doc))]
    #[cfg_attr(docsrs, doc(cfg(feature = "luau")))]
    pub fn resume_error<R>(&self, error: impl crate::IntoLua) -> Result<R>
    where
        R: FromLuaMulti,
    {
        let lua = self.0.lua.lock();
        check_thread_reentrancy(self.state(), &lua)?;
        match self.status_inner(&lua) {
            ThreadStatusInner::New(_) | ThreadStatusInner::Yielded(_) => {}
            _ => return Err(Error::CoroutineUnresumable),
        };

        let state = lua.state();
        let thread_state = self.state();
        unsafe {
            let _sg = StackGuard::new(state);

            // Exec thread resume callback
            let on_resume = lua.thread_event_triggers().on_resume;
            exec_thread_event(&lua, on_resume, thread_state, || {
                ThreadEvent::Resume(self.clone())
            })?;

            check_stack(state, 1)?;
            error.push_into_stack(&lua)?;
            check_stack(thread_state, 1)?;
            ffi::lua_xmove(state, thread_state, 1);

            let _thread_sg = StackGuard::with_top(thread_state, 0);
            let (status, nresults) = self.resume_inner(&lua, ffi::LUA_RESUMEERROR)?;

            check_stack(state, nresults + 1)?;
            ffi::lua_xmove(thread_state, state, nresults);

            // Exec thread yield callback
            let on_yield = lua.thread_event_triggers().on_yield && status.is_yielded();
            exec_thread_event(&lua, on_yield, thread_state, || ThreadEvent::Yield(self.clone()))?;

            R::from_stack_multi(nresults, &lua)
        }
    }

    /// Resumes execution of this thread.
    ///
    /// It's similar to `resume()` but leaves `nresults` values on the thread stack.
    unsafe fn resume_inner(&self, lua: &RawLua, nargs: c_int) -> Result<(ThreadStatusInner, c_int)> {
        let state = lua.state();
        let thread_state = self.state();
        let mut nresults = 0;
        #[cfg(not(feature = "luau"))]
        let ret = ffi::lua_resume(thread_state, state, nargs, &mut nresults as *mut c_int);
        #[cfg(feature = "luau")]
        let ret = ffi::lua_resumex(thread_state, state, nargs, &mut nresults as *mut c_int);
        match ret {
            ffi::LUA_OK => Ok((ThreadStatusInner::Finished, nresults)),
            ffi::LUA_YIELD => Ok((ThreadStatusInner::Yielded(0), nresults)),
            ffi::LUA_ERRMEM => {
                // Don't call error handler for memory errors
                Err(pop_error(thread_state, ret))
            }
            _ => {
                check_stack(state, 3)?;
                protect_lua!(state, 0, 1, |state| error_traceback_thread(state, thread_state))?;
                Err(pop_error(state, ret))
            }
        }
    }

    /// Gets the status of the thread.
    pub fn status(&self) -> ThreadStatus {
        match self.status_inner(&self.0.lua.lock()) {
            ThreadStatusInner::New(_) | ThreadStatusInner::Yielded(_) => ThreadStatus::Resumable,
            ThreadStatusInner::Running => ThreadStatus::Running,
            ThreadStatusInner::Normal => ThreadStatus::Normal,
            ThreadStatusInner::Finished => ThreadStatus::Finished,
            ThreadStatusInner::Error => ThreadStatus::Error,
        }
    }

    /// Gets the status of the thread (internal implementation).
    fn status_inner(&self, lua: &RawLua) -> ThreadStatusInner {
        let thread_state = self.state();
        if thread_state == lua.state() {
            // The thread is currently running
            return ThreadStatusInner::Running;
        }
        let status = unsafe { ffi::lua_status(thread_state) };
        let top = unsafe { ffi::lua_gettop(thread_state) };
        match status {
            ffi::LUA_YIELD => ThreadStatusInner::Yielded(top),
            ffi::LUA_OK => {
                // Active call frames mean this thread has resumed another (still-running) thread.
                // Without frames it's new or finished.
                let mut ar = const { unsafe { std::mem::zeroed::<ffi::lua_Debug>() } };
                #[cfg(not(feature = "luau"))]
                let has_frames = unsafe { ffi::lua_getstack(thread_state, 0, &mut ar) != 0 };
                #[cfg(feature = "luau")]
                let has_frames = unsafe { ffi::lua_getinfo(thread_state, 0, cstr!(""), &mut ar) != 0 };
                if has_frames {
                    ThreadStatusInner::Normal
                } else if top > 0 {
                    ThreadStatusInner::New(top - 1)
                } else {
                    ThreadStatusInner::Finished
                }
            }
            _ => ThreadStatusInner::Error,
        }
    }

    /// Returns the pending argument count and whether the thread was interrupted by a hook.
    #[inline]
    fn resumable_state(&self, lua: &RawLua) -> Result<(c_int, bool)> {
        match self.status_inner(lua) {
            ThreadStatusInner::New(nargs) => Ok((nargs, false)),
            ThreadStatusInner::Yielded(nargs) => {
                let hook_yielded = self.is_hook_yielded(lua);
                Ok((if hook_yielded { 0 } else { nargs }, hook_yielded))
            }
            _ => Err(Error::CoroutineUnresumable),
        }
    }

    /// Distinguishes a hook interruption from a normal yield.
    fn is_hook_yielded(&self, lua: &RawLua) -> bool {
        unsafe { lua.is_hook_yielded(self.state()) }
    }

    /// Returns `true` if this thread is resumable (meaning it can be resumed by calling
    /// [`Thread::resume`]).
    #[inline(always)]
    pub fn is_resumable(&self) -> bool {
        self.status() == ThreadStatus::Resumable
    }

    /// Returns `true` if this thread is currently running.
    #[inline(always)]
    pub fn is_running(&self) -> bool {
        self.status() == ThreadStatus::Running
    }

    /// Returns `true` if this thread is active but not running.
    ///
    /// This is the case when the thread has resumed another thread that has not yet returned
    /// or yielded.
    #[inline(always)]
    pub fn is_normal(&self) -> bool {
        self.status() == ThreadStatus::Normal
    }

    /// Returns `true` if this thread has finished executing.
    #[inline(always)]
    pub fn is_finished(&self) -> bool {
        self.status() == ThreadStatus::Finished
    }

    /// Returns `true` if this thread has raised a Lua error during execution.
    #[inline(always)]
    pub fn is_error(&self) -> bool {
        self.status() == ThreadStatus::Error
    }

    /// Sets a hook function that will periodically be called as Lua code executes.
    ///
    /// This function is similar to [`Lua::set_hook`] except that it sets the hook for the thread.
    /// You can have multiple hooks for different threads.
    ///
    /// To remove a hook call [`Thread::remove_hook`].
    ///
    /// [`Lua::set_hook`]: crate::Lua::set_hook
    #[cfg(not(feature = "luau"))]
    #[cfg_attr(docsrs, doc(cfg(not(feature = "luau"))))]
    pub fn set_hook<F>(&self, triggers: HookTriggers, callback: F) -> Result<()>
    where
        F: Fn(&crate::Lua, &Debug) -> Result<crate::VmState> + crate::MaybeSend + 'static,
    {
        let lua = self.0.lua.lock();
        unsafe {
            lua.set_thread_hook(
                self.state(),
                HookKind::Thread(triggers, crate::types::XRc::new(callback)),
            )
        }
    }

    /// Removes any hook function from this thread.
    #[cfg(not(feature = "luau"))]
    #[cfg_attr(docsrs, doc(cfg(not(feature = "luau"))))]
    pub fn remove_hook(&self) {
        let lua = self.0.lua.lock();
        unsafe {
            lua.remove_thread_hook(self.state());
        }
    }

    /// Resets a thread
    ///
    /// In [Lua 5.4]: cleans its call stack and closes all pending to-be-closed variables.
    /// Returns an error in case of either the original error that stopped the thread or errors
    /// in closing methods.
    ///
    /// In Luau: resets to the initial state of a newly created Lua thread.
    /// Lua threads in arbitrary states (like yielded or errored) can be reset properly.
    ///
    /// Other Lua versions can reset only new or finished threads.
    ///
    /// Sets a Lua function for the thread afterwards.
    ///
    /// [Lua 5.4]: https://www.lua.org/manual/5.4/manual.html#lua_closethread
    pub fn reset(&self, func: Function) -> Result<()> {
        let lua = self.0.lua.lock();
        assert!(
            lua.weak() == &func.0.lua,
            "Lua instance passed Value created from a different main Lua state"
        );
        check_thread_reentrancy(self.state(), &lua)?;
        let thread_state = self.state();
        unsafe {
            let status = self.status_inner(&lua);
            self.reset_inner(status)?;

            // Push function to the top of the thread stack
            ffi::lua_xpush(lua.ref_thread(), thread_state, func.0.index);

            #[cfg(feature = "luau")]
            {
                // Inherit `LUA_GLOBALSINDEX` from the main thread
                ffi::lua_xpush(lua.main_state(), thread_state, ffi::LUA_GLOBALSINDEX);
                ffi::lua_replace(thread_state, ffi::LUA_GLOBALSINDEX);
            }

            Ok(())
        }
    }

    unsafe fn reset_inner(&self, status: ThreadStatusInner) -> Result<()> {
        match status {
            ThreadStatusInner::New(_) | ThreadStatusInner::Finished => {
                // Clear everything
                ffi::lua_settop(self.state(), 0);
                Ok(())
            }
            ThreadStatusInner::Running => Err(Error::runtime("cannot reset a running thread")),
            ThreadStatusInner::Normal => Err(Error::runtime("cannot reset a normal thread")),
            #[cfg(not(any(feature = "lua55", feature = "lua54", feature = "luau")))]
            ThreadStatusInner::Yielded(_) | ThreadStatusInner::Error => {
                Err(Error::runtime("cannot reset non-finished thread"))
            }
            #[cfg(any(feature = "lua55", feature = "lua54", feature = "luau"))]
            ThreadStatusInner::Yielded(_) | ThreadStatusInner::Error => {
                let thread_state = self.state();

                #[cfg(all(feature = "lua54", not(feature = "vendored")))]
                let status = ffi::lua_resetthread(thread_state);
                #[cfg(any(feature = "lua55", all(feature = "lua54", feature = "vendored")))]
                let status = {
                    let lua = self.0.lua.lock();
                    ffi::lua_closethread(thread_state, lua.state())
                };
                #[cfg(any(feature = "lua55", feature = "lua54"))]
                if status != ffi::LUA_OK {
                    return Err(pop_error(thread_state, status));
                }
                #[cfg(feature = "luau")]
                ffi::lua_resetthread(thread_state);

                Ok(())
            }
        }
    }

    /// Converts [`Thread`] to an [`AsyncThread`] which implements [`Future`] and [`Stream`] traits.
    ///
    /// Only resumable threads can be converted to [`AsyncThread`].
    ///
    /// `args` are pushed to the thread stack and will be used when the thread is resumed.
    /// The object calls [`resume`] while polling and also allow to run Rust futures
    /// to completion using an executor.
    ///
    /// Using [`AsyncThread`] as a [`Stream`] allow to iterate through [`coroutine.yield`]
    /// values whereas [`Future`] version discards that values and poll until the final
    /// one (returned from the thread function).
    ///
    /// [`Future`]: std::future::Future
    /// [`Stream`]: futures_util::stream::Stream
    /// [`resume`]: https://www.lua.org/manual/5.4/manual.html#lua_resume
    /// [`coroutine.yield`]: https://www.lua.org/manual/5.4/manual.html#pdf-coroutine.yield
    ///
    /// # Examples
    ///
    /// ```
    /// # use mlua::{Lua, Result, Thread};
    /// use futures_util::stream::TryStreamExt;
    /// # #[tokio::main]
    /// # async fn main() -> Result<()> {
    /// # let lua = Lua::new();
    /// let thread: Thread = lua.load(r#"
    ///     coroutine.create(function (sum)
    ///         for i = 1,10 do
    ///             sum = sum + i
    ///             coroutine.yield(sum)
    ///         end
    ///         return sum
    ///     end)
    /// "#).eval()?;
    ///
    /// let mut stream = thread.into_async::<i64>(1)?;
    /// let mut sum = 0;
    /// while let Some(n) = stream.try_next().await? {
    ///     sum += n;
    /// }
    ///
    /// assert_eq!(sum, 286);
    ///
    /// # Ok(())
    /// # }
    /// ```
    #[cfg(feature = "async")]
    #[cfg_attr(docsrs, doc(cfg(feature = "async")))]
    pub fn into_async<R>(self, args: impl IntoLuaMulti) -> Result<AsyncThread<R>>
    where
        R: FromLuaMulti,
    {
        let lua = self.0.lua.lock();
        check_thread_reentrancy(self.state(), &lua)?;
        let (_, hook_yielded) = self.resumable_state(&lua)?;

        let state = lua.state();
        let thread_state = self.state();
        unsafe {
            let _sg = StackGuard::new(state);

            if !hook_yielded {
                let nargs = args.push_into_stack_multi(&lua)?;
                if nargs > 0 {
                    check_stack(thread_state, nargs)?;
                    ffi::lua_xmove(state, thread_state, nargs);
                }
            }

            Ok(AsyncThread {
                thread: self,
                ret: PhantomData,
                recycle: false,
            })
        }
    }

    /// Enables sandbox mode on this thread.
    ///
    /// Under the hood replaces the global environment table with a new table,
    /// that performs writes locally and proxies reads to caller's global environment.
    ///
    /// This mode ideally should be used together with the global sandbox mode [`Lua::sandbox`].
    ///
    /// Please note that Luau links environment table with chunk when loading it into Lua state.
    /// Therefore you need to load chunks into a thread to link with the thread environment.
    ///
    /// [`Lua::sandbox`]: crate::Lua::sandbox
    ///
    /// # Examples
    ///
    /// ```
    /// # use mlua::{Lua, Result};
    /// # #[cfg(feature = "luau")]
    /// # fn main() -> Result<()> {
    /// let lua = Lua::new();
    /// let thread = lua.create_thread(lua.create_function(|lua2, ()| {
    ///     lua2.load("var = 123").exec()?;
    ///     assert_eq!(lua2.globals().get::<u32>("var")?, 123);
    ///     Ok(())
    /// })?)?;
    /// thread.sandbox()?;
    /// thread.resume::<()>(())?;
    ///
    /// // The global environment should be unchanged
    /// assert_eq!(lua.globals().get::<Option<u32>>("var")?, None);
    /// # Ok(())
    /// # }
    ///
    /// # #[cfg(not(feature = "luau"))]
    /// # fn main() { }
    /// ```
    #[cfg(any(feature = "luau", doc))]
    #[cfg_attr(docsrs, doc(cfg(feature = "luau")))]
    pub fn sandbox(&self) -> Result<()> {
        let lua = self.0.lua.lock();
        let state = lua.state();
        let thread_state = self.state();
        unsafe {
            check_stack(thread_state, 3)?;
            check_stack(state, 3)?;
            protect_lua!(state, 0, 0, |_| ffi::luaL_sandboxthread(thread_state))
        }
    }

    /// Converts this thread to a generic C pointer.
    ///
    /// There is no way to convert the pointer back to its original value.
    ///
    /// Typically this function is used only for hashing and debug information.
    #[inline]
    pub fn to_pointer(&self) -> *const c_void {
        self.0.to_pointer()
    }

    /// Returns a weak reference to the Lua instance owning this value.
    #[doc(hidden)]
    #[inline]
    pub fn weak_lua(&self) -> &WeakLua {
        &self.0.lua
    }
}

impl fmt::Debug for Thread {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Thread").field(&self.0).finish()
    }
}

impl LuaType for Thread {
    const TYPE_ID: c_int = ffi::LUA_TTHREAD;
}

#[cfg(feature = "async")]
impl<R> AsyncThread<R> {
    #[inline(always)]
    pub(crate) fn set_recyclable(&mut self, recyclable: bool) {
        self.recycle = recyclable;
    }

    #[inline(always)]
    pub(crate) fn thread(&self) -> &Thread {
        &self.thread
    }
}

#[cfg(feature = "async")]
impl<R> Drop for AsyncThread<R> {
    fn drop(&mut self) {
        if self.recycle
            && let Some(lua) = self.thread.0.lua.try_lock()
        {
            unsafe {
                #[cfg(feature = "luau")]
                if lua.is_running_gc() {
                    lua.update_thread_ownership(&self.thread, None);
                    return;
                }

                let mut status = self.thread.status_inner(&lua);
                if matches!(status, ThreadStatusInner::Yielded(0))
                    && !self.thread.is_hook_yielded(&lua)
                    && lua.is_async_wrapper_yield(self.thread.state())
                {
                    // The thread is dropped while yielded, resume it with the "terminate" signal
                    ffi::lua_pushlightuserdata(self.thread.1, crate::Lua::poll_terminate().0);
                    if let Ok((new_status, _)) = self.thread.resume_inner(&lua, 1) {
                        // The coroutine can finish or yield again.
                        status = new_status;
                    }
                }

                // For Lua 5.4 this also closes all pending to-be-closed variables
                if self.thread.reset_inner(status).is_ok() {
                    lua.recycle_thread(&mut self.thread);
                }
                lua.update_thread_ownership(&self.thread, None);
            }
        }
    }
}

#[cfg(feature = "async")]
impl<R: FromLuaMulti> Stream for AsyncThread<R> {
    type Item = Result<R>;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let lua = self.thread.0.lua.lock();
        check_thread_reentrancy(self.thread.state(), &lua)?;
        let mut nargs = match self.thread.resumable_state(&lua) {
            Ok((nargs, _)) => nargs,
            Err(_) => return Poll::Ready(None),
        };

        let state = lua.state();
        let thread_state = self.thread.state();
        unsafe {
            let _sg = StackGuard::new(state);
            let _wg = WakerGuard::new(&lua, cx.waker());

            // If the resume callback runs, it may touch this thread, so re-read the argument count
            let on_resume = lua.thread_event_triggers().on_resume;
            if exec_thread_event(&lua, on_resume, thread_state, || {
                ThreadEvent::Resume(self.thread.clone())
            })? {
                nargs = match self.thread.resumable_state(&lua) {
                    Ok((nargs, _)) => nargs,
                    Err(_) => return Poll::Ready(None),
                };
            }

            let mut thread_sg = StackGuard::with_top(thread_state, 0);
            let (status, nresults) = (self.thread).resume_inner(&lua, nargs)?;
            let hook_yielded = status.is_yielded() && self.thread.is_hook_yielded(&lua);
            if hook_yielded {
                debug_assert_eq!(nresults, 0);
                thread_sg.keep(ffi::lua_gettop(thread_state));
            }

            if status.is_yielded() && !hook_yielded && nresults == 1 && is_poll_pending(thread_state) {
                // Exec thread yield callback
                let on_yield = lua.thread_event_triggers().on_yield;
                exec_thread_event(&lua, on_yield, thread_state, || {
                    ThreadEvent::Yield(self.thread.clone())
                })?;
                return Poll::Pending;
            }

            check_stack(state, nresults + 1)?;
            ffi::lua_xmove(thread_state, state, nresults);

            if status.is_yielded() {
                let on_yield = lua.thread_event_triggers().on_yield;
                exec_thread_event(&lua, on_yield, thread_state, || {
                    ThreadEvent::Yield(self.thread.clone())
                })?;
                // Continue polling
                cx.waker().wake_by_ref();
            }

            Poll::Ready(Some(R::from_stack_multi(nresults, &lua)))
        }
    }
}

#[cfg(feature = "async")]
impl<R: FromLuaMulti> Future for AsyncThread<R> {
    type Output = Result<R>;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        let lua = self.thread.0.lua.lock();
        check_thread_reentrancy(self.thread.state(), &lua)?;
        let (mut nargs, _) = self.thread.resumable_state(&lua)?;

        let state = lua.state();
        let thread_state = self.thread.state();
        unsafe {
            let _sg = StackGuard::new(state);
            let _wg = WakerGuard::new(&lua, cx.waker());

            // If the resume callback runs, it may touch this thread, so re-read the argument count
            let on_resume = lua.thread_event_triggers().on_resume;
            if exec_thread_event(&lua, on_resume, thread_state, || {
                ThreadEvent::Resume(self.thread.clone())
            })? {
                (nargs, _) = self.thread.resumable_state(&lua)?;
            }

            let mut thread_sg = StackGuard::with_top(thread_state, 0);
            let (status, nresults) = self.thread.resume_inner(&lua, nargs)?;
            let hook_yielded = status.is_yielded() && self.thread.is_hook_yielded(&lua);
            if hook_yielded {
                debug_assert_eq!(nresults, 0);
                thread_sg.keep(ffi::lua_gettop(thread_state));
            }

            if status.is_yielded() {
                let pending = !hook_yielded && nresults == 1 && is_poll_pending(thread_state);

                // Exec thread yield callback
                let on_yield = lua.thread_event_triggers().on_yield;
                exec_thread_event(&lua, on_yield, thread_state, || {
                    ThreadEvent::Yield(self.thread.clone())
                })?;

                if !pending {
                    // Ignore values returned via yield()
                    cx.waker().wake_by_ref();
                }
                return Poll::Pending;
            }

            check_stack(state, nresults + 1)?;
            ffi::lua_xmove(thread_state, state, nresults);

            Poll::Ready(R::from_stack_multi(nresults, &lua))
        }
    }
}

#[cfg(feature = "async")]
#[inline(always)]
unsafe fn is_poll_pending(state: *mut ffi::lua_State) -> bool {
    ffi::lua_tolightuserdata(state, -1) == crate::Lua::poll_pending().0
}

#[cfg(feature = "async")]
struct WakerGuard<'lua, 'a> {
    lua: &'lua RawLua,
    prev: NonNull<Waker>,
    _phantom: PhantomData<&'a ()>,
}

#[cfg(feature = "async")]
impl<'lua, 'a> WakerGuard<'lua, 'a> {
    #[inline]
    pub fn new(lua: &'lua RawLua, waker: &'a Waker) -> Result<WakerGuard<'lua, 'a>> {
        let prev = lua.set_waker(NonNull::from(waker));
        Ok(WakerGuard {
            lua,
            prev,
            _phantom: PhantomData,
        })
    }
}

#[cfg(feature = "async")]
impl Drop for WakerGuard<'_, '_> {
    fn drop(&mut self) {
        self.lua.set_waker(self.prev);
    }
}

#[cfg(test)]
mod assertions {
    use super::*;

    #[cfg(not(feature = "send"))]
    static_assertions::assert_not_impl_any!(Thread: Send);
    #[cfg(feature = "send")]
    static_assertions::assert_impl_all!(Thread: Send, Sync);
    #[cfg(all(feature = "async", not(feature = "send")))]
    static_assertions::assert_not_impl_any!(AsyncThread<()>: Send);
    #[cfg(all(feature = "async", feature = "send"))]
    static_assertions::assert_impl_all!(AsyncThread<()>: Send, Sync);
}

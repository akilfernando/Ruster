@tool
extends EditorPlugin

const OUTPUT := "/tmp/ruster-m9-godot-reference/inspector.png"

func _enter_tree() -> void:
    if DisplayServer.get_name() == "headless":
        return
    call_deferred("_capture")

func _capture() -> void:
    # Let scene loading and editor layout settle before choosing the node.
    for i in range(90):
        await get_tree().process_frame
    var scene := EditorInterface.get_edited_scene_root()
    if scene == null or not scene.has_node("ReferenceCube"):
        printerr("CAPTURE_FAILED: expected scene and ReferenceCube were not loaded")
        get_tree().quit(2)
        return
    var node := scene.get_node("ReferenceCube")
    var selection := EditorInterface.get_selection()
    selection.clear()
    selection.add_node(node)
    EditorInterface.edit_node(node)
    for i in range(120):
        await get_tree().process_frame
    var viewport := EditorInterface.get_base_control().get_viewport()
    var texture := viewport.get_texture()
    if texture == null:
        printerr("CAPTURE_FAILED: editor viewport texture unavailable")
        get_tree().quit(3)
        return
    var image := texture.get_image()
    if image == null or image.is_empty():
        printerr("CAPTURE_FAILED: editor viewport image empty")
        get_tree().quit(4)
        return
    var error := image.save_png(OUTPUT)
    if error != OK:
        printerr("CAPTURE_FAILED: save_png error ", error)
        get_tree().quit(5)
        return
    print("CAPTURE_OK ", OUTPUT, " ", image.get_size())
    get_tree().quit(0)

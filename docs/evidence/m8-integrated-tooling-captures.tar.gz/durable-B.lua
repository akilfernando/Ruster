-- stage2 saved A
-- Properties: speed (Number), enabled (Bool), target (ObjectRef).
return {
    ---@param transform RusterTransform
    ---@param props RusterProps_ffa6a744d78d28386438b4a8e8ee32f56718633735057b1b5ddfb5d224d45d98
    ---@param dt number
    ---@param host RusterHost
    ---@return RusterTransform
    update = function(transform, props, dt, host)
        if not props.enabled then return transform end
        local target = host.resolve(props.target)
        if not target then return transform end
        local distance = target.translation[1] - transform.translation[1]
        local step = math.max(0, props.speed) * dt
        transform.translation[1] = transform.translation[1]
            + math.min(step, math.max(-step, distance))
        return transform
    end
}

-- stage2 unsaved export B

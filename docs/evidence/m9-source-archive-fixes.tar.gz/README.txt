M9 first source-archive rehearsal failures and owning-tool corrections,2026-11-05.
Original eval1 manifest/inventory bytes retained; actual source artifact stays outside repository.
Logs retain Gitless-checker and missing ignored vendor-lock export failures, export test red/green and final full-gate pass.
Private absolute source/candidate/evaluation paths replaced with documented placeholders; original log hashes retained.
Patch identifies four changed tooling/test files; no engine/vendor/runtime source change or source-copy workaround.
Full checker includes176Rust/22Python tests plus lint/format/docs; one existingGPU-only test ignored.
No source archive, binary, cache, user state, credentials or desktop information bundled.

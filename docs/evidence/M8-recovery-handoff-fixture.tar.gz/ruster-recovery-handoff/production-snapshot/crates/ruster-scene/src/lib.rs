//! Application-neutral authored objects; no logistics, player or runtime state.
//!
//! Public values permit code-first construction. Call `validate` at ingestion;
//! [`Session`] validates transactional edits and owns bounded persisted history.

use std::collections::{BTreeMap, HashSet};
use std::ffi::OsString;
use std::fmt;
use std::fs::{File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};

pub const FORMAT_VERSION: u32 = 5;

mod authoring;
mod strict_json;
pub use authoring::*;
pub const MAX_OBJECTS: usize = 256;
pub const MAX_FILE_BYTES: u64 = 1024 * 1024;
pub const HISTORY_LIMIT: usize = 32;

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Transform {
    pub translation: [f32; 3],
    /// Euler rotation in radians, fixed-axis X then Y then Z (world qz*qy*qx).
    pub rotation: [f32; 3],
    pub scale: [f32; 3],
}

impl Default for Transform {
    fn default() -> Self {
        Self {
            translation: [0.0; 3],
            rotation: [0.0; 3],
            scale: [1.0; 3],
        }
    }
}

impl Transform {
    pub fn validate(&self) -> Result<(), SceneError> {
        if !self
            .translation
            .iter()
            .all(|x| x.is_finite() && x.abs() <= 10_000.0)
            || !self
                .rotation
                .iter()
                .all(|x| x.is_finite() && x.abs() <= 10_000.0)
            || !self
                .scale
                .iter()
                .all(|x| x.is_finite() && *x >= 0.001 && *x <= 1_000.0)
        {
            return Err(SceneError::Invalid("transform requires finite translation ±10000, rotation ±10000 radians and scale 0.001..1000".into()));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Object {
    pub id: String,
    /// Optional display label; identity remains immutable and references use `id`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    pub transform: Transform,
    /// Linear RGBA channels in 0..=1.
    pub color: [f32; 4],
    /// Stable asset ID; None selects the procedural unit cube.
    /// Asset existence is checked by the asset/editor boundary, not this crate.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mesh: Option<String>,
}

impl Object {
    pub fn cube(id: impl Into<String>, name: Option<String>) -> Self {
        Self {
            id: id.into(),
            name,
            transform: Transform::default(),
            color: [0.6, 0.6, 0.6, 1.0],
            mesh: None,
        }
    }
    pub fn display_name(&self) -> &str {
        self.name.as_deref().unwrap_or(&self.id)
    }
    pub fn validate(&self) -> Result<(), SceneError> {
        validate_id(&self.id)?;
        validate_name(self.name.as_deref())?;
        self.transform.validate()?;
        if let Some(mesh) = &self.mesh {
            validate_id(mesh)?;
        }
        if !self
            .color
            .iter()
            .all(|x| x.is_finite() && (0.0..=1.0).contains(x))
        {
            return Err(SceneError::Invalid(
                "color channels must be finite in 0..=1".into(),
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Scene {
    pub id: String,
    pub revision: u64,
    pub objects: Vec<Object>,
}

impl Scene {
    pub fn empty(id: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            revision: 0,
            objects: Vec::new(),
        }
    }

    pub fn demo() -> Self {
        Self {
            id: "procedural-demo".into(),
            revision: 0,
            objects: [
                ("left", [-2.0, 0.0, 0.0], [0.12, 0.58, 0.85, 1.0]),
                ("center", [0.0, 0.0, 0.0], [0.9, 0.4, 0.16, 1.0]),
                ("right", [2.0, 0.0, 0.0], [0.3, 0.75, 0.45, 1.0]),
            ]
            .into_iter()
            .map(|(id, translation, color)| Object {
                id: id.into(),
                name: None,
                transform: Transform {
                    translation,
                    ..Transform::default()
                },
                color,
                mesh: None,
            })
            .collect(),
        }
    }

    pub fn validate(&self) -> Result<(), SceneError> {
        validate_id(&self.id)?;
        if self.objects.len() > MAX_OBJECTS {
            return Err(SceneError::Invalid(format!(
                "scene exceeds {MAX_OBJECTS} objects"
            )));
        }
        let mut ids = HashSet::new();
        for object in &self.objects {
            validate_id(&object.id)?;
            if !ids.insert(&object.id) {
                return Err(SceneError::Invalid(format!(
                    "duplicate object id {}",
                    object.id
                )));
            }
            object.validate()?;
        }
        Ok(())
    }

    /// Deterministic noncryptographic FNV-1a checksum of canonical JSON field order.
    /// Fixed-size comparison evidence, never an integrity/security boundary.
    pub fn fingerprint(&self) -> String {
        let bytes = serde_json::to_vec(self).expect("Scene fields serialize to JSON");
        let hash = bytes.into_iter().fold(0xcbf29ce484222325u64, |hash, byte| {
            (hash ^ u64::from(byte)).wrapping_mul(0x100000001b3)
        });
        format!("{hash:016x}")
    }

    pub fn load(path: impl AsRef<Path>) -> Result<Self, SceneError> {
        let document = Document::load(path.as_ref())?;
        if !document.authoring.is_empty()
            || document
                .undo
                .iter()
                .chain(&document.redo)
                .any(Change::has_authoring)
        {
            return Err(SceneError::Invalid("document contains behavior authoring; use Session::open and an authoring-aware runtime, or explicitly export Session::scene() as geometry".into()));
        }
        Ok(document.scene)
    }

    /// Atomic replacement; caller manages concurrency. History starts empty.
    /// Prefer Session::save when authoring or sharing a file with other writers.
    pub fn save(&self, path: impl AsRef<Path>) -> Result<(), SceneError> {
        Document::new(self.clone()).write(path.as_ref(), false)
    }
}

fn validate_name(name: Option<&str>) -> Result<(), SceneError> {
    if name.is_some_and(|n| {
        n.is_empty() || n.len() > 128 || n.trim() != n || n.chars().any(char::is_control)
    }) {
        return Err(SceneError::Invalid("display name requires 1..128 UTF-8 bytes without surrounding whitespace or control characters".into()));
    }
    Ok(())
}

fn validate_id(id: &str) -> Result<(), SceneError> {
    if id.is_empty()
        || id.len() > 128
        || !id
            .bytes()
            .all(|c| c.is_ascii_alphanumeric() || b"-_.".contains(&c))
    {
        return Err(SceneError::Invalid(
            "id requires 1..128 ASCII letters, digits, '-', '_' or '.'".into(),
        ));
    }
    Ok(())
}

#[derive(Debug)]
pub enum SceneError {
    Io(std::io::Error),
    Format(serde_json::Error),
    UnsupportedVersion(u64),
    Invalid(String),
    /// The validated authored payload and required history exceed the serialized budget.
    Capacity,
    StaleRevision {
        expected: u64,
        actual: u64,
    },
    RevisionOverflow,
    TickOverflow,
    ObjectNotFound(String),
    NoUndo,
    NoRedo,
    Conflict,
    Busy,
}

impl fmt::Display for SceneError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Io(error) => write!(f, "scene I/O failed: {error}"),
            Self::Format(error) => write!(f, "invalid scene JSON: {error}"),
            Self::UnsupportedVersion(version) => write!(
                f,
                "unsupported scene version {version}; supported versions are 1 through {FORMAT_VERSION}"
            ),
            Self::Invalid(reason) => write!(f, "invalid scene: {reason}"),
            Self::Capacity => write!(f, "authored state and required reversible history exceed 1 MiB; reduce content or edit size before retrying"),
            Self::StaleRevision { expected, actual } => write!(
                f,
                "stale revision: expected {expected}, current {actual}; inspect and retry"
            ),
            Self::TickOverflow => write!(f, "preview tick exhausted; no step applied"),
            Self::RevisionOverflow => write!(f, "scene revision exhausted; no change applied"),
            Self::ObjectNotFound(id) => write!(f, "object {id} does not exist"),
            Self::NoUndo => write!(f, "no authored change to undo"),
            Self::NoRedo => write!(f, "no authored change to redo"),
            Self::Conflict => write!(
                f,
                "scene changed on disk or destination exists; reopen or save to a new path"
            ),
            Self::Busy => write!(
                f,
                "scene is busy in another cooperating writer; retry later"
            ),
        }
    }
}
impl std::error::Error for SceneError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Io(e) => Some(e),
            Self::Format(e) => Some(e),
            _ => None,
        }
    }
}
impl From<std::io::Error> for SceneError {
    fn from(e: std::io::Error) -> Self {
        Self::Io(e)
    }
}
impl From<serde_json::Error> for SceneError {
    fn from(e: serde_json::Error) -> Self {
        Self::Format(e)
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct TransformDelta {
    id: String,
    before: Transform,
    after: Transform,
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct IndexedObject {
    object: Object,
    index: usize,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
enum SceneDelta {
    Transforms {
        changes: Vec<TransformDelta>,
    },
    Objects {
        created: Vec<IndexedObject>,
        deleted: Vec<IndexedObject>,
    },
    Create {
        object: Object,
        index: usize,
    },
    Delete {
        object: Object,
        index: usize,
    },
    Name {
        id: String,
        before: Option<String>,
        after: Option<String>,
    },
    Transform {
        id: String,
        before: Transform,
        after: Transform,
    },
    Mesh {
        id: String,
        before: Option<String>,
        after: Option<String>,
    },
}

impl SceneDelta {
    fn references_asset(&self) -> bool {
        match self {
            Self::Mesh { before, after, .. } => before.is_some() || after.is_some(),
            Self::Create { object, .. } | Self::Delete { object, .. } => object.mesh.is_some(),
            Self::Objects { created, deleted } => created
                .iter()
                .chain(deleted)
                .any(|e| e.object.mesh.is_some()),
            _ => false,
        }
    }
    fn contains_id(&self, id: &str) -> bool {
        match self {
            Self::Create { object, .. } | Self::Delete { object, .. } => object.id == id,
            Self::Name { id: old, .. }
            | Self::Transform { id: old, .. }
            | Self::Mesh { id: old, .. } => old == id,
            Self::Transforms { changes } => changes.iter().any(|e| e.id == id),
            Self::Objects { created, deleted } => {
                created.iter().chain(deleted).any(|e| e.object.id == id)
            }
        }
    }
    fn apply(&self, scene: &mut Scene, undo: bool) -> Result<(), SceneError> {
        let inconsistent = || SceneError::Invalid("inconsistent authored history".into());
        match self {
            Self::Transforms { changes } => {
                if changes.is_empty() || changes.len() > MAX_OBJECTS {
                    return Err(inconsistent());
                }
                let mut ids = HashSet::new();
                for c in changes {
                    if !ids.insert(&c.id) {
                        return Err(inconsistent());
                    }
                    Self::Transform {
                        id: c.id.clone(),
                        before: c.before.clone(),
                        after: c.after.clone(),
                    }
                    .apply(scene, undo)?;
                }
            }
            Self::Objects { created, deleted } => {
                if (created.is_empty() == deleted.is_empty())
                    || created.len() + deleted.len() > MAX_OBJECTS
                {
                    return Err(inconsistent());
                }
                let entries = if created.is_empty() { deleted } else { created };
                let mut ids = HashSet::new();
                for (i, e) in entries.iter().enumerate() {
                    e.object.validate()?;
                    if !ids.insert(&e.object.id) || i > 0 && entries[i - 1].index >= e.index {
                        return Err(inconsistent());
                    }
                }
                let insert = !created.is_empty() != undo;
                if insert {
                    for e in entries {
                        Self::Create {
                            object: e.object.clone(),
                            index: e.index,
                        }
                        .apply(scene, false)?;
                    }
                } else {
                    for e in entries.iter().rev() {
                        Self::Delete {
                            object: e.object.clone(),
                            index: e.index,
                        }
                        .apply(scene, false)?;
                    }
                }
            }
            Self::Create { object, index } | Self::Delete { object, index } => {
                object.validate()?;
                let insert = matches!(self, Self::Create { .. }) != undo;
                if insert {
                    if scene.objects.len() >= MAX_OBJECTS
                        || *index > scene.objects.len()
                        || scene.objects.iter().any(|o| o.id == object.id)
                    {
                        return Err(inconsistent());
                    }
                    scene.objects.insert(*index, object.clone());
                } else {
                    if scene.objects.get(*index) != Some(object) {
                        return Err(inconsistent());
                    }
                    scene.objects.remove(*index);
                }
            }
            Self::Name { id, before, after } => {
                validate_id(id)?;
                validate_name(before.as_deref())?;
                validate_name(after.as_deref())?;
                let object = scene
                    .objects
                    .iter_mut()
                    .find(|o| &o.id == id)
                    .ok_or_else(inconsistent)?;
                let (expected, replacement) = if undo {
                    (after, before)
                } else {
                    (before, after)
                };
                if before == after || &object.name != expected {
                    return Err(inconsistent());
                }
                object.name = replacement.clone();
            }
            Self::Transform { id, before, after } => {
                validate_id(id)?;
                before.validate()?;
                after.validate()?;
                let object = scene
                    .objects
                    .iter_mut()
                    .find(|o| &o.id == id)
                    .ok_or_else(inconsistent)?;
                let (expected, replacement) = if undo {
                    (after, before)
                } else {
                    (before, after)
                };
                if before == after || &object.transform != expected {
                    return Err(inconsistent());
                }
                object.transform = replacement.clone();
            }
            Self::Mesh { id, before, after } => {
                validate_id(id)?;
                for mesh in [before, after].into_iter().flatten() {
                    validate_id(mesh)?;
                }
                let object = scene
                    .objects
                    .iter_mut()
                    .find(|o| &o.id == id)
                    .ok_or_else(inconsistent)?;
                let (expected, replacement) = if undo {
                    (after, before)
                } else {
                    (before, after)
                };
                if before == after || &object.mesh != expected {
                    return Err(inconsistent());
                }
                object.mesh = replacement.clone();
            }
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ValueDelta<T> {
    id: String,
    before: Option<T>,
    after: Option<T>,
}
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Change {
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    scene: Vec<SceneDelta>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    sources: Vec<ValueDelta<BehaviorSource>>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    bindings: Vec<ValueDelta<BehaviorBinding>>,
}
impl From<SceneDelta> for Change {
    fn from(delta: SceneDelta) -> Self {
        Self {
            scene: vec![delta],
            ..Self::default()
        }
    }
}
fn apply_values<T: Clone + PartialEq>(
    deltas: &[ValueDelta<T>],
    values: &mut BTreeMap<String, T>,
    undo: bool,
) -> Result<(), SceneError> {
    let mut ids = HashSet::new();
    for delta in deltas {
        validate_id(&delta.id)?;
        let (expected, replacement) = if undo {
            (&delta.after, &delta.before)
        } else {
            (&delta.before, &delta.after)
        };
        if !ids.insert(&delta.id)
            || delta.before == delta.after
            || values.get(&delta.id) != expected.as_ref()
        {
            return Err(SceneError::Invalid(
                "inconsistent authored value history".into(),
            ));
        }
        if let Some(value) = replacement {
            values.insert(delta.id.clone(), value.clone());
        } else {
            values.remove(&delta.id);
        }
    }
    Ok(())
}
impl Change {
    fn has_authoring(&self) -> bool {
        !self.sources.is_empty() || !self.bindings.is_empty()
    }
    fn references_asset(&self) -> bool {
        self.scene.iter().any(SceneDelta::references_asset)
            || self
                .bindings
                .iter()
                .flat_map(|d| [&d.before, &d.after])
                .flatten()
                .any(|b| {
                    b.properties
                        .values()
                        .any(|v| matches!(v, PropertyValue::AssetRef(Some(_))))
                })
    }
    fn object_ids(&self) -> impl Iterator<Item = &str> {
        self.bindings
            .iter()
            .flat_map(|d| [&d.before, &d.after])
            .flatten()
            .flat_map(|b| {
                std::iter::once(b.object_id.as_str()).chain(b.properties.values().filter_map(|v| {
                    match v {
                        PropertyValue::ObjectRef(Some(id)) => Some(id.as_str()),
                        _ => None,
                    }
                }))
            })
    }
    fn contains_id(&self, id: &str) -> bool {
        self.scene.iter().any(|d| d.contains_id(id)) || self.object_ids().any(|used| used == id)
    }
    fn apply(
        &self,
        scene: &mut Scene,
        authoring: &mut Authoring,
        undo: bool,
    ) -> Result<(), SceneError> {
        if self.scene.is_empty() && !self.has_authoring()
            || self.scene.len() > MAX_OBJECTS
            || self.sources.len() > MAX_SOURCES
            || self.bindings.len() > MAX_BINDINGS
        {
            return Err(SceneError::Invalid(
                "empty or oversized authored history change".into(),
            ));
        }
        if undo {
            for delta in self.scene.iter().rev() {
                delta.apply(scene, true)?;
            }
        } else {
            for delta in &self.scene {
                delta.apply(scene, false)?;
            }
        }
        // All three sections form one atomic authored state. Validate only after all apply.
        apply_values(&self.sources, &mut authoring.sources, undo)?;
        apply_values(&self.bindings, &mut authoring.bindings, undo)?;
        scene.validate()?;
        authoring.validate(scene)
    }
}

// Decode v1 through its exact schema: even `mesh: null` must be rejected.
// Its untagged transform history is migrated without losing undo or redo.
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct LegacyObject {
    id: String,
    transform: Transform,
    color: [f32; 4],
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct LegacyScene {
    id: String,
    revision: u64,
    objects: Vec<LegacyObject>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct LegacySceneDelta {
    id: String,
    before: Transform,
    after: Transform,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct LegacyDocument {
    format: String,
    format_version: u32,
    scene: LegacyScene,
    undo: Vec<LegacySceneDelta>,
    redo: Vec<LegacySceneDelta>,
}
impl From<LegacyDocument> for Document {
    fn from(old: LegacyDocument) -> Self {
        let migrate = |change: LegacySceneDelta| SceneDelta::Transform {
            id: change.id,
            before: change.before,
            after: change.after,
        };
        Self {
            format: old.format,
            format_version: old.format_version,
            scene: Scene {
                id: old.scene.id,
                revision: old.scene.revision,
                objects: old
                    .scene
                    .objects
                    .into_iter()
                    .map(|o| Object {
                        id: o.id,
                        name: None,
                        transform: o.transform,
                        color: o.color,
                        mesh: None,
                    })
                    .collect(),
            },
            authoring: Authoring::default(),
            undo: old
                .undo
                .into_iter()
                .map(migrate)
                .map(Change::from)
                .collect(),
            redo: old
                .redo
                .into_iter()
                .map(migrate)
                .map(Change::from)
                .collect(),
        }
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct V2Object {
    id: String,
    transform: Transform,
    color: [f32; 4],
    #[serde(default)]
    mesh: Option<String>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct V2Scene {
    id: String,
    revision: u64,
    objects: Vec<V2Object>,
}
#[derive(Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
enum V2SceneDelta {
    Transform {
        id: String,
        before: Transform,
        after: Transform,
    },
    Mesh {
        id: String,
        before: Option<String>,
        after: Option<String>,
    },
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct V2Document {
    format: String,
    format_version: u32,
    scene: V2Scene,
    undo: Vec<V2SceneDelta>,
    redo: Vec<V2SceneDelta>,
}
impl From<V2Document> for Document {
    fn from(old: V2Document) -> Self {
        let migrate = |c| match c {
            V2SceneDelta::Transform { id, before, after } => {
                SceneDelta::Transform { id, before, after }
            }
            V2SceneDelta::Mesh { id, before, after } => SceneDelta::Mesh { id, before, after },
        };
        Self {
            format: old.format,
            format_version: old.format_version,
            scene: Scene {
                id: old.scene.id,
                revision: old.scene.revision,
                objects: old
                    .scene
                    .objects
                    .into_iter()
                    .map(|o| Object {
                        id: o.id,
                        name: None,
                        transform: o.transform,
                        color: o.color,
                        mesh: o.mesh,
                    })
                    .collect(),
            },
            authoring: Authoring::default(),
            undo: old
                .undo
                .into_iter()
                .map(migrate)
                .map(Change::from)
                .collect(),
            redo: old
                .redo
                .into_iter()
                .map(migrate)
                .map(Change::from)
                .collect(),
        }
    }
}

// Exact pre-authoring envelope and history: future fields are rejected, including null.
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct V4Document {
    format: String,
    format_version: u32,
    scene: Scene,
    undo: Vec<SceneDelta>,
    redo: Vec<SceneDelta>,
}
impl From<V4Document> for Document {
    fn from(old: V4Document) -> Self {
        Self {
            format: old.format,
            format_version: old.format_version,
            scene: old.scene,
            authoring: Authoring::default(),
            undo: old.undo.into_iter().map(Change::from).collect(),
            redo: old.redo.into_iter().map(Change::from).collect(),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Document {
    format: String,
    format_version: u32,
    scene: Scene,
    #[serde(default, skip_serializing_if = "Authoring::is_empty")]
    authoring: Authoring,
    undo: Vec<Change>,
    redo: Vec<Change>,
}
impl Document {
    fn new(scene: Scene) -> Self {
        Self {
            format: "ruster-scene".into(),
            format_version: FORMAT_VERSION,
            scene,
            authoring: Authoring::default(),
            undo: Vec::new(),
            redo: Vec::new(),
        }
    }
    fn validate(&self) -> Result<(), SceneError> {
        self.scene.validate()?;
        self.authoring.validate(&self.scene)?;
        if self.undo.len() + self.redo.len() > HISTORY_LIMIT {
            return Err(SceneError::Invalid(format!(
                "history exceeds {HISTORY_LIMIT} changes"
            )));
        }
        check_serialized_size(
            &self.scene,
            &self.authoring,
            &self.undo.iter().collect::<Vec<_>>(),
            &self.redo.iter().collect::<Vec<_>>(),
        )
    }
    fn load(path: &Path) -> Result<Self, SceneError> {
        reject_nonregular(path)?;
        let mut bytes = Vec::new();
        File::open(path)?
            .take(MAX_FILE_BYTES + 1)
            .read_to_end(&mut bytes)?;
        Self::decode(&bytes)
    }
    fn decode(bytes: &[u8]) -> Result<Self, SceneError> {
        if bytes.len() as u64 > MAX_FILE_BYTES {
            return Err(SceneError::Invalid("file exceeds 1 MiB".into()));
        }
        let value = strict_json::parse(bytes)?;
        if value.get("format").and_then(|v| v.as_str()) != Some("ruster-scene") {
            return Err(SceneError::Invalid("expected ruster-scene format; logistics v1 scenarios remain a separate format and are not migrated".into()));
        }
        let version = value
            .get("format_version")
            .and_then(|v| v.as_u64())
            .ok_or_else(|| SceneError::Invalid("format_version must be an integer".into()))?;
        let document: Self = match version {
            1 => serde_json::from_value::<LegacyDocument>(value)?.into(),
            2 => serde_json::from_value::<V2Document>(value)?.into(),
            3 | 4 => serde_json::from_value::<V4Document>(value)?.into(),
            5 => serde_json::from_value(value)?,
            _ => return Err(SceneError::UnsupportedVersion(version)),
        };
        if version == 3
            && document.undo.iter().chain(&document.redo).any(|c| {
                c.scene.iter().any(|d| {
                    matches!(
                        d,
                        SceneDelta::Transforms { .. } | SceneDelta::Objects { .. }
                    )
                })
            })
        {
            return Err(SceneError::Invalid(
                "scene v3 does not support grouped history".into(),
            ));
        }
        document.validate()?;
        Ok(document)
    }
    fn encode(&self) -> Result<Vec<u8>, SceneError> {
        self.validate()?;
        let mut upgraded = self.clone();
        upgraded.format_version = FORMAT_VERSION;
        let mut bytes = serde_json::to_vec(&upgraded)?;
        bytes.push(b'\n');
        if bytes.len() as u64 > MAX_FILE_BYTES {
            return Err(SceneError::Capacity);
        }
        Ok(bytes)
    }
    fn write(&self, path: &Path, create_new: bool) -> Result<(), SceneError> {
        reject_nonregular(path)?;
        let bytes = self.encode()?;
        let parent = path
            .parent()
            .filter(|p| !p.as_os_str().is_empty())
            .unwrap_or_else(|| Path::new("."));
        let mut temporary = tempfile::NamedTempFile::new_in(parent)?;
        temporary.write_all(&bytes)?;
        temporary.flush()?;
        temporary.as_file().sync_all()?;
        if create_new {
            temporary.persist_noclobber(path).map_err(|e| {
                if e.error.kind() == std::io::ErrorKind::AlreadyExists {
                    SceneError::Conflict
                } else {
                    SceneError::Io(e.error)
                }
            })?;
        } else {
            temporary
                .persist(path)
                .map_err(|e| SceneError::Io(e.error))?;
        }
        Ok(())
    }
}

// Count history once and reserve the largest scene reachable through Undo/Redo.
// This includes restored deleted objects/sources and maximum revision width.
// Compact encoding is shared with the writer; concatenating stacks is conservative.
fn check_serialized_size(
    scene: &Scene,
    authoring: &Authoring,
    undo: &[&Change],
    redo: &[&Change],
) -> Result<(), SceneError> {
    #[derive(Serialize)]
    struct SceneView<'a> {
        id: &'a str,
        revision: u64,
        objects: &'a [Object],
    }
    impl<'a> From<&'a Scene> for SceneView<'a> {
        fn from(scene: &'a Scene) -> Self {
            Self {
                id: &scene.id,
                revision: u64::MAX,
                objects: &scene.objects,
            }
        }
    }
    #[derive(Serialize)]
    struct SceneOnly<'a> {
        scene: SceneView<'a>,
        #[serde(skip_serializing_if = "Authoring::is_empty")]
        authoring: &'a Authoring,
    }
    #[derive(Serialize)]
    struct View<'a> {
        format: &'static str,
        format_version: u32,
        scene: SceneView<'a>,
        #[serde(skip_serializing_if = "Authoring::is_empty")]
        authoring: &'a Authoring,
        undo: &'a [&'a Change],
        redo: &'a [&'a Change],
    }
    struct Counter {
        bytes: u64,
        exceeded: bool,
    }
    impl Write for Counter {
        fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
            self.bytes += bytes.len() as u64;
            if self.bytes > MAX_FILE_BYTES {
                self.exceeded = true;
                return Err(std::io::Error::other("serialized scene exceeds 1 MiB"));
            }
            Ok(bytes.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    fn size(value: &impl Serialize) -> Result<u64, SceneError> {
        let mut counter = Counter {
            bytes: 0,
            exceeded: false,
        };
        if let Err(error) = serde_json::to_writer(&mut counter, value) {
            return Err(if counter.exceeded {
                SceneError::Capacity
            } else {
                SceneError::Format(error)
            });
        }
        Ok(counter.bytes)
    }
    let all: Vec<_> = undo.iter().chain(redo).copied().collect();
    let envelope = size(&View {
        format: "ruster-scene",
        format_version: FORMAT_VERSION,
        scene: scene.into(),
        authoring,
        undo: &all,
        redo: &[],
    })?;
    // Wrapper constant bytes cancel when replacing the current authored payload.
    let current = size(&SceneOnly {
        scene: scene.into(),
        authoring,
    })?;
    let mut largest = current;
    for (history, reversing) in [(undo, true), (redo, false)] {
        let mut candidate = scene.clone();
        let mut candidate_authoring = authoring.clone();
        for change in history.iter().rev() {
            change.apply(&mut candidate, &mut candidate_authoring, reversing)?;
            candidate.validate()?;
            largest = largest.max(size(&SceneOnly {
                scene: (&candidate).into(),
                authoring: &candidate_authoring,
            })?);
        }
    }
    // Splitting compact stacks removes one comma when both are nonempty, so the
    // concatenated envelope bounds every split. Reserve the writer's final newline.
    if envelope - current + largest + 1 > MAX_FILE_BYTES {
        return Err(SceneError::Capacity);
    }
    Ok(())
}

fn allocate_ids(
    prefix: &str,
    count: usize,
    limit: usize,
    used: HashSet<&str>,
) -> Result<Vec<String>, SceneError> {
    if count > limit {
        return Err(SceneError::Invalid(format!("ID request exceeds{limit}")));
    }
    Ok((1..=used.len() + count)
        .map(|n| format!("{prefix}-{n}"))
        .filter(|id| !used.contains(id.as_str()))
        .take(count)
        .collect())
}

/// Authored state with bounded object, name, transform and mesh deltas. Runtime state belongs elsewhere.
#[derive(Clone, Debug)]
pub struct Session {
    document: Document,
    path: Option<PathBuf>,
    saved: Option<Document>,
    loaded_format_version: u32,
    history_evictions: usize,
}
impl Session {
    pub fn new(scene: Scene) -> Result<Self, SceneError> {
        scene.validate()?;
        let document = Document::new(scene);
        document.validate()?;
        Ok(Self {
            document,
            path: None,
            saved: None,
            loaded_format_version: FORMAT_VERSION,
            history_evictions: 0,
        })
    }
    pub fn open(path: impl AsRef<Path>) -> Result<Self, SceneError> {
        let lock = SceneLock::acquire(path.as_ref())?;
        let document = Document::load(&lock.path)?;
        Ok(Self {
            loaded_format_version: document.format_version,
            history_evictions: 0,
            saved: Some(document.clone()),
            document,
            path: Some(lock.path.clone()),
        })
    }
    /// Complete admitted authored document without changing save authority or history.
    pub fn snapshot_bytes(&self) -> Result<Vec<u8>, SceneError> {
        self.document.encode()
    }
    /// Restore a validated snapshot as an unsaved copy, never bound to its origin.
    pub fn from_snapshot_bytes(bytes: &[u8]) -> Result<Self, SceneError> {
        let document = Document::decode(bytes)?;
        Ok(Self {
            loaded_format_version: document.format_version,
            document,
            path: None,
            saved: None,
            history_evictions: 0,
        })
    }
    pub fn scene(&self) -> &Scene {
        &self.document.scene
    }
    pub fn authoring(&self) -> &Authoring {
        &self.document.authoring
    }
    pub fn source(&self, id: &str) -> Option<&BehaviorSource> {
        self.authoring().sources.get(id)
    }
    pub fn binding(&self, id: &str) -> Option<&BehaviorBinding> {
        self.authoring().bindings.get(id)
    }
    pub fn inspect_sources(&self, offset: usize, limit: usize) -> AuthoringPage<SourceSummary> {
        authoring::page(
            self.authoring()
                .sources
                .iter()
                .map(|(id, s)| SourceSummary {
                    id: id.clone(),
                    label: s.label.clone(),
                    language_id: s.language_id.clone(),
                    host_api_version: s.host_api_version,
                    text_bytes: s.text.len(),
                }),
            offset,
            limit,
        )
    }
    pub fn inspect_bindings(&self, offset: usize, limit: usize) -> AuthoringPage<BindingSummary> {
        authoring::page(
            self.authoring()
                .bindings
                .iter()
                .map(|(id, b)| BindingSummary {
                    id: id.clone(),
                    object_id: b.object_id.clone(),
                    source_id: b.source_id.clone(),
                    enabled: b.enabled,
                    property_count: b.properties.len(),
                }),
            offset,
            limit,
        )
    }
    /// Structural diagnostics only. Backend/schema/asset availability belongs to their owning hosts.
    pub fn authoring_diagnostics(
        &self,
        offset: usize,
        limit: usize,
    ) -> AuthoringPage<AuthoringDiagnostic> {
        let mut diagnostics = Vec::new();
        for (id, b) in &self.authoring().bindings {
            if !self.authoring().sources.contains_key(&b.source_id) {
                diagnostics.push(AuthoringDiagnostic {
                    code: AuthoringDiagnosticCode::MissingSource,
                    binding_id: id.clone(),
                    property: None,
                    reference_id: b.source_id.clone(),
                });
            }
            for (name, value) in &b.properties {
                if let PropertyValue::ObjectRef(Some(target)) = value {
                    if !self.scene().objects.iter().any(|o| &o.id == target) {
                        diagnostics.push(AuthoringDiagnostic {
                            code: AuthoringDiagnosticCode::MissingObjectReference,
                            binding_id: id.clone(),
                            property: Some(name.clone()),
                            reference_id: target.clone(),
                        });
                    }
                }
            }
        }
        authoring::page(diagnostics.into_iter(), offset, limit)
    }
    /// Explicit upsert of a stable source identity; broken/unknown-language text is saveable.
    pub fn set_source(
        &mut self,
        expected_revision: u64,
        id: &str,
        source: Option<BehaviorSource>,
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        validate_id(id)?;
        if let Some(source) = &source {
            source.validate()?;
        }
        let before = self.source(id).cloned();
        if before == source {
            return Ok(self.scene().revision);
        }
        self.commit_change(Change {
            sources: vec![ValueDelta {
                id: id.into(),
                before,
                after: source,
            }],
            ..Change::default()
        })
    }
    /// Explicit upsert preserves all supplied property values, independent of source schemas.
    pub fn set_binding(
        &mut self,
        expected_revision: u64,
        id: &str,
        binding: Option<BehaviorBinding>,
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        validate_id(id)?;
        if let Some(binding) = &binding {
            binding.validate()?;
        }
        let before = self.binding(id).cloned();
        if before == binding {
            return Ok(self.scene().revision);
        }
        self.commit_change(Change {
            bindings: vec![ValueDelta {
                id: id.into(),
                before,
                after: binding,
            }],
            ..Change::default()
        })
    }
    /// Create a fresh source and its attachment as one revision and Undo step.
    /// Use set_binding to attach an existing source, or set_source for explicit repair.
    pub fn create_behavior(
        &mut self,
        expected_revision: u64,
        source_id: &str,
        source: BehaviorSource,
        binding_id: &str,
        binding: BehaviorBinding,
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        validate_id(source_id)?;
        validate_id(binding_id)?;
        source.validate()?;
        binding.validate()?;
        if self.contains_source_id(source_id)
            || self.contains_binding_id(binding_id)
            || binding.source_id != source_id
        {
            return Err(SceneError::Invalid("Create behavior requires fresh identities and a binding referencing the new source.".into()));
        }
        self.commit_change(Change {
            sources: vec![ValueDelta {
                id: source_id.into(),
                before: None,
                after: Some(source),
            }],
            bindings: vec![ValueDelta {
                id: binding_id.into(),
                before: None,
                after: Some(binding),
            }],
            ..Change::default()
        })
    }
    fn reserved_source_ids(&self) -> HashSet<&str> {
        let mut used: HashSet<_> = self
            .authoring()
            .sources
            .keys()
            .map(String::as_str)
            .collect();
        used.extend(
            self.authoring()
                .bindings
                .values()
                .map(|b| b.source_id.as_str()),
        );
        for change in self.document.undo.iter().chain(&self.document.redo) {
            used.extend(change.sources.iter().map(|d| d.id.as_str()));
            used.extend(
                change
                    .bindings
                    .iter()
                    .flat_map(|d| [&d.before, &d.after])
                    .flatten()
                    .map(|b| b.source_id.as_str()),
            );
        }
        used
    }
    pub fn contains_source_id(&self, id: &str) -> bool {
        self.reserved_source_ids().contains(id)
    }
    pub fn contains_binding_id(&self, id: &str) -> bool {
        self.authoring().bindings.contains_key(id)
            || self
                .document
                .undo
                .iter()
                .chain(&self.document.redo)
                .any(|c| c.bindings.iter().any(|d| d.id == id))
    }
    pub fn allocate_source_ids(&self, count: usize) -> Result<Vec<String>, SceneError> {
        allocate_ids("source", count, MAX_SOURCES, self.reserved_source_ids())
    }
    pub fn allocate_binding_ids(&self, count: usize) -> Result<Vec<String>, SceneError> {
        let mut used: HashSet<_> = self
            .authoring()
            .bindings
            .keys()
            .map(String::as_str)
            .collect();
        used.extend(
            self.document
                .undo
                .iter()
                .chain(&self.document.redo)
                .flat_map(|c| c.bindings.iter().map(|d| d.id.as_str())),
        );
        allocate_ids("binding", count, MAX_BINDINGS, used)
    }
    fn owned_binding_deletions(&self, ids: &[&str]) -> Vec<ValueDelta<BehaviorBinding>> {
        self.authoring()
            .bindings
            .iter()
            .filter(|(_, b)| ids.contains(&b.object_id.as_str()))
            .map(|(id, b)| ValueDelta {
                id: id.clone(),
                before: Some(b.clone()),
                after: None,
            })
            .collect()
    }
    fn cloned_bindings(
        &self,
        pairs: &[(String, String)],
    ) -> Result<Vec<ValueDelta<BehaviorBinding>>, SceneError> {
        let originals: Vec<_> = pairs
            .iter()
            .flat_map(|(source, target)| {
                self.authoring()
                    .bindings
                    .values()
                    .filter(move |b| &b.object_id == source)
                    .map(move |b| (target, b))
            })
            .collect();
        let ids = self.allocate_binding_ids(originals.len())?;
        Ok(originals
            .into_iter()
            .zip(ids)
            .map(|((target, b), id)| {
                let mut binding = b.clone();
                binding.object_id.clone_from(target);
                for value in binding.properties.values_mut() {
                    if let PropertyValue::ObjectRef(Some(reference)) = value {
                        if let Some((_, replacement)) =
                            pairs.iter().find(|(original, _)| original == reference)
                        {
                            reference.clone_from(replacement);
                        }
                    }
                }
                ValueDelta {
                    id,
                    before: None,
                    after: Some(binding),
                }
            })
            .collect())
    }
    pub fn path(&self) -> Option<&Path> {
        self.path.as_deref()
    }
    /// Source format opened, or the current format after a successful save.
    pub fn loaded_format_version(&self) -> u32 {
        self.loaded_format_version
    }
    pub fn is_dirty(&self) -> bool {
        self.saved.as_ref() != Some(&self.document)
    }
    /// Cumulative oldest Undo entries trimmed by byte pressure in this session.
    /// Does not count ordinary 32-step age eviction; resets on Open/new Session.
    pub fn history_evictions(&self) -> usize {
        self.history_evictions
    }
    pub fn undo_len(&self) -> usize {
        self.document.undo.len()
    }
    pub fn redo_len(&self) -> usize {
        self.document.redo.len()
    }
    /// True when current state or reversible history can resolve an asset ID.
    /// Hosts use this to avoid relocating a scene away from its catalog.
    pub fn has_asset_references(&self) -> bool {
        self.scene().objects.iter().any(|o| o.mesh.is_some())
            || self.document.authoring.has_asset_references()
            || self
                .document
                .undo
                .iter()
                .chain(&self.document.redo)
                .any(Change::references_asset)
    }
    /// IDs retained by reversible history are reserved, preventing accidental identity reuse.
    pub fn contains_object_id(&self, id: &str) -> bool {
        self.scene().objects.iter().any(|o| o.id == id)
            || self.document.authoring.object_ids().any(|used| used == id)
            || self
                .document
                .undo
                .iter()
                .chain(&self.document.redo)
                .any(|c| c.contains_id(id))
    }

    /// Allocate bounded IDs with one transient history scan, including grouped reservations.
    pub fn allocate_object_ids(&self, count: usize) -> Result<Vec<String>, SceneError> {
        if count > MAX_OBJECTS {
            return Err(SceneError::Invalid("ID request exceeds256 objects".into()));
        }
        let mut used: HashSet<&str> = self.scene().objects.iter().map(|o| o.id.as_str()).collect();
        used.extend(self.document.authoring.object_ids());
        for change in self.document.undo.iter().chain(&self.document.redo) {
            used.extend(change.object_ids());
            for delta in &change.scene {
                match delta {
                    SceneDelta::Create { object, .. } | SceneDelta::Delete { object, .. } => {
                        used.insert(&object.id);
                    }
                    SceneDelta::Name { id, .. }
                    | SceneDelta::Transform { id, .. }
                    | SceneDelta::Mesh { id, .. } => {
                        used.insert(id);
                    }
                    SceneDelta::Transforms { changes } => {
                        used.extend(changes.iter().map(|e| e.id.as_str()));
                    }
                    SceneDelta::Objects { created, deleted } => {
                        used.extend(created.iter().chain(deleted).map(|e| e.object.id.as_str()));
                    }
                }
            }
        }
        Ok((1..=used.len() + count)
            .map(|n| format!("object-{n}"))
            .filter(|id| !used.contains(id.as_str()))
            .take(count)
            .collect())
    }

    /// Append a validated object. Its ID cannot collide with current or reversible state.
    pub fn create(&mut self, expected_revision: u64, object: Object) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        self.insert_object(object, self.scene().objects.len())
    }
    fn insert_object(&mut self, object: Object, index: usize) -> Result<u64, SceneError> {
        object.validate()?;
        if self.contains_object_id(&object.id) {
            return Err(SceneError::Invalid(format!(
                "object id {} is already present or reserved by history",
                object.id
            )));
        }
        self.commit_change(SceneDelta::Create { object, index })
    }
    /// Duplicate immediately after the source, preserving its properties and optional name.
    /// A supplied name overrides the source label; object identity is always newly supplied.
    pub fn duplicate(
        &mut self,
        expected_revision: u64,
        source: &str,
        new_id: &str,
        name: Option<String>,
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        let index = self
            .scene()
            .objects
            .iter()
            .position(|o| o.id == source)
            .ok_or_else(|| SceneError::ObjectNotFound(source.into()))?;
        let mut object = self.scene().objects[index].clone();
        object.id = new_id.into();
        if name.is_some() {
            object.name = name;
        }
        object.validate()?;
        if self.contains_object_id(new_id) {
            return Err(SceneError::Invalid(
                "duplicate object ID is present or reserved".into(),
            ));
        }
        let mut change: Change = SceneDelta::Create {
            object,
            index: index + 1,
        }
        .into();
        change.bindings = self.cloned_bindings(&[(source.into(), new_id.into())])?;
        self.commit_change(change)
    }
    /// SceneDelta only the displayed name. None restores the immutable ID as its label.
    pub fn rename(
        &mut self,
        expected_revision: u64,
        id: &str,
        name: Option<String>,
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        validate_name(name.as_deref())?;
        let object = self
            .scene()
            .objects
            .iter()
            .find(|o| o.id == id)
            .ok_or_else(|| SceneError::ObjectNotFound(id.into()))?;
        if object.name == name {
            return Ok(self.scene().revision);
        }
        self.commit_change(SceneDelta::Name {
            id: id.into(),
            before: object.name.clone(),
            after: name,
        })
    }
    pub fn delete(&mut self, expected_revision: u64, id: &str) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        let index = self
            .scene()
            .objects
            .iter()
            .position(|o| o.id == id)
            .ok_or_else(|| SceneError::ObjectNotFound(id.into()))?;
        let mut change: Change = SceneDelta::Delete {
            object: self.scene().objects[index].clone(),
            index,
        }
        .into();
        change.bindings = self.owned_binding_deletions(&[id]);
        self.commit_change(change)
    }
    fn commit_change(&mut self, change: impl Into<Change>) -> Result<u64, SceneError> {
        let change = change.into();
        let next = self
            .scene()
            .revision
            .checked_add(1)
            .ok_or(SceneError::RevisionOverflow)?;
        let mut candidate = self.scene().clone();
        let mut authoring = self.document.authoring.clone();
        change.apply(&mut candidate, &mut authoring, false)?;
        candidate.revision = next;
        candidate.validate()?;
        let age_evictions = usize::from(self.document.undo.len() == HISTORY_LIMIT);
        let mut undo: Vec<_> = self.document.undo.iter().skip(age_evictions).collect();
        undo.push(&change);
        let mut byte_evictions = 0;
        loop {
            match check_serialized_size(&candidate, &authoring, &undo[byte_evictions..], &[]) {
                Ok(()) => break,
                Err(SceneError::Capacity) if byte_evictions + 1 < undo.len() => byte_evictions += 1,
                Err(error) => return Err(error),
            }
        }
        // No mutation occurs until a suffix retaining the newest delta is admitted.
        self.document.scene = candidate;
        self.document.authoring = authoring;
        self.document.undo.drain(..age_evictions + byte_evictions);
        self.history_evictions = self.history_evictions.saturating_add(byte_evictions);
        self.document.undo.push(change);
        self.document.redo.clear();
        Ok(next)
    }
    /// One atomic transform gesture: one revision and one undo entry for all targets.
    pub fn edit_transforms(
        &mut self,
        expected_revision: u64,
        edits: &[(String, Transform)],
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        if edits.len() > MAX_OBJECTS {
            return Err(SceneError::Invalid(
                "transform group exceeds 256 edits".into(),
            ));
        }
        let mut ids = HashSet::new();
        let mut changes = Vec::new();
        for (id, transform) in edits {
            if !ids.insert(id) {
                return Err(SceneError::Invalid("duplicate transform target".into()));
            }
            transform.validate()?;
            let object = self
                .scene()
                .objects
                .iter()
                .find(|o| &o.id == id)
                .ok_or_else(|| SceneError::ObjectNotFound(id.clone()))?;
            if &object.transform != transform {
                changes.push(TransformDelta {
                    id: id.clone(),
                    before: object.transform.clone(),
                    after: transform.clone(),
                });
            }
        }
        if changes.is_empty() {
            return Ok(self.scene().revision);
        }
        self.commit_change(SceneDelta::Transforms { changes })
    }
    /// Append a copied group atomically. IDs must be fresh in current and reversible state.
    pub fn create_many(
        &mut self,
        expected_revision: u64,
        objects: Vec<Object>,
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        if objects.is_empty() {
            return Ok(self.scene().revision);
        }
        if objects.len() > MAX_OBJECTS || self.scene().objects.len() + objects.len() > MAX_OBJECTS {
            return Err(SceneError::Invalid(
                "object group exceeds 256 objects".into(),
            ));
        }
        let mut ids = HashSet::new();
        for object in &objects {
            object.validate()?;
            if !ids.insert(&object.id) || self.contains_object_id(&object.id) {
                return Err(SceneError::Invalid(
                    "new object ID collides with current or reversible state".into(),
                ));
            }
        }
        let start = self.scene().objects.len();
        let created = objects
            .into_iter()
            .enumerate()
            .map(|(i, object)| IndexedObject {
                object,
                index: start + i,
            })
            .collect();
        self.commit_change(SceneDelta::Objects {
            created,
            deleted: Vec::new(),
        })
    }
    /// Delete a selection atomically, retaining its original scene order for undo.
    pub fn delete_many(
        &mut self,
        expected_revision: u64,
        ids: &[String],
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        if ids.is_empty() {
            return Ok(self.scene().revision);
        }
        if ids.len() > MAX_OBJECTS {
            return Err(SceneError::Invalid(
                "object group exceeds 256 objects".into(),
            ));
        }
        let mut unique = HashSet::new();
        let mut deleted = Vec::with_capacity(ids.len());
        for id in ids {
            if !unique.insert(id) {
                return Err(SceneError::Invalid("duplicate deletion target".into()));
            }
            let index = self
                .scene()
                .objects
                .iter()
                .position(|o| &o.id == id)
                .ok_or_else(|| SceneError::ObjectNotFound(id.clone()))?;
            deleted.push(IndexedObject {
                object: self.scene().objects[index].clone(),
                index,
            });
        }
        deleted.sort_unstable_by_key(|e| e.index);
        let mut change: Change = SceneDelta::Objects {
            created: Vec::new(),
            deleted,
        }
        .into();
        change.bindings =
            self.owned_binding_deletions(&ids.iter().map(String::as_str).collect::<Vec<_>>());
        self.commit_change(change)
    }
    /// Copy selected objects in caller order, appending the copies as one undo step.
    pub fn duplicate_many(
        &mut self,
        expected_revision: u64,
        pairs: &[(String, String)],
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        if pairs.len() > MAX_OBJECTS {
            return Err(SceneError::Invalid(
                "object group exceeds 256 objects".into(),
            ));
        }
        let mut sources = HashSet::new();
        let mut objects = Vec::with_capacity(pairs.len());
        for (source, id) in pairs {
            if !sources.insert(source) {
                return Err(SceneError::Invalid("duplicate source in selection".into()));
            }
            let mut object = self
                .scene()
                .objects
                .iter()
                .find(|o| &o.id == source)
                .ok_or_else(|| SceneError::ObjectNotFound(source.clone()))?
                .clone();
            object.id.clone_from(id);
            objects.push(object);
        }
        if objects.is_empty() {
            return Ok(self.scene().revision);
        }
        if self.scene().objects.len() + objects.len() > MAX_OBJECTS {
            return Err(SceneError::Invalid(
                "object group exceeds256 objects".into(),
            ));
        }
        let mut ids = HashSet::new();
        for object in &objects {
            object.validate()?;
            if !ids.insert(&object.id) || self.contains_object_id(&object.id) {
                return Err(SceneError::Invalid(
                    "new object ID collides with current or reversible state".into(),
                ));
            }
        }
        let start = self.scene().objects.len();
        let mut change: Change = SceneDelta::Objects {
            created: objects
                .into_iter()
                .enumerate()
                .map(|(i, object)| IndexedObject {
                    object,
                    index: start + i,
                })
                .collect(),
            deleted: Vec::new(),
        }
        .into();
        change.bindings = self.cloned_bindings(pairs)?;
        self.commit_change(change)
    }
    fn check_revision(&self, expected: u64) -> Result<(), SceneError> {
        let actual = self.scene().revision;
        if expected != actual {
            return Err(SceneError::StaleRevision { expected, actual });
        }
        Ok(())
    }
    pub fn edit(
        &mut self,
        expected_revision: u64,
        id: &str,
        transform: &Transform,
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        transform.validate()?;
        let object = self
            .document
            .scene
            .objects
            .iter()
            .find(|o| o.id == id)
            .ok_or_else(|| SceneError::ObjectNotFound(id.into()))?;
        if &object.transform == transform {
            return Ok(self.document.scene.revision);
        }
        self.commit_change(SceneDelta::Transform {
            id: id.into(),
            before: object.transform.clone(),
            after: transform.clone(),
        })
    }

    /// Assign a syntactically valid stable asset ID, or None for a cube.
    /// Registry lookup belongs to the caller; failed/no-op commands preserve history.
    pub fn set_mesh(
        &mut self,
        expected_revision: u64,
        object_id: &str,
        mesh: Option<String>,
    ) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        if let Some(id) = &mesh {
            validate_id(id)?;
        }
        let object = self
            .document
            .scene
            .objects
            .iter()
            .find(|o| o.id == object_id)
            .ok_or_else(|| SceneError::ObjectNotFound(object_id.into()))?;
        if object.mesh == mesh {
            return Ok(self.document.scene.revision);
        }
        self.commit_change(SceneDelta::Mesh {
            id: object_id.into(),
            before: object.mesh.clone(),
            after: mesh,
        })
    }

    pub fn undo(&mut self, expected_revision: u64) -> Result<u64, SceneError> {
        self.history(expected_revision, true)
    }
    pub fn redo(&mut self, expected_revision: u64) -> Result<u64, SceneError> {
        self.history(expected_revision, false)
    }
    fn history(&mut self, expected_revision: u64, undo: bool) -> Result<u64, SceneError> {
        self.check_revision(expected_revision)?;
        let change = if undo {
            self.document.undo.last().ok_or(SceneError::NoUndo)?
        } else {
            self.document.redo.last().ok_or(SceneError::NoRedo)?
        };
        let next = self
            .scene()
            .revision
            .checked_add(1)
            .ok_or(SceneError::RevisionOverflow)?;
        let mut candidate = self.scene().clone();
        let mut authoring = self.document.authoring.clone();
        change.apply(&mut candidate, &mut authoring, undo)?;
        candidate.revision = next;
        candidate.validate()?;
        // Admission/load already bounded every reachable scene with maximum revision
        // width. Moving this same delta between stacks preserves that invariant.
        let change = if undo {
            self.document.undo.pop().ok_or(SceneError::NoUndo)?
        } else {
            self.document.redo.pop().ok_or(SceneError::NoRedo)?
        };
        self.document.scene = candidate;
        self.document.authoring = authoring;
        if undo {
            self.document.redo.push(change);
        } else {
            self.document.undo.push(change);
        }
        self.document.scene.revision = next;
        Ok(next)
    }
    /// Save to the opened file only if the full saved baseline still matches.
    /// New destinations must not exist. Failure preserves all in-memory state.
    pub fn save(&mut self, path: impl AsRef<Path>) -> Result<(), SceneError> {
        let lock = SceneLock::acquire(path.as_ref())?;
        let existing = self.path.as_ref() == Some(&lock.path);
        if existing && self.saved.as_ref() != Some(&Document::load(&lock.path)?) {
            return Err(SceneError::Conflict);
        }
        self.document.write(&lock.path, !existing)?;
        self.document.format_version = FORMAT_VERSION;
        self.loaded_format_version = FORMAT_VERSION;
        self.saved = Some(self.document.clone());
        self.path = Some(lock.path.clone());
        Ok(())
    }
}

// Same stable sibling-lock convention as the logistics authoring surface,
// independently implemented to keep scene dependencies domain-neutral.
struct SceneLock {
    path: PathBuf,
    _file: File,
}
impl Drop for SceneLock {
    fn drop(&mut self) {
        // End the lock scope even if a concurrent fork temporarily inherited the FD.
        let _ = fs2::FileExt::unlock(&self._file);
    }
}
impl SceneLock {
    fn acquire(path: &Path) -> Result<Self, SceneError> {
        let parent = path
            .parent()
            .filter(|p| !p.as_os_str().is_empty())
            .unwrap_or_else(|| Path::new("."))
            .canonicalize()?;
        let name = path
            .file_name()
            .ok_or_else(|| SceneError::Invalid("file name required".into()))?;
        let path = parent.join(name);
        reject_nonregular(&path)?;
        let mut lock_name = OsString::from(".");
        lock_name.push(name);
        lock_name.push(".ruster-lock");
        let lock_path = parent.join(lock_name);
        reject_nonregular(&lock_path)?;
        let file = OpenOptions::new()
            .create(true)
            .truncate(false)
            .read(true)
            .write(true)
            .open(lock_path)?;
        fs2::FileExt::try_lock_exclusive(&file).map_err(|error| {
            if error.kind() == std::io::ErrorKind::WouldBlock
                || error.raw_os_error() == fs2::lock_contended_error().raw_os_error()
            {
                SceneError::Busy
            } else {
                SceneError::Io(error)
            }
        })?;
        reject_nonregular(&path)?;
        Ok(Self { path, _file: file })
    }
}
fn reject_nonregular(path: &Path) -> Result<(), SceneError> {
    match path.symlink_metadata() {
        Ok(m) if !m.is_file() => Err(SceneError::Invalid(
            "scene file and lock must be regular files".into(),
        )),
        Ok(_) => Ok(()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(e) => Err(e.into()),
    }
}

/// A static configurator preview: ticks are lifecycle observations, not physics.
/// The authored snapshot changes only on explicit reset through this API.
#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct Preview {
    pub scene: Scene,
    pub tick: u64,
}
impl Preview {
    pub fn new(scene: &Scene) -> Self {
        Self {
            scene: scene.clone(),
            tick: 0,
        }
    }
    pub fn reset(&mut self, scene: &Scene) {
        self.scene = scene.clone();
        self.tick = 0;
    }
    pub fn step(&mut self) -> Result<u64, SceneError> {
        let next = self.tick.checked_add(1).ok_or(SceneError::TickOverflow)?;
        self.tick = next;
        Ok(next)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn legacy_value(document: &Document) -> serde_json::Value {
        let mut value = serde_json::to_value(document).unwrap();
        value.as_object_mut().unwrap().remove("authoring");
        for stack in ["undo", "redo"] {
            value[stack] = serde_json::to_value(
                (if stack == "undo" {
                    &document.undo
                } else {
                    &document.redo
                })
                .iter()
                .map(|c| {
                    assert!(!c.has_authoring());
                    assert_eq!(c.scene.len(), 1);
                    &c.scene[0]
                })
                .collect::<Vec<_>>(),
            )
            .unwrap();
        }
        value
    }

    fn source(text: &str) -> BehaviorSource {
        BehaviorSource {
            label: Some("Recoverable draft".into()),
            language_id: "unknown-backend".into(),
            host_api_version: 1,
            text: text.into(),
        }
    }
    fn binding(owner: &str, source: &str) -> BehaviorBinding {
        BehaviorBinding {
            object_id: owner.into(),
            source_id: source.into(),
            enabled: true,
            properties: BTreeMap::new(),
        }
    }

    // Unique risk: broken source, absent backends/references and obsolete property values
    // must survive actual storage, while geometry readers must never silently strip them.
    #[test]
    fn unfinished_authoring_roundtrips_and_duplicate_keys_fail_closed() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("authoring.json");
        let mut session = Session::new(Scene::demo()).unwrap();
        session
            .set_source(0, "source-1", Some(source("function broken(\n")))
            .unwrap();
        let mut b = binding("left", "missing-source");
        b.properties = BTreeMap::from([
            ("old_number".into(), PropertyValue::Number(f64::MAX)),
            ("enabled".into(), PropertyValue::Bool(false)),
            (
                "title".into(),
                PropertyValue::Text("unfinished\ntext".into()),
            ),
            ("velocity".into(), PropertyValue::Vec3([1.0, 2.0, 3.0])),
            (
                "target".into(),
                PropertyValue::ObjectRef(Some("missing-object".into())),
            ),
            (
                "asset".into(),
                PropertyValue::AssetRef(Some("missing-asset".into())),
            ),
            ("unset".into(), PropertyValue::ObjectRef(None)),
        ]);
        session
            .set_binding(1, "binding-1", Some(b.clone()))
            .unwrap();
        let before = session.document.clone();
        assert_eq!(
            session
                .set_binding(2, "binding-1", Some(b.clone()))
                .unwrap(),
            2
        );
        assert!(session.set_binding(1, "binding-1", None).is_err());
        let mut invalid = b.clone();
        invalid.object_id = "absent-owner".into();
        assert!(session.set_binding(2, "binding-2", Some(invalid)).is_err());
        assert!(session
            .set_binding(2, "binding-2", Some(b.clone()))
            .is_err());
        let mut invalid = source("draft");
        invalid.text = "x".repeat(MAX_SOURCE_BYTES + 1);
        assert!(session.set_source(2, "oversize", Some(invalid)).is_err());
        let mut invalid = b.clone();
        invalid
            .properties
            .insert("bad".into(), PropertyValue::Number(f64::NAN));
        assert!(session.set_binding(2, "binding-1", Some(invalid)).is_err());
        assert_eq!(session.document, before);
        assert_eq!(session.authoring_diagnostics(0, 16).total, 2);
        assert_eq!(
            session.inspect_sources(0, usize::MAX).items[0].text_bytes,
            "function broken(\n".len()
        );
        assert!(!serde_json::to_string(&session.inspect_sources(0, 16))
            .unwrap()
            .contains("function broken"));
        assert_eq!(session.inspect_bindings(0, 16).items[0].property_count, 7);
        assert!(session.has_asset_references());
        session.save(&path).unwrap();
        let mut reopened = Session::open(&path).unwrap();
        assert_eq!(reopened.authoring(), session.authoring());
        assert!(!reopened.is_dirty());
        // Recovery snapshots preserve the whole document while granting no
        // authority to overwrite either the origin or an existing destination.
        let baseline = reopened.saved.clone();
        let original_bytes = std::fs::read(&path).unwrap();
        let snapshot = reopened.snapshot_bytes().unwrap();
        assert_eq!(reopened.saved, baseline);
        assert_eq!(reopened.path(), Some(path.as_path()));
        assert!(!reopened.is_dirty());
        assert_eq!(std::fs::read(&path).unwrap(), original_bytes);
        let mut recovered = Session::from_snapshot_bytes(&snapshot).unwrap();
        assert_eq!(recovered.document, reopened.document);
        assert!(recovered.path().is_none() && recovered.is_dirty());
        assert!(matches!(recovered.save(&path), Err(SceneError::Conflict)));
        assert_eq!(std::fs::read(&path).unwrap(), original_bytes);
        recovered.undo(2).unwrap();
        recovered.redo(3).unwrap();
        assert_eq!(recovered.authoring(), reopened.authoring());
        recovered
            .save(dir.path().join("recovered-copy.json"))
            .unwrap();
        assert!(Scene::load(&path)
            .unwrap_err()
            .to_string()
            .contains("Session::open"));
        reopened.set_binding(2, "binding-1", None).unwrap();
        reopened.set_source(3, "source-1", None).unwrap();
        reopened.save(&path).unwrap();
        assert!(reopened.authoring().is_empty());
        assert!(
            Scene::load(&path).is_err(),
            "reversible behavior must not be discarded either"
        );
        reopened.undo(4).unwrap();
        reopened.undo(5).unwrap();
        assert_eq!(reopened.authoring(), session.authoring());
        // Explicit geometry export is an intentional caller operation.
        let geometry = dir.path().join("geometry.json");
        reopened.scene().save(&geometry).unwrap();
        assert_eq!(Scene::load(&geometry).unwrap(), *reopened.scene());

        let source_json = serde_json::to_string(&source("unfinished (")).unwrap();
        let binding_json = serde_json::to_string(&b).unwrap();
        let scene_json = serde_json::to_string(session.scene()).unwrap();
        let envelope = |authoring: String| {
            format!("{{\"format\":\"ruster-scene\",\"format_version\":5,\"scene\":{scene_json},\"authoring\":{authoring},\"undo\":[],\"redo\":[]}}")
        };
        let good = envelope(format!(
            "{{\"sources\":{{\"s\":{source_json}}},\"bindings\":{{\"b\":{binding_json}}}}}"
        ));
        let duplicates = [
            good.replacen("\"format_version\":5", "\"format_version\":5,\"format_version\":5", 1),
            envelope("{\"sources\":{},\"sources\":{},\"bindings\":{}}".into()),
            envelope(format!("{{\"sources\":{{\"s\":{source_json},\"s\":{source_json}}},\"bindings\":{{}}}}")),
            envelope(format!("{{\"sources\":{{\"s\":{}}},\"bindings\":{{}}}}", source_json.replacen("\"language_id\":", "\"language_id\":\"other\",\"language_id\":", 1))),
            envelope(format!("{{\"sources\":{{}},\"bindings\":{{\"b\":{binding_json},\"b\":{binding_json}}}}}")),
            good.replacen("\"enabled\":true", "\"enabled\":true,\"enabled\":false", 1),
            good.replacen("\"properties\":{", "\"properties\":{\"duplicate\":{\"type\":\"bool\",\"value\":true},\"duplicat\\u0065\":{\"type\":\"bool\",\"value\":false},", 1),
        ];
        for duplicate in duplicates {
            std::fs::write(&path, &duplicate).unwrap();
            assert!(
                Session::open(&path).is_err(),
                "duplicate keys must fail in original bytes"
            );
            assert_eq!(std::fs::read_to_string(&path).unwrap(), duplicate);
        }
    }

    // Unique risk: deleting/duplicating objects must transact owned bindings with the
    // geometry and remap only references inside the copied selection, including self refs.
    #[test]
    fn behavior_lifecycle_is_one_undo_and_reserves_dangling_references() {
        // New source + attachment must never become two independent Undo steps
        // or leave a source behind when the owner's attachment is rejected.
        let mut attached = Session::new(Scene::demo()).unwrap();
        attached
            .create_behavior(
                0,
                "source-1",
                source("unfinished("),
                "binding-1",
                binding("left", "source-1"),
            )
            .unwrap();
        assert_eq!((attached.scene().revision, attached.undo_len()), (1, 1));
        attached.undo(1).unwrap();
        assert!(attached.authoring().is_empty());
        assert!(
            attached.contains_source_id("source-1") && attached.contains_binding_id("binding-1")
        );
        attached.redo(2).unwrap();
        let before = attached.document.clone();
        for (revision, source_id, binding_id, owner, referenced_source) in [
            (0, "source-2", "binding-2", "right", "source-2"),
            (3, "source-1", "binding-2", "right", "source-1"),
            (3, "source-2", "binding-1", "right", "source-2"),
            (3, "source-2", "binding-2", "left", "source-2"),
            (3, "source-2", "binding-2", "absent", "source-2"),
            (3, "source-2", "binding-2", "right", "other-source"),
        ] {
            assert!(attached
                .create_behavior(
                    revision,
                    source_id,
                    source("unfinished("),
                    binding_id,
                    binding(owner, referenced_source)
                )
                .is_err());
            assert_eq!(attached.document, before);
            assert_eq!(attached.history_evictions(), 0);
        }
        let mut session = Session::new(Scene::demo()).unwrap();
        let mut a = binding("left", "source-1");
        a.properties.insert(
            "internal".into(),
            PropertyValue::ObjectRef(Some("right".into())),
        );
        a.properties.insert(
            "external".into(),
            PropertyValue::ObjectRef(Some("center".into())),
        );
        let mut b = binding("right", "source-1");
        b.properties.insert(
            "self_ref".into(),
            PropertyValue::ObjectRef(Some("right".into())),
        );
        b.properties.insert(
            "dangling".into(),
            PropertyValue::ObjectRef(Some("object-1".into())),
        );
        session.set_binding(0, "binding-1", Some(a)).unwrap();
        session.set_binding(1, "binding-2", Some(b)).unwrap();
        assert_eq!(session.allocate_object_ids(1).unwrap(), ["object-2"]);
        assert_eq!(session.allocate_source_ids(1).unwrap(), ["source-2"]);
        let original = session.document.clone();
        let pairs = [
            ("left".into(), "copy-left".into()),
            ("right".into(), "copy-right".into()),
        ];
        session.duplicate_many(2, &pairs).unwrap();
        assert_eq!(session.undo_len(), 3);
        let copy = session
            .authoring()
            .bindings
            .values()
            .find(|b| b.object_id == "copy-left")
            .unwrap();
        assert_eq!(
            copy.properties["internal"],
            PropertyValue::ObjectRef(Some("copy-right".into()))
        );
        assert_eq!(
            copy.properties["external"],
            PropertyValue::ObjectRef(Some("center".into()))
        );
        let copy = session
            .authoring()
            .bindings
            .values()
            .find(|b| b.object_id == "copy-right")
            .unwrap();
        assert_eq!(
            copy.properties["self_ref"],
            PropertyValue::ObjectRef(Some("copy-right".into()))
        );
        assert_eq!(
            copy.properties["dangling"],
            PropertyValue::ObjectRef(Some("object-1".into()))
        );
        session.undo(3).unwrap();
        assert_eq!(session.authoring(), &original.authoring);
        assert_eq!(session.scene().objects, original.scene.objects);
        session.redo(4).unwrap();
        let copied = session.authoring().clone();
        session
            .delete_many(5, &["left".into(), "copy-right".into()])
            .unwrap();
        assert_eq!(session.authoring().bindings.len(), 2);
        session.undo(6).unwrap();
        assert_eq!(session.authoring(), &copied);
        session.delete(7, "right").unwrap();
        session.undo(8).unwrap();
        assert_eq!(session.authoring(), &copied);
        session.duplicate(9, "right", "single-copy", None).unwrap();
        assert!(session
            .authoring()
            .bindings
            .values()
            .any(|b| b.object_id == "single-copy"
                && b.properties["self_ref"]
                    == PropertyValue::ObjectRef(Some("single-copy".into()))));
        session.set_binding(10, "binding-2", None).unwrap();
        assert!(
            session.contains_object_id("object-1"),
            "history references reserve dangling identities"
        );
        assert!(session.create(11, Object::cube("object-1", None)).is_err());
        assert!(session.contains_source_id("source-1"));
        // Explicit source upsert repairs a referred identity instead of reallocating it.
        session
            .set_source(11, "source-1", Some(source("broken draft")))
            .unwrap();
        assert!(session.source("source-1").is_some());
    }

    // Unique risk: v4 grouped histories must migrate without rewriting, and old
    // versions cannot silently accept new authoring envelope/history fields, even null.
    #[test]
    fn v4_history_migrates_strictly_and_preserves_open_baseline() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("v4.json");
        let mut old = Session::new(Scene::demo()).unwrap();
        old.duplicate_many(0, &[("left".into(), "copy".into())])
            .unwrap();
        old.delete_many(1, &["left".into(), "right".into()])
            .unwrap();
        old.undo(2).unwrap();
        old.document.format_version = 4;
        let value = legacy_value(&old.document);
        let bytes = serde_json::to_vec(&value).unwrap();
        std::fs::write(&path, &bytes).unwrap();
        let mut reopened = Session::open(&path).unwrap();
        assert!(!reopened.is_dirty());
        assert_eq!(reopened.loaded_format_version(), 4);
        assert_eq!(std::fs::read(&path).unwrap(), bytes);
        assert_eq!((reopened.undo_len(), reopened.redo_len()), (1, 1));
        reopened.redo(3).unwrap();
        reopened.undo(4).unwrap();
        reopened.undo(5).unwrap();
        assert_eq!(reopened.scene().objects, Scene::demo().objects);
        reopened.save(&path).unwrap();
        assert_eq!(reopened.loaded_format_version(), 5);
        assert_eq!(Session::open(&path).unwrap().redo_len(), 2);
        for version in [3, 4] {
            for location in ["envelope", "history"] {
                let mut bad = value.clone();
                bad["format_version"] = version.into();
                if location == "envelope" {
                    bad["authoring"] = serde_json::Value::Null;
                } else {
                    bad["undo"][0]["sources"] = serde_json::Value::Null;
                }
                std::fs::write(&path, serde_json::to_vec(&bad).unwrap()).unwrap();
                assert!(Session::open(&path).is_err());
            }
        }
    }

    // Unique risk: a near-cap file admitted by the actual v4 writer must retain
    // every old Undo/Redo entry, rather than fail due to new wrapper indentation.
    #[test]
    fn actual_near_cap_v4_writer_recipe_migrates_without_history_loss() {
        let mut scene = Scene::empty("v4-near-cap");
        scene.objects = (0..256)
            .map(|n| Object::cube(format!("object-{n:03}"), None))
            .collect();
        let mut session = Session::new(scene).unwrap();
        // Historical aaacef9's writer admits five256-object groups, then27 scalar
        // groups to32 entries. The sixth large group was actually rejected there.
        for step in 0..32 {
            let count = if step < 5 { 256 } else { 1 };
            let edits = session
                .scene()
                .objects
                .iter()
                .take(count)
                .map(|o| {
                    let mut transform = o.transform.clone();
                    transform.translation[0] = if transform.translation[0] == 0.0 {
                        0.001
                    } else {
                        0.0
                    };
                    (o.id.clone(), transform)
                })
                .collect::<Vec<_>>();
            session
                .edit_transforms(session.scene().revision, &edits)
                .unwrap();
        }
        session.undo(session.scene().revision).unwrap();
        let old = V4Document {
            format: "ruster-scene".into(),
            format_version: 4,
            scene: session.scene().clone(),
            undo: session
                .document
                .undo
                .iter()
                .map(|c| {
                    assert_eq!(c.scene.len(), 1);
                    c.scene[0].clone()
                })
                .collect(),
            redo: session
                .document
                .redo
                .iter()
                .map(|c| c.scene[0].clone())
                .collect(),
        };
        let mut bytes = serde_json::to_vec_pretty(&old).unwrap();
        bytes.push(b'\n');
        // This exact byte count/hash was independently matched to the actual old
        // Session::save output, retained compressed with provenance in evidence.
        assert_eq!(bytes.len(), 1_028_346);
        let hash = bytes.iter().fold(0xcbf29ce484222325u64, |h, b| {
            (h ^ u64::from(*b)).wrapping_mul(0x100000001b3)
        });
        assert_eq!(hash, 0x392c41b401123383);
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("v4.json");
        std::fs::write(&path, &bytes).unwrap();
        let mut reopened = Session::open(&path).unwrap();
        assert_eq!((reopened.undo_len(), reopened.redo_len()), (31, 1));
        assert_eq!(reopened.history_evictions(), 0);
        assert_eq!(reopened.loaded_format_version(), 4);
        assert!(!reopened.is_dirty());
        assert_eq!(std::fs::read(&path).unwrap(), bytes);
        assert!(
            serde_json::to_vec_pretty(&reopened.document).unwrap().len() > MAX_FILE_BYTES as usize,
            "pretty v5 wrappers reproduce the migration overflow"
        );
        let objects = reopened.scene().objects.clone();
        reopened.redo(33).unwrap();
        reopened.undo(34).unwrap();
        assert_eq!(reopened.scene().objects, objects);
        reopened.save(&path).unwrap();
        assert_eq!(reopened.loaded_format_version(), 5);
        assert_eq!((reopened.undo_len(), reopened.redo_len()), (31, 1));
        let compact = std::fs::read(&path).unwrap();
        assert!(compact.len() <= MAX_FILE_BYTES as usize);
        assert_eq!(compact.iter().filter(|b| **b == b'\n').count(), 1);
        let reopened = Session::open(&path).unwrap();
        assert_eq!((reopened.undo_len(), reopened.redo_len()), (31, 1));
        assert_eq!(reopened.history_evictions(), 0);
    }

    // Unique risk: source deletion can shrink current state while Undo grows it;
    // admission must reserve all reachable authored payloads plus retained history once.
    #[test]
    fn source_history_byte_admission_preserves_saveable_undo_and_failure_atomicity() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("bounded.json");
        let mut session = Session::new(Scene::empty("bounded")).unwrap();
        for n in 0..50 {
            let text = format!("{}{n:03}", "\u{0001}".repeat(MAX_SOURCE_BYTES - 3));
            session
                .set_source(session.scene().revision, "source-1", Some(source(&text)))
                .unwrap();
        }
        assert!(
            session.history_evictions() > 0,
            "source editing must continue by trimming oldest history"
        );
        assert!(session.undo_len() < HISTORY_LIMIT);
        let latest = session.source("source-1").unwrap().clone();
        let evictions = session.history_evictions();
        let before = session.document.clone();
        assert!(session
            .set_source(session.scene().revision - 1, "source-1", None)
            .is_err());
        assert_eq!(
            session
                .set_source(session.scene().revision, "source-1", Some(latest.clone()))
                .unwrap(),
            session.scene().revision
        );
        let mut invalid = latest.clone();
        invalid.text.push('x');
        assert!(session
            .set_source(session.scene().revision, "source-1", Some(invalid))
            .is_err());
        assert_eq!(session.document, before);
        assert_eq!(session.history_evictions(), evictions);
        session.undo(session.scene().revision).unwrap();
        assert!(session.source("source-1").unwrap().text.ends_with("048"));
        assert_eq!(session.history_evictions(), evictions);
        session.redo(session.scene().revision).unwrap();
        assert_eq!(session.source("source-1"), Some(&latest));
        assert_eq!(session.history_evictions(), evictions);
        session
            .set_source(session.scene().revision, "source-1", None)
            .unwrap();
        session.save(&path).unwrap();
        let mut reopened = Session::open(&path).unwrap();
        assert_eq!(
            reopened.history_evictions(),
            0,
            "byte-pressure reporting is session-local"
        );
        reopened.document.scene.revision = 98;
        reopened.undo(98).unwrap();
        reopened.redo(99).unwrap();
        reopened.save(&path).unwrap();
        assert!(std::fs::metadata(&path).unwrap().len() <= MAX_FILE_BYTES);
        assert_eq!(
            Session::open(&path).unwrap().authoring(),
            reopened.authoring()
        );
        // A valid group whose new payload plus its own newest delta cannot fit
        // remains rejected atomically, even when every older Undo could be trimmed.
        let mut scene = Scene::empty("oversized-group");
        scene.objects = (0..8)
            .map(|n| Object::cube(format!("owner-{n}"), None))
            .collect();
        let mut group = Session::new(scene).unwrap();
        for n in 0..8 {
            let mut binding = binding(&format!("owner-{n}"), "missing-source");
            binding.properties = (0..MAX_PROPERTIES)
                .map(|p| {
                    (
                        format!("property-{p}"),
                        PropertyValue::Text("x".repeat(MAX_PROPERTY_TEXT_BYTES)),
                    )
                })
                .collect();
            group
                .set_binding(
                    group.scene().revision,
                    &format!("binding-{n}"),
                    Some(binding),
                )
                .unwrap();
        }
        let before = group.document.clone();
        let evictions = group.history_evictions();
        let pairs = (0..8)
            .map(|n| (format!("owner-{n}"), format!("copy-{n}")))
            .collect::<Vec<_>>();
        assert!(matches!(
            group.duplicate_many(group.scene().revision, &pairs),
            Err(SceneError::Capacity)
        ));
        assert_eq!(group.document, before);
        assert_eq!(group.history_evictions(), evictions);
        let mut pages = Session::new(Scene::empty("pages")).unwrap();
        for i in 0..17 {
            pages
                .set_source(i, &format!("source-{i}"), Some(source("")))
                .unwrap();
        }
        assert_eq!(pages.inspect_sources(0, usize::MAX).items.len(), 16);
        assert_eq!(pages.inspect_sources(0, usize::MAX).next_offset, Some(16));
        assert_eq!(pages.inspect_sources(16, 16).items.len(), 1);
        assert!(pages.inspect_sources(usize::MAX, 16).items.is_empty());
    }

    // Unique risk: partial multi-object mutations and per-object undo steps break a
    // gesture's atomicity; byte-limited recent history must keep every accepted state saveable.
    #[test]
    fn grouped_edits_are_atomic_one_step_and_byte_bounded() {
        let mut session = Session::new(Scene::demo()).unwrap();
        let first = session.scene().objects[0].transform.clone();
        let mut moved = first.clone();
        moved.translation[0] += 1.0;
        let before = session.document.clone();
        assert!(session
            .edit_transforms(
                0,
                &[
                    ("left".into(), moved.clone()),
                    ("missing".into(), moved.clone())
                ]
            )
            .is_err());
        assert_eq!(session.document, before);
        assert!(session
            .edit_transforms(
                0,
                &[
                    ("left".into(), moved.clone()),
                    ("left".into(), moved.clone())
                ]
            )
            .is_err());
        assert_eq!(session.document, before);
        session
            .edit_transforms(
                0,
                &[("left".into(), moved.clone()), ("right".into(), moved)],
            )
            .unwrap();
        assert_eq!(session.undo_len(), 1);
        session.undo(1).unwrap();
        assert_eq!(session.scene().objects, before.scene.objects);
        let before = session.document.clone();
        assert_eq!(
            session
                .edit_transforms(2, &[("left".into(), first)])
                .unwrap(),
            2
        );
        assert_eq!(session.document, before);
        session
            .duplicate_many(
                2,
                &[
                    ("left".into(), "left-copy".into()),
                    ("right".into(), "right-copy".into()),
                ],
            )
            .unwrap();
        assert_eq!(session.scene().objects.len(), 5);
        assert_eq!(session.undo_len(), 1);
        session
            .delete_many(3, &["left".into(), "right-copy".into()])
            .unwrap();
        session.undo(4).unwrap();
        assert_eq!(
            session
                .scene()
                .objects
                .iter()
                .map(|o| o.id.as_str())
                .collect::<Vec<_>>(),
            ["left", "center", "right", "left-copy", "right-copy"]
        );
        session.undo(5).unwrap();
        assert_eq!(session.scene().objects, before.scene.objects);

        let mut large = Session::new(Scene::empty("large")).unwrap();
        large
            .create_many(
                0,
                (0..MAX_OBJECTS)
                    .map(|i| {
                        Object::cube(
                            format!("object-{i}-{}", "a".repeat(110)),
                            Some("n".repeat(128)),
                        )
                    })
                    .collect(),
            )
            .unwrap();
        for n in 1..=HISTORY_LIMIT + 4 {
            let edits: Vec<_> = large
                .scene()
                .objects
                .iter()
                .map(|o| {
                    let mut t = o.transform.clone();
                    t.translation = [n as f32; 3];
                    (o.id.clone(), t)
                })
                .collect();
            large
                .edit_transforms(large.scene().revision, &edits)
                .unwrap();
        }
        assert!(
            large.history_evictions() > 0,
            "large group edits must keep the newest step and trim older history when needed"
        );
        assert!(large.document.validate().is_ok());
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("large.json");
        large.save(&path).unwrap();
        assert!(std::fs::metadata(&path).unwrap().len() <= MAX_FILE_BYTES);
        assert_eq!(Session::open(&path).unwrap().scene(), large.scene());
        // An admitted near-cap transaction remains undoable across revision digit growth.
        let objects = large.scene().objects.clone();
        large.document.scene.revision = 98;
        large.undo(98).unwrap();
        large.redo(99).unwrap();
        assert_eq!(large.scene().revision, 100);
        assert_eq!(large.scene().objects, objects);
        // Group history can reserve far more than the old289-ID editor probe.
        let mut ids = Session::new(Scene::empty("ids")).unwrap();
        for (start, count) in [(1, 256), (257, 44)] {
            let objects: Vec<_> = (start..start + count)
                .map(|n| Object::cube(format!("object-{n}"), None))
                .collect();
            let names: Vec<_> = objects.iter().map(|o| o.id.clone()).collect();
            ids.create_many(ids.scene().revision, objects).unwrap();
            ids.delete_many(ids.scene().revision, &names).unwrap();
        }
        assert_eq!(
            ids.allocate_object_ids(2).unwrap(),
            vec!["object-301", "object-302"]
        );
        assert!(ids.allocate_object_ids(MAX_OBJECTS + 1).is_err());
    }

    // Unique risk: a v3 label can silently accept grouped v4 semantics, or opening
    // a supported v3 document loses name/lifecycle undo and redo state.
    #[test]
    fn v3_migrates_scalar_history_but_rejects_grouped_history() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("v3.json");
        let mut doc = Document::new(Scene::demo());
        doc.format_version = 3;
        doc.scene.objects[0].name = Some("Named".into());
        doc.undo.push(
            SceneDelta::Name {
                id: "left".into(),
                before: None,
                after: Some("Named".into()),
            }
            .into(),
        );
        doc.redo.push(
            SceneDelta::Delete {
                object: doc.scene.objects[1].clone(),
                index: 1,
            }
            .into(),
        );
        std::fs::write(&path, serde_json::to_vec(&legacy_value(&doc)).unwrap()).unwrap();
        let mut session = Session::open(&path).unwrap();
        assert_eq!(session.loaded_format_version(), 3);
        session.redo(0).unwrap();
        session.undo(1).unwrap();
        session.undo(2).unwrap();
        assert!(session.scene().objects[0].name.is_none());
        session.save(&path).unwrap();
        assert_eq!(session.loaded_format_version(), FORMAT_VERSION);
        doc.undo = vec![SceneDelta::Transforms {
            changes: vec![TransformDelta {
                id: "left".into(),
                before: Transform::default(),
                after: doc.scene.objects[0].transform.clone(),
            }],
        }
        .into()];
        std::fs::write(&path, serde_json::to_vec(&legacy_value(&doc)).unwrap()).unwrap();
        assert!(Session::open(&path).is_err());
    }

    // Unique risk: a FIFO or other nonregular source/lock blocks before bounded
    // ingestion. Metadata rejection must occur before any open call.
    #[cfg(unix)]
    #[test]
    fn nonregular_sources_and_locks_are_rejected_before_open() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("fifo.scene");
        assert!(std::process::Command::new("mkfifo")
            .arg(&path)
            .status()
            .unwrap()
            .success());
        assert!(matches!(Scene::load(&path), Err(SceneError::Invalid(_))));
        assert!(matches!(
            Scene::demo().save(&path),
            Err(SceneError::Invalid(_))
        ));
        assert!(matches!(Session::open(&path), Err(SceneError::Invalid(_))));
        let path = dir.path().join("ordinary.json");
        let lock = dir.path().join(".ordinary.json.ruster-lock");
        assert!(std::process::Command::new("mkfifo")
            .arg(lock)
            .status()
            .unwrap()
            .success());
        assert!(matches!(
            Session::new(Scene::demo()).unwrap().save(&path),
            Err(SceneError::Invalid(_))
        ));
        assert!(!path.exists());
    }

    // Unique risk: lifecycle deltas preserve order/identity/assets through storage and
    // interleaved edits while failed commands and no-op naming preserve redo.
    #[test]
    fn lifecycle_history_roundtrip_preserves_order_identity_and_assets() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("scene.json");
        let mut session = Session::new(Scene::empty("owned")).unwrap();
        let mut cube = Object::cube("stable-a", Some("First object".into()));
        cube.mesh = Some("owned-mesh".into());
        session.create(0, cube.clone()).unwrap();
        session.duplicate(1, "stable-a", "stable-b", None).unwrap();
        session
            .rename(2, "stable-a", Some("Renamed ✨".into()))
            .unwrap();
        assert_eq!(session.scene().objects[0].id, "stable-a");
        assert_eq!(session.scene().objects[1].display_name(), "First object");
        session.delete(3, "stable-a").unwrap();
        session.delete(4, "stable-b").unwrap();
        assert!(session.scene().objects.is_empty());
        assert!(
            session.has_asset_references(),
            "deleted payloads retain mesh roots"
        );
        session.save(&path).unwrap();
        let mut session = Session::open(&path).unwrap();
        let before = session.document.clone();
        assert!(
            session.create(5, cube.clone()).is_err(),
            "history IDs stay reserved"
        );
        assert_eq!(session.document, before);
        session.undo(5).unwrap();
        session.undo(6).unwrap();
        assert_eq!(
            session
                .scene()
                .objects
                .iter()
                .map(|o| o.id.as_str())
                .collect::<Vec<_>>(),
            ["stable-a", "stable-b"]
        );
        assert_eq!(session.scene().objects[0].display_name(), "Renamed ✨");
        let before = session.document.clone();
        assert_eq!(
            session
                .rename(7, "stable-a", Some("Renamed ✨".into()))
                .unwrap(),
            7
        );
        assert!(session.rename(7, "stable-a", Some(" bad ".into())).is_err());
        assert!(session.delete(6, "stable-a").is_err());
        assert_eq!(session.document, before);
        session.save(&path).unwrap();
        let mut session = Session::open(&path).unwrap();
        session.redo(7).unwrap();
        session.redo(8).unwrap();
        for rev in 9..14 {
            session.undo(rev).unwrap();
        }
        assert!(session.scene().objects.is_empty());
        assert_eq!(session.redo_len(), 5);
        session
            .create(14, Object::cube("new-identity", None))
            .unwrap();
        assert_eq!(session.redo_len(), 0);
        assert_eq!(session.undo_len(), 1);
    }

    // Unique risk: old formats silently accept new semantics, or malformed lifecycle
    // history introduces invalid intermediate scenes or non-atomic failed commands.
    #[test]
    fn lifecycle_limits_and_strict_v2_migration() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("v2.json");
        let mut value = serde_json::to_value(Document::new(Scene::demo())).unwrap();
        value["format_version"] = 2.into();
        value["scene"]["objects"][0]["mesh"] = "asset".into();
        value["undo"] =
            serde_json::json!([{"kind":"mesh","id":"left","before":null,"after":"asset"}]);
        value["redo"] = serde_json::json!([{"kind":"transform","id":"center","before":Transform::default(),"after":Transform { translation: [1.0,0.0,0.0], ..Transform::default() }}]);
        let bytes = serde_json::to_vec(&value).unwrap();
        std::fs::write(&path, &bytes).unwrap();
        let mut old = Session::open(&path).unwrap();
        assert_eq!(old.loaded_format_version(), 2);
        assert!(!old.is_dirty());
        old.redo(0).unwrap();
        old.undo(1).unwrap();
        old.undo(2).unwrap();
        old.save(&path).unwrap();
        assert_eq!(old.loaded_format_version(), FORMAT_VERSION);
        assert!(Session::open(&path).unwrap().scene().objects[0]
            .mesh
            .is_none());
        for version in [1, 2] {
            let mut mislabeled = if version == 1 {
                serde_json::from_slice(include_bytes!("../tests/fixtures/legacy-v1.scene.json"))
                    .unwrap()
            } else {
                value.clone()
            };
            mislabeled["scene"]["objects"][0]["name"] = serde_json::Value::Null;
            std::fs::write(&path, serde_json::to_vec(&mislabeled).unwrap()).unwrap();
            assert!(Session::open(&path).is_err());
        }
        let mut mislabeled = value;
        mislabeled["undo"] =
            serde_json::json!([{"kind":"name","id":"left","before":null,"after":"A"}]);
        std::fs::write(&path, serde_json::to_vec(&mislabeled).unwrap()).unwrap();
        assert!(Session::open(&path).is_err());
        let mut session = Session::new(Scene::empty("limits")).unwrap();
        for i in 0..MAX_OBJECTS {
            session
                .create(i as u64, Object::cube(format!("object-{i}"), None))
                .unwrap();
        }
        let before = session.document.clone();
        assert!(session
            .create(MAX_OBJECTS as u64, Object::cube("overflow", None))
            .is_err());
        assert_eq!(session.document, before);
        assert_eq!(session.undo_len(), HISTORY_LIMIT);
        session.document.scene.revision = u64::MAX;
        let before = session.document.clone();
        assert!(session.delete(u64::MAX, "object-0").is_err());
        assert_eq!(session.document, before);
        let mut corrupt = Document::new(Scene::empty("bad-history"));
        corrupt.redo = vec![SceneDelta::Create {
            object: Object::cube("same", None),
            index: 1,
        }
        .into()];
        assert!(corrupt.validate().is_err());
        corrupt.redo = vec![SceneDelta::Delete {
            object: Object::cube("absent", None),
            index: 0,
        }
        .into()];
        assert!(corrupt.validate().is_err());
    }

    // Unique risk: commands/history must survive the actual storage boundary.
    #[test]
    fn edit_undo_redo_save_reopen_preserves_identity_and_history() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("scene.json");
        let mut session = Session::new(Scene::demo()).unwrap();
        let initial = session.scene().clone();
        let mut transform = initial.objects[0].transform.clone();
        transform.translation[1] = 3.0;
        assert_eq!(session.edit(0, "left", &transform).unwrap(), 1);
        session.save(&path).unwrap();
        assert!(!session.is_dirty());
        let mut reopened = Session::open(&path).unwrap();
        assert_eq!(reopened.scene(), session.scene());
        assert_eq!(reopened.undo(1).unwrap(), 2);
        assert_eq!(reopened.scene().objects, initial.objects);
        reopened.save(&path).unwrap();
        let mut reopened = Session::open(&path).unwrap();
        assert_eq!(reopened.redo(2).unwrap(), 3);
        assert_eq!(reopened.scene().objects[0].transform, transform);
        assert_eq!(reopened.scene().id, initial.id);
        assert_eq!(reopened.undo(3).unwrap(), 4);
        transform.translation[1] = 5.0;
        reopened.edit(4, "left", &transform).unwrap();
        assert!(matches!(reopened.redo(5), Err(SceneError::NoRedo)));
    }

    // Unique risk: invalid/stale/no-op commands and revision exhaustion mutate
    // neither current state nor the history/dirty baseline.
    #[test]
    fn commands_are_atomic_and_history_is_bounded() {
        let mut session = Session::new(Scene::demo()).unwrap();
        let initial = session.document.clone();
        let transform = session.scene().objects[0].transform.clone();
        assert_eq!(session.edit(0, "left", &transform).unwrap(), 0);
        assert_eq!(session.document, initial);
        assert!(matches!(
            session.edit(1, "left", &transform),
            Err(SceneError::StaleRevision { .. })
        ));
        assert!(matches!(
            session.undo(1),
            Err(SceneError::StaleRevision { .. })
        ));
        assert!(matches!(
            session.redo(1),
            Err(SceneError::StaleRevision { .. })
        ));
        let mut invalid = transform.clone();
        invalid.scale[0] = f32::NAN;
        assert!(session.edit(0, "left", &invalid).is_err());
        assert!(matches!(
            session.edit(0, "absent", &transform),
            Err(SceneError::ObjectNotFound(_))
        ));
        assert!(matches!(session.undo(0), Err(SceneError::NoUndo)));
        assert_eq!(session.document, initial);
        for i in 1..=40 {
            let mut change = transform.clone();
            change.translation[1] = i as f32;
            session.edit(i - 1, "left", &change).unwrap();
        }
        assert_eq!(session.undo_len(), HISTORY_LIMIT);
        assert_eq!(
            session.history_evictions(),
            0,
            "normal age eviction is not byte-pressure eviction"
        );
        for i in 0..HISTORY_LIMIT {
            session.undo(40 + i as u64).unwrap();
        }
        assert_eq!(session.scene().objects[0].transform.translation[1], 8.0);
        assert_eq!(session.redo_len(), HISTORY_LIMIT);
        session.document.scene.revision = u64::MAX;
        let before = session.document.clone();
        assert!(matches!(
            session.redo(u64::MAX),
            Err(SceneError::RevisionOverflow)
        ));
        assert!(matches!(
            session.edit(u64::MAX, "left", &transform),
            Err(SceneError::RevisionOverflow)
        ));
        assert_eq!(session.document, before);
    }

    // Unique risk: legacy undo AND redo survive an explicit v1-to-current save,
    // including an unchanged save; absent mesh fields preserve old fingerprints.
    #[test]
    fn legacy_v1_history_migrates_without_dropping_or_rewriting_on_open() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("legacy.json");
        let bytes = include_bytes!("../tests/fixtures/legacy-v1.scene.json");
        std::fs::write(&path, bytes).unwrap();
        let mut session = Session::open(&path).unwrap();
        assert_eq!(session.loaded_format_version(), 1);
        assert!(!session.is_dirty());
        assert_eq!((session.undo_len(), session.redo_len()), (1, 1));
        assert!(session.scene().objects[0].mesh.is_none());
        assert_eq!(std::fs::read(&path).unwrap(), bytes);
        let legacy: serde_json::Value = serde_json::from_slice(bytes).unwrap();
        let serialized: serde_json::Value =
            serde_json::from_slice(&serde_json::to_vec(session.scene()).unwrap()).unwrap();
        assert_eq!(serialized, legacy["scene"]);
        let fingerprint = session.scene().fingerprint();
        // Fixed from the v1 struct's canonical field order, before mesh existed.
        assert_eq!(fingerprint, "65601f5c06cf65d9");
        let occupied = dir.path().join("occupied.json");
        std::fs::write(&occupied, b"external work").unwrap();
        assert!(matches!(session.save(&occupied), Err(SceneError::Conflict)));
        assert_eq!(session.loaded_format_version(), 1);
        assert!(!session.is_dirty());
        assert_eq!(std::fs::read(&path).unwrap(), bytes);
        session.save(&path).unwrap();
        assert_eq!(session.loaded_format_version(), FORMAT_VERSION);
        assert!(!session.is_dirty());
        let stored: serde_json::Value =
            serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
        assert_eq!(stored["format_version"], FORMAT_VERSION);
        assert_eq!(stored["undo"][0]["scene"][0]["kind"], "transform");
        assert_eq!(stored["redo"][0]["scene"][0]["kind"], "transform");
        let mut reopened = Session::open(&path).unwrap();
        assert_eq!(reopened.scene().fingerprint(), fingerprint);
        reopened.redo(3).unwrap();
        assert_eq!(reopened.scene().objects[0].transform.translation[0], 2.0);
        reopened.undo(4).unwrap();
        reopened.undo(5).unwrap();
        assert_eq!(reopened.scene().objects[0].transform.translation[0], 0.0);
        reopened.redo(6).unwrap();
        assert_eq!(reopened.scene().objects[0].transform.translation[0], 1.0);
    }

    // Unique risk: a mislabeled v1 document must never silently discard v2 mesh
    // assignments or accept v2 tagged history, including explicit mesh null.
    #[test]
    fn legacy_v1_rejects_mesh_fields_and_v2_history() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("legacy.json");
        let legacy: serde_json::Value =
            serde_json::from_slice(include_bytes!("../tests/fixtures/legacy-v1.scene.json"))
                .unwrap();
        for mesh in [serde_json::Value::Null, "owned-mesh".into()] {
            let mut value = legacy.clone();
            value["scene"]["objects"][0]["mesh"] = mesh;
            let bytes = serde_json::to_vec(&value).unwrap();
            std::fs::write(&path, &bytes).unwrap();
            assert!(matches!(Session::open(&path), Err(SceneError::Format(_))));
            assert_eq!(std::fs::read(&path).unwrap(), bytes);
        }
        let mut value = legacy;
        value["undo"][0]["kind"] = "transform".into();
        std::fs::write(&path, serde_json::to_vec(&value).unwrap()).unwrap();
        assert!(Session::open(&path).is_err());
    }

    // Unique risk: mesh and transform edits share one chronological persisted
    // history while invalid/stale/no-op assignments preserve redo and dirty state.
    #[test]
    fn mesh_assignments_share_history_and_failed_commands_are_atomic() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("mesh.json");
        let mut session = Session::new(Scene::demo()).unwrap();
        let mesh = Some("owned_mesh.01".into());
        session.set_mesh(0, "left", mesh.clone()).unwrap();
        let mut transform = session.scene().objects[0].transform.clone();
        transform.translation[1] = 5.0;
        session.edit(1, "left", &transform).unwrap();
        session.undo(2).unwrap();
        session.save(&path).unwrap();
        let before = session.document.clone();
        assert_eq!(session.set_mesh(3, "left", mesh.clone()).unwrap(), 3);
        assert!(matches!(
            session.set_mesh(2, "left", mesh.clone()),
            Err(SceneError::StaleRevision { .. })
        ));
        assert!(matches!(
            session.set_mesh(3, "absent", None),
            Err(SceneError::ObjectNotFound(_))
        ));
        for invalid in [
            "",
            "../source.obj",
            "mesh/name",
            "mesh name",
            &"x".repeat(129),
        ] {
            assert!(session.set_mesh(3, "left", Some(invalid.into())).is_err());
        }
        assert_eq!(session.document, before);
        assert!(!session.is_dirty());
        let mut reopened = Session::open(&path).unwrap();
        assert_eq!(reopened.redo(3).unwrap(), 4);
        assert_eq!(reopened.scene().objects[0].transform, transform);
        reopened.undo(4).unwrap();
        reopened.undo(5).unwrap();
        assert_eq!(reopened.scene().objects[0].mesh, None);
        reopened.save(&path).unwrap();
        let mut reopened = Session::open(&path).unwrap();
        reopened.redo(6).unwrap();
        assert_eq!(reopened.scene().objects[0].mesh, mesh);
        reopened.set_mesh(7, "left", None).unwrap();
        assert_eq!(reopened.redo_len(), 0);
        reopened.undo(8).unwrap();
        assert_eq!(reopened.scene().objects[0].mesh, mesh);
        reopened.document.scene.revision = u64::MAX;
        let before = reopened.document.clone();
        assert!(matches!(
            reopened.set_mesh(u64::MAX, "left", None),
            Err(SceneError::RevisionOverflow)
        ));
        assert_eq!(reopened.document, before);
        // Bounded history applies equally to mesh changes.
        let mut bounded = Session::new(Scene::demo()).unwrap();
        for i in 0..40 {
            bounded
                .set_mesh(i, "left", Some(format!("mesh-{i}")))
                .unwrap();
        }
        assert_eq!(bounded.undo_len(), HISTORY_LIMIT);
        bounded.document.validate().unwrap();
        // Persisted mesh chains must match the current field, just like transforms.
        bounded.document.scene.objects[0].mesh = None;
        assert!(bounded.document.validate().is_err());
    }

    // Unique risk: public code-first values bypass constructor validation.
    #[test]
    fn public_value_validation_rejects_representative_limits() {
        let demo = Scene::demo();
        let mut cases = Vec::new();
        let mut scene = demo.clone();
        scene.id = "x".repeat(129);
        cases.push(scene);
        let mut scene = demo.clone();
        scene.objects[0].mesh = Some("mesh/source.obj".into());
        cases.push(scene);
        let mut scene = demo.clone();
        scene.objects[1].id = "left".into();
        cases.push(scene);
        let mut scene = demo.clone();
        scene.objects[0].transform.translation[0] = 10_001.0;
        cases.push(scene);
        let mut scene = demo.clone();
        scene.objects[0].transform.rotation[0] = f32::INFINITY;
        cases.push(scene);
        let mut scene = demo.clone();
        scene.objects[0].transform.scale[0] = 0.0;
        cases.push(scene);
        let mut scene = demo.clone();
        scene.objects[0].color[0] = 1.01;
        cases.push(scene);
        let mut scene = demo.clone();
        scene.objects = vec![scene.objects[0].clone(); MAX_OBJECTS + 1];
        cases.push(scene);
        for scene in cases {
            assert!(Session::new(scene).is_err());
        }
        let mut boundary = demo;
        boundary.objects[0].transform = Transform {
            translation: [10_000.0; 3],
            rotation: [-10_000.0; 3],
            scale: [0.001, 1_000.0, 1.0],
        };
        assert!(boundary.validate().is_ok());
    }

    // Unique risk: malformed/foreign/versioned files or inconsistent persisted
    // history are accepted and later corrupt undo, or exhaust bounded ingestion.
    #[test]
    fn file_boundary_rejects_corruption_versions_history_and_foreign_formats() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("scene.json");
        let good = serde_json::to_value(Document::new(Scene::demo())).unwrap();
        let mut cases = vec![
            b"{".to_vec(),
            br#"{"format_version":1,"id":"logistics","config":{}}"#.to_vec(),
        ];
        let mut value = good.clone();
        value["format_version"] = (FORMAT_VERSION + 1).into();
        cases.push(serde_json::to_vec(&value).unwrap());
        let mut value = good.clone();
        value["unexpected"] = true.into();
        cases.push(serde_json::to_vec(&value).unwrap());
        let mut value = good.clone();
        value["undo"] =
            serde_json::json!([{"kind":"mesh","id":"left","before":null,"after":"owned-mesh"}]);
        cases.push(serde_json::to_vec(&value).unwrap());
        let mut value = good.clone();
        value["undo"] = serde_json::json!([{"kind":"unrecognized","id":"left"}]);
        cases.push(serde_json::to_vec(&value).unwrap());
        let mut value = good;
        value["undo"] = serde_json::json!([{"id":"left","before":Transform::default(),"after":Transform::default()}]);
        cases.push(serde_json::to_vec(&value).unwrap());
        cases.push(vec![b' '; MAX_FILE_BYTES as usize + 1]);
        for bytes in cases {
            std::fs::write(&path, &bytes).unwrap();
            assert!(Session::open(&path).is_err());
            assert_eq!(std::fs::read(&path).unwrap(), bytes);
        }
        let mut session = Session::new(Scene::demo()).unwrap();
        session.document.undo = vec![
            SceneDelta::Transform {
                id: "left".into(),
                before: Transform::default(),
                after: Transform::default()
            }
            .into();
            HISTORY_LIMIT + 1
        ];
        assert!(session.document.validate().is_err());
    }

    // Unique risk: failed atomic saves, full-baseline conflicts and lock/path
    // aliases overwrite external work or mark unsaved work as clean.
    #[test]
    fn persistence_failure_conflict_and_cooperating_lock_preserve_work() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("scene.json");
        let mut session = Session::new(Scene::demo()).unwrap();
        session.save(&path).unwrap();
        let original = std::fs::read(&path).unwrap();
        let mut invalid = Scene::demo();
        invalid.objects[0].transform.scale[0] = 0.0;
        assert!(invalid.save(&path).is_err());
        assert_eq!(std::fs::read(&path).unwrap(), original);
        let directory = dir.path().join("directory");
        std::fs::create_dir(&directory).unwrap();
        assert!(session.scene().save(&directory).is_err());
        assert!(directory.is_dir());
        let lock = SceneLock::acquire(&path).unwrap();
        assert!(matches!(
            session.save(dir.path().join("./scene.json")),
            Err(SceneError::Busy)
        ));
        // Model a descriptor inherited by another process: closing just this File
        // would retain flock until every duplicate closes, beyond the guard scope.
        let inherited = lock._file.try_clone().unwrap();
        drop(lock);
        let reacquired = SceneLock::acquire(&path).unwrap();
        drop(reacquired);
        drop(inherited);
        let mut external = Document::load(&path).unwrap();
        external.scene.objects[0].color[0] = 0.5;
        external.write(&path, false).unwrap();
        let mut transform = session.scene().objects[0].transform.clone();
        transform.translation[2] = 9.0;
        session.edit(0, "left", &transform).unwrap();
        let before = session.document.clone();
        assert!(matches!(session.save(&path), Err(SceneError::Conflict)));
        assert_eq!(session.document, before);
        assert!(session.is_dirty());
        assert_eq!(Document::load(&path).unwrap(), external);
        let mut fresh = Session::new(Scene::demo()).unwrap();
        assert!(matches!(fresh.save(&path), Err(SceneError::Conflict)));
        assert!(fresh.path().is_none());
        #[cfg(unix)]
        {
            let alias = dir.path().join("alias.json");
            std::os::unix::fs::symlink(&path, &alias).unwrap();
            assert!(matches!(Session::open(alias), Err(SceneError::Invalid(_))));
        }
    }

    // Unique risk: preview ticks/editing leak into each other's snapshots.
    #[test]
    fn static_preview_isolated_until_reset_and_tick_overflow_atomic() {
        let mut scene = Scene::demo();
        let mut preview = Preview::new(&scene);
        scene.objects[0].transform.translation[0] = 9.0;
        assert_eq!(preview.step().unwrap(), 1);
        assert_ne!(preview.scene, scene);
        assert_ne!(preview.scene.fingerprint(), scene.fingerprint());
        preview.reset(&scene);
        assert_eq!(preview.scene, scene);
        assert_eq!(preview.tick, 0);
        assert_eq!(preview.scene.fingerprint(), scene.fingerprint());
        preview.tick = u64::MAX;
        let before = preview.clone();
        assert!(matches!(preview.step(), Err(SceneError::TickOverflow)));
        assert_eq!(preview, before);
    }
}

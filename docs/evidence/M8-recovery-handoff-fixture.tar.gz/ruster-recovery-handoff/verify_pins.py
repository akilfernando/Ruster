from pathlib import Path
import hashlib,json,subprocess,tomllib
root=Path('/home/akilf/Projects/Ruster')
folder=Path('/tmp/ruster-recovery-handoff')
metadata=json.loads(subprocess.check_output(['/home/akilf/.cargo/bin/cargo','metadata','--locked','--offline','--format-version','1','--manifest-path',str(folder/'Cargo.toml')],text=True))
nodes={n['id']:n for n in metadata['resolve']['nodes']};packages={p['id']:p for p in metadata['packages']}
root_packages={(p['name'],p['version'],p.get('source')):p for p in tomllib.loads((root/'Cargo.lock').read_text())['package']}
temp_packages={(p['name'],p['version'],p.get('source')):p for p in tomllib.loads((folder/'Cargo.lock').read_text())['package']}
seen=set();todo=[metadata['resolve']['root']]
while todo:
 current=todo.pop()
 if current in seen:continue
 seen.add(current)
 todo.extend(d['pkg'] for d in nodes[current]['deps'] if any(k['kind'] in (None,'build') for k in d['dep_kinds']))
records=[]
for ident in sorted(seen):
 package=packages[ident];key=(package['name'],package['version'],package.get('source'))
 if package['name']=='ruster-recovery-handoff':continue
 assert key in root_packages,('Not in production root lock',key)
 assert key in temp_packages,('Not in temp lock',key)
 assert temp_packages[key].get('checksum')==root_packages[key].get('checksum'),('Checksum mismatch',key)
 records.append({'name':key[0],'version':key[1],'source':key[2],'checksum':temp_packages[key].get('checksum')})
print(json.dumps({'all_reachable_normal_build_entries_match_root':True,'checked_packages':len(records),'root_lock_sha256':hashlib.sha256((root/'Cargo.lock').read_bytes()).hexdigest(),'temp_lock_sha256':hashlib.sha256((folder/'Cargo.lock').read_bytes()).hexdigest(),'features':{packages[i]['name']:nodes[i]['features'] for i in seen if packages[i]['name'] in ['serde','serde_json','sha2','tempfile','ruster-scene']},'packages':records},indent=2))

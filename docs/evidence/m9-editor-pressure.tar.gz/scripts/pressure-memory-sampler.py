#!/usr/bin/env python3
"""PREPARED ONLY: one disposable default-release editor history/runtime retention journey.

PREPARED ONLY: execute only after the root grants its serialized quiet window.
No input injection, clipboard, workspace switching, builds or repository writes.
--render-unfocused explicitly scopes a temporary rule to this window's unique tag;
choose it before measurements, never change rendering conditions between phases.
"""
import argparse
import asyncio
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import shutil
import socket
import stat
import statistics
import struct
import subprocess
import time
import traceback
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(os.environ['RUSTER_SOURCE_ROOT']).resolve()
CONF = Path.home() / '.config/hypr/hyprland.lua'
HUMAN_PIDS = ()  # Populate only from a fresh protected-process inventory, if needed.
EXPECTED_HEAD = 'a083654d55df64362feefe0cabe672f909118f43'
EXPECTED_BINARY = '1599a6966fbc8f2fc158409e73b0cff9b3f86d3e5025f4ca97557492788504e3'
EXPECTED_FIXTURE = '1a29bb65325a37e284f0ea639e3e6921e252686283d0249e12592163a89a9fb9'
TICKS = os.sysconf('SC_CLK_TCK')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def object_values(value):
    # Scene transforms/colors are f32. MCP Value prints widened f64 values while
    # Session's direct writer prints shortest round-tripping f32 decimals.
    if isinstance(value, float):
        return struct.unpack('f', struct.pack('f', value))[0]
    if isinstance(value, list):
        return [object_values(x) for x in value]
    if isinstance(value, dict):
        return {key: object_values(x) for key, x in value.items()}
    return value


def proc_values(pid):
    path = Path('/proc') / str(pid)
    fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
    status = {key: value.strip() for key, value in
              (line.split(':', 1) for line in (path / 'status').read_text().splitlines())}
    return {'cpu_seconds': (int(fields[11]) + int(fields[12])) / TICKS,
            'rss_kib': int(status['VmRSS'].split()[0]),
            'hwm_kib': int(status['VmHWM'].split()[0]),
            'threads': int(status['Threads']), 'start_ticks': int(fields[19])}


async def run(args):
    assert importlib.metadata.version('mcp') == '2.3.0'
    binary = args.binary.resolve(strict=True)
    adapter = args.adapter.resolve(strict=True)
    fixture = args.fixture.resolve(strict=True)
    assert sha(binary) == EXPECTED_BINARY
    assert sha(fixture) == EXPECTED_FIXTURE and fixture.stat().st_size == 907273
    source_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True, timeout=10).strip()
    subprocess.run(['git', 'diff', '--exit-code', EXPECTED_HEAD, '--', 'crates', 'third_party', 'Cargo.toml', 'Cargo.lock', '.cargo', 'rust-toolchain.toml'], cwd=ROOT, check=True, stdout=subprocess.DEVNULL, timeout=10)
    assert sha(adapter) == '44182096cf08f38d4f28b471d9e3ff5e75ccfd87b72d1fe6056fbe07ed1391a9'
    fixture_document = json.loads(fixture.read_text())
    admission_path = fixture.parent / 'admission-smoke.scene.json'
    assert sha(admission_path) == '184523ce96d784850ea558579c7c670bb87e63ef6984b19b8dead70d781228b2'
    admission_document = json.loads(admission_path.read_text())
    assert fixture_document['scene']['revision'] == 23 and len(fixture_document['undo']) == 23 and not fixture_document['redo']
    base = args.directory.resolve()
    assert base.is_relative_to(Path('/tmp')) and not base.exists()
    base.mkdir(parents=True, mode=0o700)
    recovery_dir = args.recovery_directory.resolve()
    assert recovery_dir.is_relative_to((Path.home() / '.local/state')) and not recovery_dir.exists()
    assert not args.recovery_directory.is_symlink()
    mount = json.loads(subprocess.check_output(['findmnt', '-J', '-T', str(recovery_dir.parent)], timeout=10))['filesystems'][0]
    assert mount['source'].startswith('/dev/nvme'), mount
    recovery_dir.mkdir(mode=0o700)
    for name in ('project', 'state', 'snapshots', 'tmp'):
        (base / name).mkdir(mode=0o700)
    scene_path = base / 'project/scene.json'
    shutil.copyfile(fixture, scene_path)
    original_config = CONF.read_bytes()
    assert b'ruster-development-workspace' in original_config
    assert b'workspace = "2 silent"' in original_config and b'no_initial_focus = true' in original_config
    instances = json.loads(subprocess.check_output(['hyprctl', 'instances', '-j'], timeout=10))
    assert len(instances) == 1, 'An exact desktop instance is required'
    instance = instances[0]['instance']

    def ctl(*arguments):
        return subprocess.check_output(['hyprctl', '-i', instance, *arguments], text=True, timeout=10)

    def state(name):
        return json.loads(ctl('-j', name))

    initial_workspace = state('activeworkspace')['id']
    assert initial_workspace == 1, 'Only run while the user remains on workspace1'
    initial_clients = state('clients')
    assert not [item for item in initial_clients if item['class'] == 'org.ruster.editor'], 'Defer if any preexisting editor is present'
    for human_pid in HUMAN_PIDS:
        assert not Path('/proc', str(human_pid)).exists(), 'Prior human PID exists; re-inventory before running'
    token = 'ruster-m9-pressure-memory-' + uuid.uuid4().hex
    rule = ('\n-- BEGIN ' + token + '\n'
            'hl.window_rule({name="' + token + '",match={class="^org[.]ruster[.]editor$",tag="' + token + '"},render_unfocused=true})\n'
            '-- END ' + token + '\n').encode()
    metadata = {
        'ok': False, 'recorded_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'engine_source': EXPECTED_HEAD, 'launch_head': source_head, 'binary': str(binary), 'binary_sha256': sha(binary),
        'adapter': str(adapter), 'adapter_sha256': sha(adapter), 'mcp_sdk': '2.3.0',
        'fixture': str(fixture), 'fixture_sha256': sha(fixture), 'fixture_bytes': fixture.stat().st_size,
        'objects': 256, 'enabled_bindings': 255, 'shared_lua_sources': 1,
        'scope': 'whole-editor history/runtime/recovery journey; coarse250ms RSS peak and OS cumulative VmHWM, not pure Lua allocation, instantaneous peak, leak proof or focused latency',
        'condition': 'hidden workspace2; pointer outside target; no focused input; ' +
                     ('unique-tag-scoped temporary render_unfocused=true' if args.render_unfocused else 'default compositor occlusion'),
        'inspection': 'disabled', 'validation': 'disabled', 'mcp': 'enabled for both phases',
        'requested_gpu': 'NVIDIA ICD per process; actual adapter is recorded in editor.log',
        'platform': platform.uname()._asdict(), 'hyprland_version': ctl('version'),
        'monitors': [{key: value for key, value in monitor.items() if key in
            ('name', 'width', 'height', 'refreshRate', 'scale', 'transform', 'disabled', 'dpmsStatus')}
            for monitor in state('monitors')], 'initial_active_workspace': initial_workspace,
        'initial_config_sha256': hashlib.sha256(original_config).hexdigest(),
        'prior_human_pids_absent': list(HUMAN_PIDS), 'warmup_seconds_per_phase': 5, 'sample_count_per_phase': 10,
        'sample_interval_seconds': .25, 'cycles': 10, 'recovery_directory': str(recovery_dir), 'recovery_mount': mount,
        'fixture_revision': 23, 'fixture_undo': 23, 'fixture_redo': 0, 'intentional_shutdown': 'exact-owned SIGTERM after durable final recovery; no normal shutdown/reopen claim', 'proc_ticks_per_second': TICKS,
        'redraw_count': 'not measured; production complete-frame counter is unavailable',
        'samples': [], 'trace': [], 'events': [],
    }
    governor = Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor')
    metadata['governor'] = governor.read_text().strip() if governor.exists() else None
    process = None
    process_start = None
    socket_path = None
    rule_installed = False
    log = None
    monitor_task = None
    monitor_done = False
    journey_phase = 'startup'
    metadata['rss_trace'] = []

    def save():
        (base / 'result.json').write_text(json.dumps(metadata, indent=2) + '\n')

    def hidden():
        current = state('activeworkspace')['id']
        assert current == initial_workspace == 1, 'User workspace changed; abort unattended work'
        return current

    def owned_process():
        assert process is not None and process.pid not in HUMAN_PIDS and process.poll() is None
        assert proc_values(process.pid)['start_ticks'] == process_start
        assert (Path('/proc') / str(process.pid) / 'exe').resolve() == binary

    def exact_window():
        owned_process()
        matches = [item for item in state('clients') if item['pid'] == process.pid]
        assert len(matches) == 1 and matches[0]['class'] == 'org.ruster.editor' and matches[0]['workspace']['id'] == 2, matches
        return matches[0]

    def dispatch(body, check_workspace=True):
        if check_workspace:
            hidden()
        exact_window()
        expression = ('assert(hl.get_active_workspace() and hl.get_active_workspace().id~=2, "workspace2 active; defer owned-window action"); local n=0; for _,w in ipairs(hl.get_windows({class="org.ruster.editor"})) do if w.pid==' +
                      str(process.pid) + ' then ' + body + '; n=n+1 end end; assert(n==1)')
        result = ctl('eval', expression)
        assert not any(word in result.lower() for word in ('error', 'warning')), result

    def peer_check():
        hidden()
        exact_window()
        assert socket_path is not None and socket_path.is_relative_to(base / 'tmp')
        assert not socket_path.is_symlink() and not socket_path.parent.is_symlink()
        info, parent = socket_path.stat(), socket_path.parent.stat()
        assert stat.S_ISSOCK(info.st_mode) and info.st_uid == parent.st_uid == os.getuid()
        assert stat.S_IMODE(info.st_mode) == 0o600 and stat.S_IMODE(parent.st_mode) == 0o700
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as probe:
            probe.settimeout(2)
            probe.connect(str(socket_path))
            peer_pid, peer_uid, peer_gid = struct.unpack('3i', probe.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize('3i')))
        assert peer_pid == process.pid and peer_pid not in HUMAN_PIDS and peer_uid == os.getuid()
        return {'pid': peer_pid, 'uid': peer_uid, 'gid': peer_gid}

    async def settle():
        until = time.monotonic() + 5
        while time.monotonic() < until:
            hidden(); owned_process()
            await asyncio.sleep(.25)

    async def monitor():
        # Guard/query overhead can make intervals exceed250ms; retain timestamps.
        while not monitor_done:
            if process is not None and process.poll() is None:
                try:
                    value = proc_values(process.pid)
                    assert value['start_ticks'] == process_start
                    metadata['rss_trace'].append({'phase': journey_phase, 'monotonic': time.monotonic(), **value})
                except (FileNotFoundError, ProcessLookupError):
                    pass
            await asyncio.sleep(.25)

    async def samples(phase):
        nonlocal journey_phase
        journey_phase = phase + '_settle5s'
        await settle()
        geometry = {key: exact_window()[key] for key in ('size', 'at', 'floating', 'workspace', 'monitor')}
        if 'matched_geometry' in metadata:
            assert geometry == metadata['matched_geometry'], 'Restore original geometry before retention sampling'
        else:
            metadata['matched_geometry'] = geometry
        journey_phase = phase + '_ten_samples'
        observations = []
        started = time.monotonic()
        for index in range(10):
            hidden(); owned_process()
            observations.append({'index': index + 1, 'monotonic': time.monotonic(), **proc_values(process.pid)})
            await asyncio.sleep(.25)
        entry = {'phase': phase, 'count': 10, 'elapsed_seconds': time.monotonic()-started,
                 'observations': observations, 'rss_min_kib': min(x['rss_kib'] for x in observations),
                 'rss_max_kib': max(x['rss_kib'] for x in observations),
                 'hwm_max_kib': max(x['hwm_kib'] for x in observations),
                 'rss_median_kib': statistics.median(x['rss_kib'] for x in observations),
                 'geometry': geometry, 'system_loadavg': os.getloadavg()}
        if metadata['samples']:
            entry['rss_median_minus_baseline_kib'] = entry['rss_median_kib']-metadata['samples'][0]['rss_median_kib']
        metadata['samples'].append(entry); save()
        print(json.dumps({key:value for key,value in entry.items() if key!='observations'}), flush=True)

    async def published_checkpoint(snapshot, label):
        deadline = time.monotonic() + 20
        while True:
            hidden(); owned_process()
            candidates = []
            for path in recovery_dir.glob('window-*/checkpoint.json'):
                assert path.is_file() and not path.is_symlink() and not path.parent.is_symlink()
                payload = path.read_bytes()
                record = json.loads(payload)
                assert record['format'] == 'ruster-editor-recovery' and record['version'] == 1 and record['sequence'] > 0
                saved = record['snapshot']
                document = saved['document']
                # Rust Snapshot checksums the exact raw JSON document, not a re-encoding.
                match = re.search(r'"document"\s*:\s*', payload.decode())
                assert match
                rawtext = payload.decode()[match.end():]
                decoded, end = json.JSONDecoder().raw_decode(rawtext)
                assert decoded == document
                assert hashlib.sha256(rawtext[:end].encode()).hexdigest() == saved['document_sha256']
                assert saved['origin'] == str(scene_path)
                if str(document['scene']['revision']) != snapshot['revision']:
                    continue
                assert object_values(document['scene']['objects']) == object_values(snapshot['objects'])
                assert document['authoring'] == fixture_document['authoring']
                assert saved['drafts']['version'] == 3 and str(saved['drafts']['revision']) == snapshot['revision']
                expected_undo = 24 if label == 'after_edit' else 23
                expected_redo = 0 if label == 'after_edit' else 1
                assert len(document['undo']) == expected_undo and len(document['redo']) == expected_redo
                if label == 'after_undo':
                    assert document == admission_document, 'Published full Session must match independently admitted edit/Undo smoke'
                else:
                    assert document['undo'][:-1] == fixture_document['undo']
                    assert document['undo'][-1] == admission_document['redo'][-1]
                archive = base / 'snapshots' / (label + '-published-checkpoint.json')
                archive.write_bytes(payload)
                candidates.append({'path': str(path), 'archived': str(archive), 'sha256': sha(archive),
                    'bytes': len(payload), 'sequence': record['sequence'], 'revision': snapshot['revision'],
                    'undo': len(document['undo']), 'redo': len(document['redo']),
                    'document_sha256': saved['document_sha256']})
            if candidates:
                assert len(candidates) == 1
                metadata.setdefault('recovery_checkpoints', {})[label] = candidates[0]; save()
                return
            assert time.monotonic() < deadline, 'Current revision did not produce a finalized published checkpoint'
            await asyncio.sleep(.25)

    try:
        env = dict(os.environ, RUSTER_MCP_ENABLE='1', TMPDIR=str(base / 'tmp'),
                   RUSTER_EDITOR_STATE=str(base / 'state/editor.json'), RUSTER_RECOVERY_DIR=str(recovery_dir),
                   HYPRLAND_INSTANCE_SIGNATURE=instance, XDG_RUNTIME_DIR=os.environ['XDG_RUNTIME_DIR'], WAYLAND_DISPLAY=os.environ['WAYLAND_DISPLAY'])
        for key in ('EGUI_INSPECTION', 'RUSTER_MCP_SOCKET', 'VK_INSTANCE_LAYERS', 'VK_LAYER_VALIDATE_SYNC',
                    'VK_LOADER_DEBUG', 'VK_LAYER_PATH', 'VK_LOADER_LAYERS_ENABLE', 'VK_LOADER_LAYERS_ALLOW',
                    'VK_LOADER_LAYERS_DISABLE', 'WGPU_DEBUG', 'WGPU_VALIDATION', 'WGPU_GPU_BASED_VALIDATION',
                    'WGPU_VALIDATION_INDIRECT_CALL', 'LD_LIBRARY_PATH'):
            env.pop(key, None)
        env.update(WGPU_DEBUG='0', WGPU_VALIDATION='0', WGPU_GPU_BASED_VALIDATION='0',
                   VK_DRIVER_FILES='/usr/share/vulkan/icd.d/nvidia_icd.json')
        metadata['editor_environment_overrides'] = {key: env[key] for key in
            ('RUSTER_MCP_ENABLE', 'TMPDIR', 'RUSTER_EDITOR_STATE', 'RUSTER_RECOVERY_DIR', 'VK_DRIVER_FILES',
             'WGPU_DEBUG', 'WGPU_VALIDATION', 'WGPU_GPU_BASED_VALIDATION', 'HYPRLAND_INSTANCE_SIGNATURE', 'WAYLAND_DISPLAY')}
        hidden(); log = (base / 'editor.log').open('wb')
        process = subprocess.Popen([str(binary), '--scene', str(scene_path)], env=env, stdout=log, stderr=subprocess.STDOUT)
        process_start = proc_values(process.pid)['start_ticks']
        metadata['pid'] = process.pid; save()
        monitor_task = asyncio.create_task(monitor())
        deadline = time.monotonic() + 30
        while not any(item['pid'] == process.pid for item in state('clients')):
            hidden(); owned_process(); assert time.monotonic() < deadline
            await asyncio.sleep(.1)
        metadata['initial_window'] = exact_window()
        dispatch('hl.dispatch(hl.dsp.window.float({action="on",window=w}))')
        dispatch('hl.dispatch(hl.dsp.window.resize({x=1100,y=800,relative=false,window=w}))')
        if args.render_unfocused:
            dispatch('hl.dispatch(hl.dsp.window.tag({tag="+' + token + '",window=w}))')
            clients = state('clients')
            assert [item['pid'] for item in clients if token in item.get('tags', [])] == [process.pid]
            current = CONF.read_bytes()
            assert rule not in current and token.encode() not in current
            (base / 'hyprland-before-rule.lua').write_bytes(current)
            CONF.write_bytes(current + rule); rule_installed = True
            subprocess.run(['hyprctl', '-i', instance, 'reload', 'config-only'], check=True, stdout=subprocess.DEVNULL, timeout=15)
            assert ctl('configerrors').strip() in ('', 'ok')
            hidden(); exact_window()
            metadata['render_unfocused_rule'] = rule.decode(); save()
        while socket_path is None:
            owned_process(); hidden(); assert time.monotonic() < deadline
            matches = re.findall(r'Ruster MCP bridge: (\S+) \(private', (base / 'editor.log').read_text(errors='replace'))
            if matches:
                assert len(matches) == 1
                socket_path = Path(matches[0]).resolve(strict=True)
            else:
                await asyncio.sleep(.1)
        metadata['socket'] = str(socket_path); metadata['socket_peer'] = peer_check(); save()
        adapter_env = {**env, 'RUSTER_MCP_SOCKET': str(socket_path)}
        with (base / 'adapter.log').open('w') as adapter_log:
            async with stdio_client(StdioServerParameters(command=str(adapter), env=adapter_env), errlog=adapter_log) as (read, write):
                async with ClientSession(read, write) as client:
                    await asyncio.wait_for(client.initialize(), timeout=10)
                    names = {tool.name for tool in (await asyncio.wait_for(client.list_tools(), timeout=10)).tools}
                    assert len(names) == 44 and {'behavior_runtime_reset', 'behavior_runtime_stop', 'scene_inspect'} <= names

                    async def call(name, value=None):
                        peer_check()
                        response = await asyncio.wait_for(client.call_tool(name, value or {}), timeout=12)
                        result = response.structured_content
                        metadata['trace'].append({'tool': name, 'arguments': value or {}, 'response': result,
                                                  'is_error': bool(response.is_error)})
                        save()
                        assert result is not None and not response.is_error and result['ok'], response
                        return result['result']

                    async def authored_snapshot():
                        pages, objects, offset = [], [], None
                        while True:
                            page = await call('scene_inspect', {} if offset is None else {'offset': offset})
                            assert page['object_count'] == 256 and not page['drafts_pending'] and not page['recovery_pending']
                            assert page['revision'].isdigit()
                            if pages:
                                assert page['session_token'] == pages[0]['session_token'] and page['revision'] == pages[0]['revision']
                            pages.append(page); objects.extend(page['objects']); offset = page['next_offset']
                            if offset is None:
                                break
                        assert len(objects) == 256
                        return {'session_token': pages[0]['session_token'], 'revision': pages[0]['revision'], 'objects': objects,
                                'asset_revision': pages[0]['asset_revision'], 'shader_revision': pages[0]['shader_revision'],
                                'dirty': pages[0]['dirty'], 'drafts_pending': pages[0]['drafts_pending'], 'recovery_pending': pages[0]['recovery_pending']}

                    before_scene = await authored_snapshot()
                    assert before_scene['revision'] == '23' and not before_scene['dirty']
                    assert object_values(before_scene['objects']) == object_values(fixture_document['scene']['objects'])
                    (base / 'snapshots/before.json').write_text(json.dumps(before_scene, indent=2)+'\n')
                    initial_runtime = await call('behavior_runtime_inspect')
                    assert initial_runtime['run_id'] is None and initial_runtime['tick'] is None
                    assert not any(initial_runtime[key] for key in ('ready', 'busy', 'playing', 'visible'))
                    metadata['runtime_before'] = initial_runtime; save()
                    await samples('before_lazy_vm_initialization')
                    unchanged = await call('behavior_runtime_inspect')
                    assert unchanged['run_id'] is None and unchanged['tick'] is None
                    expected = {'expected_session_token': before_scene['session_token'], 'expected_revision': before_scene['revision']}

                    async def operation(name, current_run=None):
                        arguments = dict(expected)
                        if current_run is not None:
                            arguments['expected_run_id'] = current_run
                        accepted = await call(name, arguments)
                        deadline = time.monotonic() + 20
                        while True:
                            observed = await call('behavior_runtime_inspect', {'operation_id': accepted['operation_id']})
                            receipt = observed['operation']
                            assert receipt is not None and receipt['operation_id'] == accepted['operation_id']
                            assert receipt['run_id'] == accepted['run_id']
                            assert receipt['state'] not in ('failed', 'superseded'), observed
                            if receipt['state'] == 'completed' and not observed['busy']:
                                break
                            assert time.monotonic() < deadline, 'Exact runtime receipt timed out'
                            await asyncio.sleep(.05)
                        assert observed['diagnostic'] is None and not observed['playing']
                        metadata['events'].append({'operation': name, 'accepted': accepted, 'completed': observed}); save()
                        return observed

                    for cycle in range(1, 11):
                        journey_phase = f'cycle_{cycle}_active'
                        reset = await operation('behavior_runtime_reset')
                        assert reset['ready'] and reset['tick'] == '0' and reset['object_count'] == 256
                        stepped = await operation('behavior_runtime_step', reset['run_id'])
                        assert stepped['ready'] and stepped['tick'] == '1' and stepped['object_count'] == 256
                        stopped = await operation('behavior_runtime_stop', stepped['run_id'])
                        assert not stopped['visible'] and not stopped['ready'] and stopped['tick'] == '1'
                        assert await authored_snapshot() == before_scene
                        assert sha(scene_path) == EXPECTED_FIXTURE and sha(fixture) == EXPECTED_FIXTURE
                        if cycle in (3, 6, 9):
                            size = {3: (900, 650), 6: (1280, 900), 9: (700, 500)}[cycle]
                            dispatch(f'hl.dispatch(hl.dsp.window.resize({{x={size[0]},y={size[1]},relative=false,window=w}}))')
                            await asyncio.sleep(.5)
                            assert exact_window()['size'] == list(size)
                            metadata.setdefault('resizes', []).append({'cycle': cycle, 'size': list(size)})
                            dispatch('hl.dispatch(hl.dsp.window.resize({x=1100,y=800,relative=false,window=w}))')
                            await asyncio.sleep(.5)
                        await samples(f'after_cycle_{cycle}_stop')
                    journey_phase = 'authored_edit_recovery'
                    first = before_scene['objects'][0]
                    changed = json.loads(json.dumps(first['transform']))
                    changed['translation'][2] = .125
                    await call('scene_transform', {**expected, 'object_id': first['id'], 'transform': changed})
                    edited = await authored_snapshot()
                    assert edited['revision'] == '24' and edited['dirty']
                    expected_objects = json.loads(json.dumps(before_scene['objects']))
                    expected_objects[0]['transform'] = changed
                    assert edited['objects'] == expected_objects
                    (base / 'snapshots/after-edit.json').write_text(json.dumps(edited, indent=2)+'\n')
                    await published_checkpoint(edited, 'after_edit')
                    await samples('after_authored_edit_and_published_recovery')
                    journey_phase = 'undo_recovery'
                    await call('scene_undo', {'expected_session_token': edited['session_token'], 'expected_revision': edited['revision']})
                    undone = await authored_snapshot()
                    assert undone['revision'] == '25' and undone['dirty']
                    assert undone['objects'] == before_scene['objects']
                    assert undone['session_token'] == before_scene['session_token']
                    (base / 'snapshots/after-undo.json').write_text(json.dumps(undone, indent=2)+'\n')
                    await published_checkpoint(undone, 'after_undo')
                    await samples('after_undo_and_published_recovery')
                    final_runtime = await call('behavior_runtime_inspect')
                    assert not any(final_runtime[key] for key in ('busy', 'playing', 'visible', 'ready'))
                    final_scene = await authored_snapshot()
                    assert final_scene == undone
                    metadata['runtime_final'] = final_runtime
                    metadata['undo_scope'] = 'Restored authored objects; revision25/history23Undo+1Redo/dirty differ from initial revision23/history23Undo+0Redo/clean. No exact Session equality.'
                    assert sha(scene_path) == sha(fixture) == EXPECTED_FIXTURE
        hidden(); exact_window(); owned_process()
        metadata['planned_termination'] = 'Durable current-revision recovery and authored snapshots archived. Exact-owned SIGTERM; no Save/Discard/native input.'
        process.terminate()
        metadata['exit_code'] = await asyncio.to_thread(process.wait, timeout=20)
        assert metadata['exit_code'] == -15
        monitor_done = True
        await monitor_task
        metadata['coarse_sampled_peak_rss_kib'] = max(x['rss_kib'] for x in metadata['rss_trace'])
        metadata['phase_peaks'] = {phase: {'rss_kib': max(x['rss_kib'] for x in metadata['rss_trace'] if x['phase']==phase),
            'vmhwm_kib': max(x['hwm_kib'] for x in metadata['rss_trace'] if x['phase']==phase)}
            for phase in sorted({x['phase'] for x in metadata['rss_trace']})}
        metadata['active_journey_coarse_peak_rss_kib'] = max(x['rss_kib'] for x in metadata['rss_trace'] if x['phase'].endswith('_active') or x['phase'] in ('authored_edit_recovery', 'undo_recovery'))
        metadata['observed_cumulative_vmhwm_kib'] = max(x['hwm_kib'] for x in metadata['rss_trace'])
        metadata['startup_coarse_peak_rss_kib'] = max(x['rss_kib'] for x in metadata['rss_trace'] if x['phase'] == 'startup')
        assert sha(scene_path) == sha(fixture) == EXPECTED_FIXTURE
        assert sha(binary) == EXPECTED_BINARY
        metadata['fixture_final_sha256'] = sha(scene_path)
        metadata['ok'] = True
    except BaseException as error:
        metadata['failure'] = repr(error)
        metadata['traceback'] = traceback.format_exc(); save()
        raise
    finally:
        if process is not None and process.poll() is None:
            # The user might be interacting with our window after a workspace switch.
            # Keep it open for root rather than closing or signalling a visible test.
            try:
                if state('activeworkspace')['id'] == 2:
                    metadata['cleanup_deferred'] = 'workspace2 active; owned test window left open for root'
                    metadata['ok'] = False
                else:
                    dispatch('hl.dispatch(hl.dsp.window.close({window=w}))')
                    metadata['cleanup_exit_code'] = await asyncio.to_thread(process.wait, timeout=10)
            except BaseException as error:
                metadata['cleanup_close_failure'] = repr(error)
                try:
                    if state('activeworkspace')['id'] == 2:
                        metadata['cleanup_deferred'] = 'workspace2 became active; owned test process left open for root'
                        metadata['ok'] = False
                    else:
                        # Recheck immediately before signalling, and verify process identity.
                        owned_process()
                        assert state('activeworkspace')['id'] != 2
                        process.terminate()
                        metadata['cleanup_terminated_exit_code'] = await asyncio.to_thread(process.wait, timeout=10)
                except BaseException as termination_error:
                    metadata['cleanup_termination_failure'] = repr(termination_error)
        if log is not None:
            log.close()
        if rule_installed:
            try:
                current = CONF.read_bytes()
                assert current.count(rule) == 1, 'Rule marker changed; preserve config and report manual cleanup'
                CONF.write_bytes(current.replace(rule, b'', 1))
                subprocess.run(['hyprctl', '-i', instance, 'reload', 'config-only'], check=True, stdout=subprocess.DEVNULL, timeout=15)
                assert ctl('configerrors').strip() in ('', 'ok')
                metadata['temporary_rule_removed'] = True
            except BaseException as error:
                metadata['cleanup_rule_failure'] = repr(error); metadata['ok'] = False
        metadata['config_equal_initial'] = CONF.read_bytes() == original_config
        metadata['final_config_sha256'] = sha(CONF)
        metadata['final_active_workspace'] = state('activeworkspace')['id']
        final_clients = state('clients')
        metadata['initial_editor_windows_preserved'] = all(
            any(new['pid'] == old['pid'] and new['address'] == old['address'] for new in final_clients)
            for old in initial_clients if old['class'] == 'org.ruster.editor')
        metadata['owned_process_exited'] = process is None or process.poll() is not None
        metadata['owned_window_absent'] = process is None or not any(x['pid'] == process.pid for x in final_clients)
        if not metadata['config_equal_initial'] or metadata['final_active_workspace'] != 1 or not metadata['owned_window_absent']:
            metadata['ok'] = False
        if not metadata['initial_editor_windows_preserved'] or not metadata['owned_process_exited']:
            metadata['ok'] = False
        monitor_done = True
        if monitor_task is not None:
            await monitor_task
        metadata['recovery_preserved'] = recovery_dir.exists()
        save()
    assert metadata['ok'], metadata
    print(json.dumps({'ok': True, 'output': str(base / 'result.json')}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, default=Path(os.environ.get('RUSTER_FROZEN_EDITOR', '/absolute/path/to/frozen-default-editor')))
    parser.add_argument('--adapter', type=Path, default=ROOT / 'target/debug/ruster-mcp')
    parser.add_argument('--fixture', type=Path, default=Path(__file__).resolve().parents[1] / 'fixtures/scene.json')
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--recovery-directory', type=Path, required=True)
    parser.add_argument('--render-unfocused', action='store_true')
    asyncio.run(run(parser.parse_args()))

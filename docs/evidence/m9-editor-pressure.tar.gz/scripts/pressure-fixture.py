#!/usr/bin/env python3
"""Build temporary history pressure through cached public Session CLI; no builds."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(os.environ['RUSTER_SOURCE_ROOT']).resolve()
BASE = Path(os.environ['RUSTER_FIXTURE_OUTPUT']).resolve()
SOURCE = Path(__file__).resolve().parents[1] / 'fixtures/empty-history-source.scene.json'
CLI = ROOT / 'target/debug/ruster-scene'
BEHAVIOR = ROOT / 'target/debug/ruster-behavior'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    assert sha(SOURCE) == 'bcc1fb3fba5ca6a613ae6faf7447d38c74fe791fed07702ef484943f23c2588e'
    BASE.mkdir(mode=0o700)
    scene = BASE / 'scene.json'
    shutil.copyfile(SOURCE, scene)
    manifest = {'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'source_sha256': sha(SOURCE), 'scene_cli_sha256': sha(CLI),
                'behavior_cli_sha256': sha(BEHAVIOR), 'commands': [],
                'method': 'cached CLI transforms invokes public Session::edit_transforms then Session::save; no hand-authored history',
                'ok': False}
    def save():
        (BASE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    def run(args, log):
        started = time.monotonic()
        result = subprocess.run([str(x) for x in args], cwd=ROOT, capture_output=True, text=True, timeout=60)
        (BASE / log).write_text(result.stdout + result.stderr)
        manifest['commands'].append({'argv': [str(x) for x in args], 'exit': result.returncode,
                                     'wall_seconds': time.monotonic() - started, 'log': log})
        save()
        assert result.returncode == 0, result.stderr
    try:
        # Fixed ordinary-range deltas; adapt only group size to retain >=120KiB headroom.
        for iteration in range(32):
            document = json.loads(scene.read_text())
            if scene.stat().st_size >= 875 * 1024:
                break
            group = 256 if scene.stat().st_size < 720 * 1024 else 64
            edits = []
            for obj in document['scene']['objects'][:group]:
                transform = json.loads(json.dumps(obj['transform']))
                transform['translation'][2] = 0.001 if transform['translation'][2] == 0 else 0
                edits.append({'object_id': obj['id'], 'transform': transform})
            batch = BASE / 'batch.json'
            batch.write_text(json.dumps(edits))
            revision = document['scene']['revision']
            run([CLI, 'transforms', scene, revision, batch], f'seed-{iteration:02}.log')
            updated = json.loads(scene.read_text())
            assert updated['scene']['revision'] == revision + 1
            assert len(updated['undo']) == len(document['undo']) + 1, 'Do not admit pressure through eviction'
            manifest.setdefault('seeds', []).append({'revision': revision + 1, 'group': group, 'bytes': scene.stat().st_size})
        assert 850 * 1024 <= scene.stat().st_size <= 950 * 1024
        document = json.loads(scene.read_text())
        assert len(document['scene']['objects']) == 256
        assert len(document['authoring']['bindings']) == 255
        assert document['authoring'] == json.loads(SOURCE.read_text())['authoring']
        # Demonstrate bounded one-object edit/Undo admission on a separate disposable copy.
        smoke = BASE / 'admission-smoke.scene.json'
        shutil.copyfile(scene, smoke)
        obj = document['scene']['objects'][0]
        tr = obj['transform']['translation']
        run([CLI, 'transform', smoke, document['scene']['revision'], obj['id'], tr[0], tr[1], 0.125], 'admission-transform.log')
        edited = json.loads(smoke.read_text())
        assert edited['scene']['revision'] == document['scene']['revision'] + 1
        assert len(edited['undo']) == len(document['undo']) + 1
        run([CLI, 'undo', smoke, edited['scene']['revision']], 'admission-undo.log')
        undone = json.loads(smoke.read_text())
        assert undone['scene']['objects'] == document['scene']['objects']
        assert undone['authoring'] == document['authoring']
        assert len(undone['undo']) == len(document['undo']) and len(undone['redo']) == 1
        # Each cached lock-using validation is intentionally sequential.
        run([CLI, 'inspect', scene], 'inspect.log')
        run([BEHAVIOR, 'check', scene], 'behavior-check.log')
        run([BEHAVIOR, 'run', scene, 1], 'behavior-run-one.log')
        manifest.update(ok=True, fixture_sha256=sha(scene), fixture_bytes=scene.stat().st_size,
                        revision=document['scene']['revision'], undo_entries=len(document['undo']),
                        redo_entries=len(document['redo']), headroom_bytes=1048576-scene.stat().st_size,
                        objects=256, enabled_bindings=255, shared_lua_sources=1,
                        admission_smoke_sha256=sha(smoke), source_final_sha256=sha(SOURCE))
        assert manifest['source_final_sha256'] == manifest['source_sha256']
    finally:
        save()
    print(json.dumps(manifest, indent=2))

if __name__ == '__main__':
    main()

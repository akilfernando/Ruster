# Partial integrated recovery evidence

Reports and logs are sanitized copies; capability socket paths and session tokens are redacted.
Three actual images and selected trees show the unsubmitted draft, restored draft, and repaired UI.
The real first checkpoint and current second checkpoint are omitted to avoid publishing private paths
or invalidating their byte hashes. Independent file and raw document checksums are in provenance.json
and reports/root-checkpoints-verification.json. Controllers are sanitized evidence, not runnable copies; host config paths are placeholders.
The initial intentional SIGKILL is distinct from the continuation, whose exit code was not observed.
Save as, normal exit and reopen were not verified. SHA256SUMS covers all other members.

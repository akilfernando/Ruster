#!/usr/bin/env python3
"""Continuation from verified checkpoint; execute only with explicit root grant."""
import argparse, asyncio, base64, hashlib, importlib.util, json, os, re, shutil, socket, stat, struct, subprocess, time, traceback, uuid
from pathlib import Path
from types import SimpleNamespace
ROOT=Path('<repository>'); BASE=Path('<disposable-fixture>');CONF=Path('<hyprland-config>')
BINARY=Path('/tmp/ruster-m9-inspection-release-a083654');ADAPTER=ROOT/'target/debug/ruster-mcp';PORT=None
BH='6d40f91897522f1d0a7ccb040d6cd80ad39f3180a95e7270fa390792ba2e16d2';AH='44182096cf08f38d4f28b471d9e3ff5e75ccfd87b72d1fe6056fbe07ed1391a9'
GOOD='return { update = function(transform, props, dt, host) return transform end }\n';BAD='return { update = function(\n';DRAFT='-- unapplied recovery journey draft\nreturn { update = function(\n'
spec=importlib.util.spec_from_file_location('native',ROOT/'docs/evidence/M8-content-recovery-native.py');native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
def sha(data):return hashlib.sha256(data).hexdigest()
def start_ticks(pid):return int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19])
def nodes(t):return [n for _,n in t['Tree'][2][0]]
async def run(a):
 from mcp import ClientSession,StdioServerParameters
 from mcp.client.stdio import stdio_client
 mount=subprocess.check_output(['findmnt','-T',str(BASE.parent),'-no','SOURCE,FSTYPE'],text=True,timeout=10).strip();assert '/dev/nvme' in mount, ('recovery fixture is not on NVMe',mount)
 assert sha(BINARY.read_bytes())==BH and sha(ADAPTER.read_bytes())==AH and BASE.is_dir()
 fixture=BASE/'fixture';original=fixture/'project/scene.json';sibling=fixture/'project/recovered-journey.json';initial_hash='7c07a328725c6b45b327cf718054c883e3f46c7566458f8735984133faf90c5c'
 assert not sibling.exists() and sha(original.read_bytes())==initial_hash
 previous_raw=(BASE/'result.json').read_bytes();previous=json.loads(previous_raw)
 assert previous['status']=='failed' and previous['checkpoint']['sha256']=='fdf02d9b9894ac61a2ee38abd5a2738f0f50be57fb7d97c90638ddac9ec7e71d'
 assert len(previous['processes'])==1 and previous['processes'][0]['exit']==-9
 matches=list((fixture/'recovery').glob('window-*/checkpoint.json'));assert len(matches)==1
 raw=matches[0].read_bytes();assert sha(raw)==previous['checkpoint']['sha256'] and raw==(BASE/'checkpoint.json').read_bytes()
 record=json.loads(raw);snap=record['snapshot'];assert record['sequence']==previous['checkpoint']['sequence'] and str(snap['document']['scene']['revision'])==previous['checkpoint']['revision']
 assert snap['origin']==str(original) and snap['asset_origin']==str(fixture/'project') and snap['drafts']['behavior']['source']['text']==DRAFT and snap['document']['authoring']['sources']['journey-source']['text']==BAD
 txt=raw.decode();marker='"document":';assert txt.count(marker)==1;pos=txt.index(marker)+len(marker)
 while txt[pos].isspace():pos+=1
 _,end=json.JSONDecoder().raw_decode(txt,pos);assert sha(txt[pos:end].encode())==snap['document_sha256']==previous['checkpoint']['document_sha256']
 before_calls=[x for x in previous['mcp'] if x['tool']=='behavior_source_set'];assert len(before_calls)==1
 expected={'expected_session_token':before_calls[0]['args']['expected_session_token']}
 CAP=BASE/'continuation';assert not CAP.exists();CAP.mkdir(mode=0o700)
 active=native.hypr(a.instance,'activeworkspace')['id'];assert active!=2
 original_config=CONF.read_bytes();token='ruster-m9-recovery-'+uuid.uuid4().hex
 rule=('\n-- BEGIN '+token+'\n'+'hl.window_rule({name="'+token+'",match={class="^org[.]ruster[.]editor$",tag="'+token+'"},render_unfocused=true})\n'+'-- END '+token+'\n').encode()
 report={'status':'running','previous_report_sha256':sha(previous_raw),'verified_checkpoint_sha256':sha(raw),'storage_mount':mount,'initial_workspace':active,'original_sha256':initial_hash,'binary_sha256':BH,'adapter_sha256':AH,'processes':[],'actions':[],'mcp':[]};process=None;driver=None;start=None;address=None;log=None;rule_installed=False;socket_path=None;used_ports=set();adapter_ordinal=0
 (CAP/'captures').mkdir(mode=0o700)
 def save():(CAP/'result.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
 def hidden():assert native.hypr(a.instance,'activeworkspace')['id']==active!=2,'Workspace changed: stop'
 def guard():
  hidden();assert process and process.poll() is None and start_ticks(process.pid)==start and Path(f'/proc/{process.pid}/exe').resolve()==BINARY
  cs=[c for c in native.hypr(a.instance,'clients') if c['pid']==process.pid];assert len(cs)==1 and cs[0]['class']=='org.ruster.editor' and cs[0]['workspace']['id']==2 and cs[0]['address']==address
  return cs[0]
 def dispatch(body):
  guard();expr=('assert(hl.get_active_workspace() and hl.get_active_workspace().id~=2); local n=0; for _,w in ipairs(hl.get_windows({class="org.ruster.editor"})) do '+f'if w.pid=={process.pid} then {body}; n=n+1 end end; assert(n==1)')
  out=subprocess.check_output(['hyprctl','-i',a.instance,'eval',expr],text=True,timeout=10);assert not any(k in out.lower() for k in ('error','warning')),out;guard()
 def peer():
  guard();assert socket_path and socket_path.is_relative_to(BASE/'tmp') and not socket_path.is_symlink()
  s=socket_path.stat();parent=socket_path.parent.stat();assert stat.S_ISSOCK(s.st_mode) and s.st_uid==parent.st_uid==os.getuid() and stat.S_IMODE(s.st_mode)==0o600 and stat.S_IMODE(parent.st_mode)==0o700
  with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as q:
   q.settimeout(2);q.connect(str(socket_path));pid,uid,gid=struct.unpack('3i',q.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
  assert pid==process.pid and uid==os.getuid()
 def tree(name):
  t=driver.call('GetTree');(CAP/'captures'/f'{name}-tree.json').write_text(json.dumps(t,indent=2,default=str)+'\n');return t
 def screenshot(name):
  dimensions,png=driver.call({'GetScreenshot':{'pixels_per_point':1.0}})['Screenshot'];(CAP/'captures'/f'{name}.png').write_bytes(bytes(png));report['actions'].append({'capture':name,'dimensions':dimensions});save()
 def action(name,act):
  guard();report['actions'].append({'action':name,'request':act,'state':'started'});save();driver.action(act,0);report['actions'][-1]['state']='done';save()
 def click(label,role=None):
  selector={'label':label};selector.update({'role':role} if role else {});value=driver.match(selector);b=value['bounds'];w=guard()['size'];assert b[0]>=0 and b[1]>=0 and b[2]<=w[0] and b[3]<=w[1],(selector,b,w)
  action('click '+label,{'op':'click','selector':selector})
 def wait_label(part,seconds=20):
  until=time.monotonic()+seconds
  while time.monotonic()<until:
   t=driver.call('GetTree');found=[n for n in nodes(t) if n[0]=='label' and part in str(n[-1].get('value',''))]
   if found:return t
   time.sleep(.1)
  raise TimeoutError('UI label not found: '+part)
 def open_source():
  click('left','button');t=tree('inspector-before-source');matches=[n for n in nodes(t) if n[0]=='button' and n[-1].get('label')=='Edit behavior source'];assert len(matches)==1
  b=matches[0][-1]['bounds'];w=guard()['size']
  if b[1]<0 or b[3]>w[1]:
   # One bounded app-scoped scroll, with its target anchored to the inspector's visible left selection header.
   visible=[n for n in nodes(t) if n[0]=='label' and n[-1].get('value')=='left' and n[-1].get('bounds',[0,0,0,0])[1]>=0];assert len(visible)==1
   pos=driver.center({'role':'label','value':'left'});driver.event([{'PointerMoved':pos},{'MouseWheel':{'unit':'Point','phase':'Move','source':'Unknown','delta':{'x':0.0,'y':-400.0},'modifiers':native.MODS}}]);tree('after-single-scroll')
  click('Edit behavior source','button')
 def source_text():
  matches=[n for n in driver.nodes() if n[0]=='multilineTextInput'];assert len(matches)==1;return matches[0][-1]['value']
 def replace_text(expected,value):
  assert source_text()==expected;action('focus source',{'op':'click','selector':{'role':'multilineTextInput'}});action('replace source',{'op':'text','value':value});assert source_text()==value
 async def launch(kind,scene=None):
  nonlocal process,start,address,driver,log,rule_installed,socket_path
  global PORT
  socket_path=None
  hidden();assert process is None or process.poll() is not None
  with socket.socket() as test:
   test.bind(('127.0.0.1',0));PORT=test.getsockname()[1]
  assert PORT not in used_ports, 'ephemeral port reused: stop without retry';used_ports.add(PORT)
  assert not any(line.split()[1].endswith(f':{PORT:04X}') and line.split()[3]=='0A' for line in Path('/proc/net/tcp').read_text().splitlines()[1:]), 'selected port acquired by another listener'
  env=dict(os.environ,RUSTER_EDITOR_STATE=str(fixture/'state/editor.json'),RUSTER_RECOVERY_DIR=str(fixture/'recovery'),TMPDIR=str(BASE/'tmp'),HOME=str(BASE/'home'),XDG_CONFIG_HOME=str(BASE/'config'),XDG_CACHE_HOME=str(BASE/'cache'),XDG_STATE_HOME=str(BASE/'xdg-state'),EGUI_INSPECTION=f'127.0.0.1:{PORT}',RUSTER_MCP_ENABLE='1')
  for k in ('RUSTER_MCP_SOCKET','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LAYER_PATH','VK_LOADER_DEBUG','LD_LIBRARY_PATH'):env.pop(k,None)
  log=(CAP/f'{kind}.log').open('xb');args=[str(BINARY)]+(['--scene',str(scene)] if scene else []);process=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env=env);start=start_ticks(process.pid);address=None
  report['processes'].append({'phase':kind,'pid':process.pid,'start_ticks':start,'args':args,'inspection_port':PORT});save()
  deadline=time.monotonic()+35
  while time.monotonic()<deadline:
   hidden();assert process.poll() is None
   found=[c for c in native.hypr(a.instance,'clients') if c['pid']==process.pid]
   if found:assert len(found)==1 and found[0]['workspace']['id']==2 and found[0]['class']=='org.ruster.editor';address=found[0]['address'];break
   await asyncio.sleep(.1)
  assert address
  dispatch('hl.dispatch(hl.dsp.window.float({action="on",window=w}))');dispatch('hl.dispatch(hl.dsp.window.resize({x=1400,y=1000,relative=false,window=w}))')
  dispatch('hl.dispatch(hl.dsp.window.tag({tag="+'+token+'",window=w}))');assert [c['pid'] for c in native.hypr(a.instance,'clients') if token in c.get('tags',[])]==[process.pid]
  if not rule_installed:
   assert CONF.read_bytes()==original_config;CONF.write_bytes(original_config+rule);rule_installed=True
   subprocess.run(['hyprctl','-i',a.instance,'reload','config-only'],check=True,stdout=subprocess.DEVNULL,timeout=15);assert subprocess.check_output(['hyprctl','-i',a.instance,'configerrors'],text=True).strip() in ('','ok')
  while time.monotonic()<deadline:
   guard();found=re.findall(r'Ruster MCP bridge: (\S+) \(private',(CAP/f'{kind}.log').read_text(errors='replace'))
   if found:assert len(found)==1;socket_path=Path(found[0]).resolve(strict=True);peer();break
   await asyncio.sleep(.1)
  assert socket_path
  driver=native.Driver(SimpleNamespace(pid=process.pid,instance=a.instance,port=PORT),fixture,CAP/'captures')
  report['processes'][-1]['window']=guard();save()
  return env
 async def connect(env,work):
  nonlocal adapter_ordinal
  adapter_ordinal+=1
  with (CAP/f'adapter-{adapter_ordinal:02}.log').open('x') as err:
   async with stdio_client(StdioServerParameters(command=str(ADAPTER),env={**env,'RUSTER_MCP_SOCKET':str(socket_path)}),errlog=err) as (rd,wr):
    async with ClientSession(rd,wr) as client:
     await asyncio.wait_for(client.initialize(),10)
     async def call(name,args=None):
      peer();r=await asyncio.wait_for(client.call_tool(name,args or {}),12);v=r.structured_content;report['mcp'].append({'tool':name,'args':args or {},'response':v,'is_error':r.is_error});save();assert v and not r.is_error and v['ok'],v;return v['result']
     return await work(call)
 async def reset(call,expected,terminal):
  accepted=await call('behavior_runtime_reset',expected);deadline=time.monotonic()+20
  while True:
   state=await call('behavior_runtime_inspect',{'operation_id':accepted['operation_id']});r=state['operation'];assert r and r['operation_id']==accepted['operation_id'] and r['run_id']==accepted['run_id']
   if r['state'] in ('failed','completed','superseded'):break
   assert time.monotonic()<deadline;await asyncio.sleep(.05)
  assert r['state']==terminal and not state['busy']
  if terminal=='failed':assert state['diagnostic']['code']=='compile' and state['diagnostic']['source_id']=='journey-source'
  else:assert state['ready'] and state['tick']=='0' and state['diagnostic'] is None
  return state
 async def close_clean():
  click('File');tree('file-menu-'+str(len(report['processes'])));click('Close window');code=await asyncio.to_thread(process.wait,20);assert code==0;report['processes'][-1]['exit']=code;log.close();driver.sock.close();save()
 try:
  env=await launch('restore')
  tree('restore-prompt');click('Restore as unsaved copy');wait_label('Recovered');assert sha(original.read_bytes())==initial_hash;tree('restored')
  async def restored(call):
   sc=await call('scene_inspect');runtime=await call('behavior_runtime_inspect');assert sc['drafts_pending'] and not runtime['playing'] and not runtime['visible'] and not runtime['ready'];return sc
  state=await connect(env,restored);assert state['session_token']!=expected['expected_session_token'];assert source_text()==DRAFT;screenshot('restored-draft');replace_text(DRAFT,GOOD);click('Apply source data','button');click('Close source (keep draft)','button')
  async def repaired(call):
   sc=await call('scene_inspect');assert not sc['drafts_pending'];ex={'expected_session_token':sc['session_token'],'expected_revision':sc['revision']};source=await call('behavior_source',{**ex,'source_id':'journey-source'});assert base64.b64decode(source['text_base64'])==GOOD.encode();await reset(call,ex,'completed');return sc
  await connect(env,repaired);tree('repaired');screenshot('repaired')
  # Real File menu and path dialog; use the explicit save button, not Enter.
  click('File');click('Save as…');t=tree('save-dialog');inputs=[n for n in nodes(t) if n[0]=='textInput' and str(n[-1].get('value','')).endswith('.json')];assert len(inputs)==1
  selector={'role':'textInput','value':inputs[0][-1]['value']};action('focus save path',{'op':'click','selector':selector});action('new sibling path',{'op':'text','value':str(sibling)});click('Save to new path','button')
  deadline=time.monotonic()+20
  while time.monotonic()<deadline:
   guard()
   if sibling.is_file() and not list((fixture/'recovery').glob('window-*/checkpoint.json')):break
   await asyncio.sleep(.1)
  assert sibling.is_file() and not list((fixture/'recovery').glob('window-*/checkpoint.json'));doc=json.loads(sibling.read_text());assert doc['format_version']==5 and doc['authoring']['sources']['journey-source']['text']==GOOD and doc['authoring']['bindings']['journey-binding']['object_id']=='left' and doc['authoring']['bindings']['journey-binding']['source_id']=='journey-source' and next(o for o in doc['scene']['objects'] if o['id']=='left')['mesh']=='pyramid' and doc['undo']
  assert sha(original.read_bytes())==initial_hash;report['saved_sibling_sha256']=sha(sibling.read_bytes());tree('saved');save();await close_clean()
  env=await launch('reopen',sibling)
  async def reopened(call):
   sc=await call('scene_inspect');assert sc['object_count']==3 and not sc['dirty'] and not sc['drafts_pending'] and str(sc['revision'])==str(doc['scene']['revision']) and next(o for o in sc['objects'] if o['id']=='left')['mesh']=='pyramid';ex={'expected_session_token':sc['session_token'],'expected_revision':sc['revision']};source=await call('behavior_source',{**ex,'source_id':'journey-source'});assert base64.b64decode(source['text_base64'])==GOOD.encode();binding=await call('behavior_inspect',{'kind':'bindings','offset':'0'});assert any(b['object_id']=='left' and b['source_id']=='journey-source' for b in binding['page']['items']);runtime=await call('behavior_runtime_inspect');assert not runtime['playing'] and not runtime['visible'] and not runtime['ready'];return sc
  await connect(env,reopened);assert sha(original.read_bytes())==initial_hash;tree('reopened');screenshot('reopened');await close_clean();report['status']='completed_pending_visual_review';save()
 except BaseException as error:report['status']='failed';report['error']=repr(error);report['traceback']=traceback.format_exc();save();raise
 finally:
  if process and process.poll() is None:report['cleanup_deferred']='owned process left for root; no additional interaction after failure'
  if rule_installed:
   try:
    current=CONF.read_bytes();assert current.count(rule)==1;CONF.write_bytes(current.replace(rule,b'',1));subprocess.run(['hyprctl','-i',a.instance,'reload','config-only'],check=True,stdout=subprocess.DEVNULL,timeout=15);assert subprocess.check_output(['hyprctl','-i',a.instance,'configerrors'],text=True,timeout=10).strip() in ('','ok');report['rule_removed']=True
   except BaseException as error:report['rule_cleanup_error']=repr(error)
  report['previous_report_unchanged']=sha((BASE/'result.json').read_bytes())==sha(previous_raw);report['config_equal']=CONF.read_bytes()==original_config;report['final_workspace']=native.hypr(a.instance,'activeworkspace')['id'];save()
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--instance');a=p.parse_args()
 if not (a.execute and a.instance):p.error('No launch: explicit root grant plus --execute and --instance required')
 asyncio.run(run(a))

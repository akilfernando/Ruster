Actual m9-eval-2 extracted-source verification,2026-11-05.
Immutable source commit/tree/archive/inventory identity: SOURCE-MANIFEST.json.
Complete extracted source RO-bound at /work/source inside private Ubuntu24.04.5 userspace. No .git metadata or synthetic Git initialization.
Full check passed176Rust/22Python tests, strictClippy/format/docs; one existingGPU-only test ignored; elapsed62.09s.
Original698file checksums verified unchanged after execution. Cached pinned toolchain/registry and target; samehostkernel, not fresh-machine/human acceptance.
Manifest/inventory exact bytes unchanged; log/command private paths replaced with explicit namedplaceholders.
No source archive/binary/cache/credentials/userstate included.

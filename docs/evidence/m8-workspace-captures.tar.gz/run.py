import os, json, subprocess, time, pathlib, hashlib
BASE=pathlib.Path('/tmp/ruster-workspace-native/final')
BASE.mkdir(parents=True,exist_ok=True)
ROOT=pathlib.Path('/home/akilf/Projects/Ruster')
INSTANCE='0aa6745f705f2c4b0a5004eb019ef76e5bbdb426_1793690289_1133262353'
CONF=pathlib.Path('/home/akilf/.config/hypr/hyprland.lua')
def hypr(command):
    return json.loads(subprocess.check_output(['hyprctl','-i',INSTANCE,'-j',command]))
assert hypr('activeworkspace')['id'] != 2
assert not any(c['class']=='org.ruster.editor' for c in hypr('clients'))
original=CONF.read_bytes()
(BASE/'hyprland-before.lua').write_bytes(original)
marker='-- BEGIN RUSTER M8 WORKSPACE NATIVE\n'
rule=marker+'''hl.window_rule({
    name = "ruster-m8-workspace-native",
    match = { class = "^org[.]ruster[.]editor$", title = "^Ruster Editor$" },
    workspace = "2 silent", no_initial_focus = true,
    float = true, size = { 1400, 1000 }, render_unfocused = true,
})
-- END RUSTER M8 WORKSPACE NATIVE
'''
assert marker.encode() not in original
CONF.write_bytes(original+b'\n'+rule.encode())
subprocess.run(['hyprctl','-i',INSTANCE,'reload'],check=True)
assert subprocess.check_output(['hyprctl','-i',INSTANCE,'configerrors']).strip() in (b'',b'ok')
env=dict(os.environ,XDG_RUNTIME_DIR='/run/user/1000',WAYLAND_DISPLAY='wayland-1',HYPRLAND_INSTANCE_SIGNATURE=INSTANCE,
 LD_LIBRARY_PATH='/home/akilf/.local/share/ruster-tools/vulkan-validation/usr/lib',
 VK_LAYER_PATH='/home/akilf/.local/share/ruster-tools/vulkan-validation/usr/share/vulkan/explicit_layer.d',
 VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='layer',
 EGUI_INSPECTION='127.0.0.1:5738',RUSTER_EDITOR_STATE=str(BASE/'state/editor.json'),PYTHONPATH='/tmp/ruster-walkthrough-python')
records=[]
for launch,stages in [('first',['blank']),('second',['resume','dirty-close'])]:
    assert hypr('activeworkspace')['id'] != 2
    log=(BASE/(launch+'.log')).open('wb')
    process=subprocess.Popen([str(ROOT/'target/debug/ruster-editor')],env=env,stdout=log,stderr=subprocess.STDOUT)
    (BASE/'current-pid').write_text(str(process.pid))
    deadline=time.monotonic()+30
    while not any(c['pid']==process.pid for c in hypr('clients')):
        assert process.poll() is None
        assert time.monotonic()<deadline
        time.sleep(.1)
    for stage in stages:
        subprocess.run(['python3',str(ROOT/'docs/evidence/M8-workspace-native.py'),stage,'--pid',str(process.pid),'--instance',INSTANCE,'--output',str(BASE),'--state',str(BASE/'state/editor.json')],env=env,check=True)
    code=process.wait(timeout=20)
    assert code==0,code
    log.close()
    records.append(dict(launch=launch,pid=process.pid,exit=code))
    subprocess.run(['python3',str(ROOT/'scripts/check_vulkan_log.py'),str(BASE/(launch+'.log'))],check=True)
current=CONF.read_bytes()
block=b'\n'+rule.encode()
assert current.count(block)==1
CONF.write_bytes(current.replace(block,b'',1))
subprocess.run(['hyprctl','-i',INSTANCE,'reload'],check=True)
assert subprocess.check_output(['hyprctl','-i',INSTANCE,'configerrors']).strip() in (b'',b'ok')
cleanup=dict(records=records,activeworkspace=hypr('activeworkspace')['id'],windows=[c for c in hypr('clients') if c['class']=='org.ruster.editor'],config_equal=CONF.read_bytes()==original,config_sha256=hashlib.sha256(CONF.read_bytes()).hexdigest())
assert not cleanup['windows']
(BASE/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
print(json.dumps(cleanup),flush=True)

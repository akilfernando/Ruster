use ruster_v4_fixture::{Object, Scene, Session};
fn main() {
    let mut scene = Scene::empty("v4-near-cap");
    scene.objects = (0..256).map(|n| Object::cube(format!("object-{n:03}"), None)).collect();
    let mut session = Session::new(scene).unwrap();
    let mut groups = 0;
    loop {
        let edits = session.scene().objects.iter().map(|o| {
            let mut transform = o.transform.clone();
            transform.translation[0] = if transform.translation[0] == 0.0 {0.001} else {0.0};
            (o.id.clone(), transform)
        }).collect::<Vec<_>>();
        if let Err(error) = session.edit_transforms(session.scene().revision, &edits) { println!("first full-group rejection after {groups}: {error}"); break; }
        groups += 1;
    }
    while session.undo_len() < 32 {
        let object = &session.scene().objects[0];
        let mut transform = object.transform.clone();
        transform.translation[0] = if transform.translation[0] == 0.0 {0.001} else {0.0};
        session.edit_transforms(session.scene().revision, &[(object.id.clone(), transform)]).unwrap();
    }
    session.undo(session.scene().revision).unwrap();
    session.save("/tmp/ruster-v4-fixture/near-cap-v4.scene.json").unwrap();
    println!("full groups={groups} undo={} redo={} revision={} bytes={}", session.undo_len(), session.redo_len(), session.scene().revision, std::fs::metadata("/tmp/ruster-v4-fixture/near-cap-v4.scene.json").unwrap().len());
}

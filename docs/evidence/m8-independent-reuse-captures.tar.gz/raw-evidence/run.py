#!/usr/bin/env python3
"""Reproduce serialized M8 independent export proof runs."""
import hashlib, json, os, pathlib, subprocess, time
ROOTS = {
    "yard": pathlib.Path("/tmp/ruster-m8-yard-independent"),
    "motion-lab": pathlib.Path("/tmp/ruster-m8-motion-independent"),
}
TARGET = pathlib.Path("/tmp/ruster-m8-independent-target")
ARTIFACTS = pathlib.Path("/tmp/ruster-m8-independent-proof")
CWD = ARTIFACTS / "cwd"
CARGO = "/home/akilf/.cargo/bin/cargo"
ENV = os.environ.copy()
ENV.update({
    "CARGO_TARGET_DIR": str(TARGET),
    "CARGO_BUILD_JOBS": "4",
    "RUSTFLAGS": "--remap-path-prefix=/tmp=/ruster-source --remap-path-prefix=/home/akilf=/ruster-build -C debuginfo=0",
    "CFLAGS": "-ffile-prefix-map=/tmp=/ruster-source -ffile-prefix-map=/home/akilf=/ruster-build",
})

def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""): h.update(b)
    return h.hexdigest()

def run(label, root, args):
    command = [CARGO, *args]
    start = time.monotonic()
    p = subprocess.run(command, cwd=CWD, env=ENV, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    elapsed = time.monotonic() - start
    out = ARTIFACTS / "logs" / f"{label}.log"
    out.write_text(p.stdout)
    row = {"label": label, "cwd": str(CWD), "root": str(root), "command": command,
           "env": {k: ENV[k] for k in ("CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "RUSTFLAGS", "CFLAGS")},
           "exit_code": p.returncode, "elapsed_seconds": elapsed, "log": str(out), "log_sha256": sha(out)}
    (ARTIFACTS / "runs.jsonl").open("a").write(json.dumps(row, sort_keys=True)+"\n")
    print(json.dumps(row, sort_keys=True))
    if p.returncode:
        print(p.stdout[-6000:])
        raise SystemExit(p.returncode)
    return p.stdout

if __name__ == "__main__":
    raise SystemExit("Use as an imported harness; run explicit stages from the assigned worker.")

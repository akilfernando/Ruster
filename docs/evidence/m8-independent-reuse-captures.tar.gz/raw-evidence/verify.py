#!/usr/bin/env python3
"""Verify the captured, non-Cargo parts of the M8 independent reuse proof."""
import hashlib, json, pathlib, subprocess, tarfile
ART=pathlib.Path('/tmp/ruster-m8-independent-proof')
EXPORTS={'yard':pathlib.Path('/tmp/ruster-m8-yard-independent'),'motion-lab':pathlib.Path('/tmp/ruster-m8-motion-independent')}
ARCHIVES={'yard':ART/'yard-modified-linux-x86_64.tar.gz','motion-lab':ART/'motion-lab-modified-linux-x86_64.tar.gz'}
EXPECT={'yard':{'archive_sha256':'7b69c70887d17b4b26a27d8f7889e398de5b0918b58b5705428fc68399a25f7e','run':'Target delivered! | tick=10 delivered=20 target=20 source=10 capacity=2'},'motion-lab':{'archive_sha256':'d2dd80fe439c54e70c3d524f884fe02f43513086240116eb7d7b6784194ed4f4','sample-slow':-1.5,'sample-fast':-1.0}}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check_archive(app):
    archive=ARCHIVES[app]; assert sha(archive)==EXPECT[app]['archive_sha256']
    dest=ART/f'{app}-verify-extract'
    assert not dest.exists(), f'remove fresh destination first: {dest}'
    dest.mkdir()
    with tarfile.open(archive,'r:gz') as tf:
        for m in tf.getmembers():
            assert (dest/m.name).resolve().is_relative_to(dest.resolve()) and not (m.issym() or m.islnk()),m.name
        tf.extractall(dest,filter='data')
    root=dest/('ruster-yard' if app=='yard' else 'ruster-motion-lab')
    manifest=json.loads((root/'manifest.json').read_text())
    assert len(manifest['files'])== (8 if app=='yard' else 9)
    for item in manifest['files']:
        assert sha(root/item['path'])==item['sha256'],item['path']
    for name in ['LICENSE-APACHE','LICENSE-MIT','THIRD_PARTY_NOTICES.txt','SUPPLEMENTAL_NOTICES.txt','LICENSE-SOURCES.json']:
        p=root/name; data=p.read_bytes(); assert len(data)>100 and b'\0' not in data[:4096]
    command=[str(root/('ruster-yard' if app=='yard' else 'ruster-motion-lab'))]
    command += ['--headless'] if app=='yard' else ['--generic-demo','--headless','--ticks','10']
    p=subprocess.run(command,cwd=ART/'cwd',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert p.returncode==0,p.stdout
    if app=='yard': assert EXPECT[app]['run'] in p.stdout,p.stdout
    else:
        scene=json.loads(p.stdout); pos={o['id']:o['transform']['translation'][0] for o in scene['runtime_scene']['objects']}
        for key in ('sample-slow','sample-fast'): assert abs(pos[key]-EXPECT[app][key])<1e-5,(key,pos[key])
    print(app,'archive/hash/license/relocation checks passed; output:',p.stdout.splitlines()[0])
for app in ('yard','motion-lab'): check_archive(app)

#!/usr/bin/env python3
"""Bounded Ubuntu native startup smoke. Execute only after explicit launch grant."""
import argparse, hashlib, json, os, signal, stat, subprocess, time, traceback
from pathlib import Path

BASE = Path('/tmp/ruster-m9-ubuntu-native')
PLAN = BASE / 'plan.json'
INSTANCE = '0aa6745f705f2c4b0a5004eb019ef76e5bbdb426_1793690289_1133262353'
PROTECTED = {717774, 771692}
CONF = Path('$USER_HOME/.config/hypr/hyprland.lua')
records = []
def record(event, **details):
    records.append(dict(event=event, time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **details))
    (BASE/'process-records.json').write_text(json.dumps(records, indent=2)+'\n')
    print(json.dumps(records[-1]), flush=True)
def ctl(*args):
    return subprocess.check_output(['hyprctl','-i',INSTANCE,*args], text=True)
def state(name):
    return json.loads(ctl('-j',name))
def active_guard(expected=None):
    active = state('activeworkspace')['id']
    if active == 2 or (expected is not None and active != expected):
        raise RuntimeError(f'active workspace changed or is 2: {active}, expected {expected}')
    return active
def parent(pid):
    try:
        return int((Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()[1])
    except (FileNotFoundError, ProcessLookupError, ValueError, IndexError):
        return None
def descends(pid, ancestor):
    seen=set()
    while pid and pid not in seen:
        if pid == ancestor: return True
        seen.add(pid); pid=parent(pid)
    return False
def protected_status(initial):
    clients=state('clients')
    result={}
    for pid, old in initial.items():
        current=[c for c in clients if c['pid']==pid]
        alive=Path('/proc',str(pid)).exists()
        preserved=all(any(c['address']==v['address'] and c['pid']==pid for c in current) for v in old)
        result[str(pid)]={'alive':alive,'initial':old,'current':current,'windows_preserved':preserved,
                          'classification': 'present' if preserved and alive else ('exited_naturally_or_unknown' if not alive else 'changed_or_missing')}
    return result
def safe_dirs(root, relative):
    node=root
    for part in Path(relative).parts:
        node=node/part
        if node.exists() or node.is_symlink():
            if node.is_symlink() or not node.is_dir(): raise RuntimeError(f'unsafe mount directory: {node}')
        else: node.mkdir(mode=0o755)
        if not node.resolve().is_relative_to(root): raise RuntimeError('mount escaped rootfs')
def exact(pid, ancestor, address=None):
    assert pid not in PROTECTED and descends(pid,ancestor), 'target is not owned descendant'
    found=[c for c in state('clients') if c['pid']==pid]
    assert len(found)==1 and found[0]['class']=='org.ruster.editor' and found[0]['workspace']['id']==2,found
    if address is not None: assert found[0]['address']==address
    return found[0]
def dispatch(pid, ancestor, address, expected, body):
    active_guard(expected); before=exact(pid,ancestor,address)
    expr=('local n=0; for _,w in ipairs(hl.get_windows({class="org.ruster.editor"})) do '
          f'if w.pid=={pid} then {body}; n=n+1 end end; assert(n==1)')
    output=ctl('eval',expr)
    if 'error' in output.lower() or 'warning' in output.lower(): raise RuntimeError(output)
    active_guard(expected)
    return before,output

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true',help='Explicitly run the granted smoke')
    args=parser.parse_args()
    if not args.execute:
        print('Prepared; no launch. Pass --execute only after root grants the run.')
        return
    plan=json.loads(PLAN.read_text()); root=Path(plan['rootfs']).resolve(strict=True)
    assert root == Path('$EVAL_BASE/rootfs')
    binary=Path(plan['binary']).resolve(strict=True)
    assert binary.is_relative_to(root) and binary.is_file()
    assert not (BASE/'process-records.json').exists() and not (BASE/'native.log').exists(), 'refuse overwriting evidence'
    active=active_guard(); clients=state('clients')
    protected={pid:[c for c in clients if c['pid']==pid] for pid in PROTECTED}
    config_hash=hashlib.sha256(CONF.read_bytes()).hexdigest()
    for name in ('smoke','run/user/1000','sys'): safe_dirs(root,name)
    placeholder=root/'run/user/1000/wayland-1'
    if placeholder.is_symlink() or (placeholder.exists() and not placeholder.is_file()):
        raise RuntimeError(f'unsafe socket mountpoint: {placeholder}')
    if not placeholder.exists(): placeholder.touch(mode=0o600)
    argv=plan['argv'].copy(); idx=argv.index('--proc')
    argv[idx:idx]=['--ro-bind','/sys','/sys']
    record('prepared', binary=str(binary), sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
           active_workspace=active, protected=protected_status(protected), config_sha256=config_hash,
           argv=argv, caveat='Startup/resize/exit only; no framebuffer, focused interaction, complete-frame or validation claim.')
    proc=None; target=None; window=None
    try:
        with (BASE/'native.log').open('xb') as log:
            proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT)
            record('spawn', bwrap_pid=proc.pid)
            deadline=time.monotonic()+35
            while time.monotonic()<deadline:
                active_guard(active)
                if proc.poll() is not None: raise RuntimeError(f'bwrap exited before window: {proc.returncode}')
                candidates=[c for c in state('clients') if c['pid'] not in PROTECTED and descends(c['pid'],proc.pid)]
                if candidates:
                    assert len(candidates)==1,candidates
                    target=candidates[0]['pid']; window=exact(target,proc.pid)
                    assert os.path.samefile(f'/proc/{target}/exe',binary), 'window executable is not built binary'
                    break
                time.sleep(.2)
            if target is None: raise TimeoutError('No owned editor window within 35 seconds')
            address=window['address']; record('window',pid=target,window=window,active_workspace=active_guard(active))
            for label,body in [('float','hl.dispatch(hl.dsp.window.float({action="on",window=w}))'),
                               ('normal','hl.dispatch(hl.dsp.window.resize({x=1400,y=1000,relative=false,window=w}))'),
                               ('small','hl.dispatch(hl.dsp.window.resize({x=960,y=640,relative=false,window=w}))'),
                               ('normal_again','hl.dispatch(hl.dsp.window.resize({x=1400,y=1000,relative=false,window=w}))')]:
                before,output=dispatch(target,proc.pid,address,active,body)
                time.sleep(.5); active_guard(active)
                record(label,before=before,after=exact(target,proc.pid,address),dispatch=output)
            dispatch(target,proc.pid,address,active,'hl.dispatch(hl.dsp.window.close({window=w}))')
            code=proc.wait(timeout=25); record('normal_exit',exit=code,pid=target)
            assert code==0
            active_guard(active)
            assert not any(c['pid']==target for c in state('clients'))
    except BaseException as error:
        record('failure',error=repr(error),traceback=traceback.format_exc())
        # Never intervene while the user is on the test workspace or moved since launch.
        try:
            active_guard(active)
            if proc is not None and proc.poll() is None:
                if target is not None and window is not None:
                    dispatch(target,proc.pid,window['address'],active,'hl.dispatch(hl.dsp.window.close({window=w}))')
                    try: record('cleanup_close_exit',exit=proc.wait(timeout=10))
                    except subprocess.TimeoutExpired: pass
                if proc.poll() is None:
                    active_guard(active)
                    # Popen is the only owned bwrap leader; die-with-parent limits the child lifetime.
                    proc.terminate()
                    try: code=proc.wait(timeout=8)
                    except subprocess.TimeoutExpired:
                        active_guard(active); proc.kill(); code=proc.wait(timeout=8)
                    record('cleanup_forced_bwrap_exit',exit=code)
        except BaseException as cleanup:
            record('cleanup_deferred_or_failed',error=repr(cleanup))
        raise
    finally:
        record('final', active_workspace=state('activeworkspace')['id'],
               protected=protected_status(protected), config_equal=hashlib.sha256(CONF.read_bytes()).hexdigest()==config_hash,
               owned_process_running=(proc is not None and proc.poll() is None))
if __name__=='__main__': main()

#!/usr/bin/env python3
"""Prepare a disposable Ubuntu editor smoke plan; NEVER launches or alters desktop state."""
import hashlib, json, os, shutil, stat
from pathlib import Path

EVAL = Path('/tmp/ruster-m9-ubuntu-eval.json')
RUN = Path('/tmp/ruster-m9-ubuntu-native')
meta = json.loads(EVAL.read_text())
root = Path(meta['base']) / 'rootfs'
source = root / 'work/source/examples/content'
binary = root / 'work/target/release/ruster-editor'
socket = Path('/run/user/1000/wayland-1')
render = Path('/dev/dri/by-path/pci-0000:00:02.0-render').resolve(strict=True)
assert render == Path('/dev/dri/renderD128') and stat.S_ISCHR(render.stat().st_mode)
assert stat.S_ISSOCK(socket.stat().st_mode)
assert root.is_dir() and source.is_dir()
assert not RUN.exists(), f'refusing to overwrite {RUN}'
(RUN/'project').mkdir(parents=True)
for name in ('scene.json', 'scene.wgsl', '.ruster-assets.json'):
    shutil.copy2(source/name, RUN/'project'/name)
shutil.copytree(source/'meshes', RUN/'project/meshes')
for name in ('home', 'config', 'cache', 'state', 'recovery', 'runtime'):
    (RUN/name).mkdir(mode=0o700)
files = {str(p.relative_to(RUN/'project')): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted((RUN/'project').rglob('*')) if p.is_file()}
args = ['bwrap', '--unshare-user', '--uid', '1000', '--gid', '1000',
        '--ro-bind', str(root), '/', '--dev', '/dev', '--dir', '/dev/dri',
        '--dev-bind', str(render), str(render), '--proc', '/proc',
        '--dir', '/run/user/1000', '--ro-bind', str(socket), '/run/user/1000/wayland-1',
        '--bind', str(RUN), '/smoke', '--clearenv', '--setenv', 'PATH', '/usr/bin:/bin',
        '--setenv', 'HOME', '/smoke/home', '--setenv', 'XDG_CONFIG_HOME', '/smoke/config',
        '--setenv', 'XDG_CACHE_HOME', '/smoke/cache', '--setenv', 'XDG_STATE_HOME', '/smoke/state',
        '--setenv', 'XDG_RUNTIME_DIR', '/run/user/1000', '--setenv', 'WAYLAND_DISPLAY', 'wayland-1',
        '--setenv', 'VK_DRIVER_FILES', '/usr/share/vulkan/icd.d/intel_icd.json',
        '--setenv', 'RUSTER_EDITOR_STATE', '/smoke/state/editor.json',
        '--setenv', 'RUSTER_RECOVERY_DIR', '/smoke/recovery', '--setenv', 'LC_ALL', 'C.UTF-8',
        '--cap-drop', 'ALL', '--chdir', '/smoke/project', '--die-with-parent',
        '/work/target/release/ruster-editor', '--scene', '/smoke/project/scene.json']
plan = {'status': 'PREPARED ONLY; NO LAUNCH GRANTED', 'rootfs': str(root),
        'binary': str(binary), 'binary_exists_at_prepare': binary.is_file(),
        'project_sha256': files, 'render_node': str(render), 'wayland_socket': str(socket),
        'argv': args, 'host_pid_namespace_shared': True,
        'validation': 'No Khronos validation layer currently in private rootfs; do not claim it.',
        'scope': 'No automatic compositor changes, process control, UI input or framebuffer capture.'}
(RUN/'plan.json').write_text(json.dumps(plan, indent=2)+'\n')
print(json.dumps(plan, indent=2))

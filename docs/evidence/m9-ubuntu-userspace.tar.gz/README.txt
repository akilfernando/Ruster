Ruster M9 Ubuntu userspace evaluation, source a083654d55df64362feefe0cabe672f909118f43.
Canonical image/source checksums and commands: evaluation-manifest.json.
Logs retain failed extraction, interrupted first check, resumed full pass, notices/release/ELF/help and native startup.
Private absolute base/toolchain/registry/user paths are replaced by named placeholders.
Native compositor records are whitelisted event/geometry/outcome summaries: no window addresses, full window state, config bytes, socket identifiers or user project contents.
Native script sources retained for reproduction; restore placeholder paths explicitly.
No rootfs, downloaded image, binary, Cargo cache, human project/state/recovery or desktop configuration is included.
This tests separate Ubuntu userspace sharing the host kernel/devices/compositor, existing read-only Rust toolchain/registry. Native run has no framebuffer/focused-input/complete-render/Khronos-validation proof. No minimum distro/fresh-machine/Windows claim.
Original local evidence retained outside repository.

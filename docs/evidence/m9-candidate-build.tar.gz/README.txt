Necessary final default editor build after CLI-help-only correction,2026-11-05. Existing warm host cache,4jobs.
Process IDs/startticks omitted; all elapsed/RSS/PSS sums preserved unchanged. Paths sanitized with documented PROJECT/TOOLCHAIN_BIN/USER_HOME placeholders.
Sampler source is evidence-only; replace placeholders and choose fresh output locations before explicit reuse.
Scope is observed process group, not guaranteed complete descendant tree or instantaneous peak. Source-head has uncommitted HELP change identified by main_rs_sha256; final candidate commit recorded separately.
Default/inspection configurations are distinct. Existing native evidence transfers for unchanged GUI code, not through source-string inference. No new test added for copy-only correction.

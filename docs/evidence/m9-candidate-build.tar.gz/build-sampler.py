import hashlib,json,os,pathlib,re,subprocess,time
root=pathlib.Path.cwd();tool=pathlib.Path('$TOOLCHAIN_BIN');env=dict(os.environ);env['PATH']=str(tool)+':'+env.get('PATH','');cmd=[str(tool/'cargo'),'build','--locked','--offline','--release','-j','4','-p','ruster-editor'];result={'command':cmd,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'main_rs_sha256':hashlib.sha256((root/'crates/ruster-editor/src/main.rs').read_bytes()).hexdigest(),'condition':'warm existing target after inspection build; necessary final default candidate build; summed process-group PSS/RSS sampled, not instantaneous or unique physical peak','samples':[]};start=time.monotonic()
with open('/tmp/ruster-m9-default-candidate-build.log','w') as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  members=[]
  for d in pathlib.Path('/proc').iterdir():
   if not d.name.isdigit():continue
   try:
    fields=(d/'stat').read_text().rsplit(')',1)[1].split()
    if int(fields[2])!=p.pid:continue
    roll=(d/'smaps_rollup').read_text();values={k:int(v) for k,v in re.findall(r'^(Rss|Pss):\s+(\d+)\s+kB$',roll,re.M)};members.append({'pid':int(d.name),'start_ticks':int(fields[19]),'rss_kib':values['Rss'],'pss_kib':values['Pss']})
   except (FileNotFoundError,ProcessLookupError,PermissionError) as error:
    continue
  result['samples'].append({'elapsed_seconds':time.monotonic()-start,'members':members,'rss_sum_kib':sum(x['rss_kib'] for x in members),'pss_sum_kib':sum(x['pss_kib'] for x in members)})
  time.sleep(.25)
 result['exit']=p.wait();result['seconds']=time.monotonic()-start
result['max_observed_rss_sum_kib']=max(x['rss_sum_kib'] for x in result['samples']);result['max_observed_pss_sum_kib']=max(x['pss_sum_kib'] for x in result['samples']);binary=root/'target/release/ruster-editor'
if result['exit']==0:
 result['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();result['binary_bytes']=binary.stat().st_size;help=subprocess.check_output([str(binary),'--help'],text=True);assert 'File → Workspace and shortcuts…' in help and 'Workspace menu' not in help;result['help_route_verified']=True
pathlib.Path('/tmp/ruster-m9-default-candidate-build.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='samples'},indent=2));print(pathlib.Path('/tmp/ruster-m9-default-candidate-build.log').read_text()[-1000:]);raise SystemExit(result['exit'])

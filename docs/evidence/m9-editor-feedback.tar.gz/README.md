# Captured feedback evidence

observations.json retains all 18 timing records and summarized receipt/predicate checks.
captures/ contains three representative PNGs and the associated before/after trees.
build/ includes the initial PATH failure and successful instrumented release build.
scripts/ contains sanitized historical controller and timing helper for review, not execution.
Populate placeholders only after reviewing current isolation, exact process ownership, protected
PIDs, paths, socket and workspace conditions. The controller imports the tracked inspection
driver named in scripts/provenance.json. Original and sanitized hashes are distinct there.
SHA256SUMS covers every archive member except itself.

#!/usr/bin/env python3
"""Isolated feedback observations; explicit --execute and root grant required."""
import argparse, asyncio, base64, copy, hashlib, importlib.util, json, os, re, shutil, socket, stat, statistics, struct, subprocess, time, traceback, uuid
from pathlib import Path
from types import SimpleNamespace

ROOT=Path('/path/to/Ruster'); BASE=Path('/path/to/disposable-feedback-run'); CONF=Path('/path/to/hyprland.lua')
HEAD='a083654d55df64362feefe0cabe672f909118f43'; FORBIDDEN=set()  # REDACTED: populate protected PIDs before any use; PORT=5752
GOOD='return { update = function(transform, props, dt, host) return transform end }\n'
BAD='return { update = function(\n'
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
native=load('ruster_guard',ROOT/'docs/evidence/M8-content-recovery-native.py')
measure=load('feedback_measure','/path/to/ruster-m9-feedback-measure.py')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def nodes(tree): return [n for _,n in tree['Tree'][2][0]]
def labels(tree,s):
 return [n for n in nodes(tree) if n[0]=='label' and s in str(n[-1].get('value','')) and visible(n[-1])]
def visible(d):
 b=d.get('bounds'); return bool(b and b[2]>b[0] and b[3]>b[1] and b[0]>=0 and b[1]>=0 and b[2]<=1400 and b[3]<=1000)
def field(tree,value):
 return [n for n in nodes(tree) if n[0]=='textInput' and n[-1].get('value')==value and visible(n[-1])]
async def main(args):
 from mcp import ClientSession,StdioServerParameters
 from mcp.client.stdio import stdio_client
 binary=args.binary.resolve(strict=True); adapter=args.adapter.resolve(strict=True)
 assert sha(binary)==args.binary_sha256 and sha(adapter)==args.adapter_sha256
 launch_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
 subprocess.run(['git','diff','--exit-code',HEAD,'--','crates','third_party','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml'],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
 assert not BASE.exists(), 'preserve previous run evidence'; BASE.mkdir(mode=0o700)
 for p in ('project','state','recovery','tmp','captures'): (BASE/p).mkdir(mode=0o700)
 for p in ('scene.json','scene.wgsl','.ruster-assets.json'): shutil.copyfile(ROOT/'examples/content'/p,BASE/'project'/p)
 shutil.copytree(ROOT/'examples/content/meshes',BASE/'project/meshes')
 initial_project={str(p.relative_to(BASE/'project')):sha(p) for p in (BASE/'project').rglob('*') if p.is_file()}
 instance=args.instance; initial_workspace=native.hypr(instance,'activeworkspace')['id']; assert initial_workspace != 2
 original=CONF.read_bytes(); clients=native.hypr(instance,'clients'); initial_inventory=[c for c in clients if c['class']=='org.ruster.editor']
 report={'status':'running','engine_source':HEAD,'launch_head':launch_head,'binary_sha256':sha(binary),'adapter_sha256':sha(adapter),'fixture_hashes':initial_project,
         'initial_inventory':initial_inventory,'initial_workspace':initial_workspace,'config_sha256':hashlib.sha256(original).hexdigest(),
         'scope':'agent-triggered instrumented release feedback on hidden workspace; includes screenshot capture, not physical input-to-photon',
         'samples':[],'trace':[]}
 def save(): (BASE/'result.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
 def start_ticks(pid): return int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19])
 def guard():
  assert native.hypr(instance,'activeworkspace')['id']==initial_workspace!=2
  assert process and process.pid not in FORBIDDEN and process.poll() is None
  assert start_ticks(process.pid)==process_start and Path(f'/proc/{process.pid}/exe').resolve()==binary
  w=[c for c in native.hypr(instance,'clients') if c['pid']==process.pid]
  assert len(w)==1 and w[0]['class']=='org.ruster.editor' and w[0]['workspace']['id']==2
  if window_address is not None: assert w[0]['address']==window_address
  return w[0]
 def peer():
  guard(); assert socket_path and socket_path.is_relative_to(BASE/'tmp') and not socket_path.is_symlink()
  st=socket_path.stat(); parent=socket_path.parent.stat()
  assert stat.S_ISSOCK(st.st_mode) and st.st_uid==parent.st_uid==os.getuid() and stat.S_IMODE(st.st_mode)==0o600 and stat.S_IMODE(parent.st_mode)==0o700
  with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
   s.settimeout(2);s.connect(str(socket_path)); pid,uid,gid=struct.unpack('3i',s.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
  assert pid==process.pid and uid==os.getuid();return {'pid':pid,'uid':uid,'gid':gid}
 process=None;process_start=None;window_address=None;socket_path=None;driver=None; log=None
 rule_installed=False; token='ruster-m9-feedback-'+uuid.uuid4().hex
 rule=('\n-- BEGIN '+token+'\n'+'hl.window_rule({name="'+token+'",match={class="^org[.]ruster[.]editor$",tag="'+token+'"},render_unfocused=true})\n'+'-- END '+token+'\n').encode()
 try:
  env=dict(os.environ,RUSTER_MCP_ENABLE='1',EGUI_INSPECTION=f'127.0.0.1:{PORT}',TMPDIR=str(BASE/'tmp'),RUSTER_EDITOR_STATE=str(BASE/'state/editor.json'),RUSTER_RECOVERY_DIR=str(BASE/'recovery'),HYPRLAND_INSTANCE_SIGNATURE=instance,XDG_RUNTIME_DIR='/run/user/<uid>',WAYLAND_DISPLAY='wayland-<socket>')
  for k in ('RUSTER_MCP_SOCKET','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LAYER_PATH','VK_LOADER_DEBUG','VK_LOADER_LAYERS_ENABLE','VK_LOADER_LAYERS_ALLOW','VK_LOADER_LAYERS_DISABLE','WGPU_DEBUG','WGPU_VALIDATION','WGPU_GPU_BASED_VALIDATION','WGPU_VALIDATION_INDIRECT_CALL','LD_LIBRARY_PATH'):env.pop(k,None)
  env.update(VK_DRIVER_FILES='/usr/share/vulkan/icd.d/nvidia_icd.json',WGPU_DEBUG='0',WGPU_VALIDATION='0',WGPU_GPU_BASED_VALIDATION='0')
  report['validation_requested']='No explicit Vulkan layers; WGPU_DEBUG=0, WGPU_VALIDATION=0, WGPU_GPU_BASED_VALIDATION=0; implicit driver layers not independently inventoried.'
  with socket.socket() as probe: probe.bind(('127.0.0.1',PORT))
  log=(BASE/'editor.log').open('xb');process=subprocess.Popen([str(binary),'--scene',str(BASE/'project/scene.json')],stdout=log,stderr=subprocess.STDOUT,env=env)
  process_start=start_ticks(process.pid);report['pid']=process.pid;report['process_start_ticks']=process_start;save(); end=time.monotonic()+35
  while time.monotonic()<end:
   assert native.hypr(instance,'activeworkspace')['id']==initial_workspace and process.poll() is None
   found=[c for c in native.hypr(instance,'clients') if c['pid']==process.pid]
   if found:
    window_address=guard()['address'];report['window_address']=window_address;save();break
   await asyncio.sleep(.1)
  else:raise TimeoutError('owned window')
  while time.monotonic()<end:
   guard(); found=re.findall(r'Ruster MCP bridge: (\S+) \(private',(BASE/'editor.log').read_text(errors='replace'))
   if found: assert len(found)==1; socket_path=Path(found[0]).resolve(strict=True); peer();break
   await asyncio.sleep(.1)
  else: raise TimeoutError('private MCP socket')
  # Object handle resolves exactly this verified process; no focus/workspace dispatch.
  for command in ('hl.dispatch(hl.dsp.window.float({action="on",window=w}))',
                  'hl.dispatch(hl.dsp.window.resize({x=1400,y=1000,relative=false,window=w}))'):
   guard()
   expr=('assert(hl.get_active_workspace() and hl.get_active_workspace().id~=2); local n=0; '
         'for _,w in ipairs(hl.get_windows({class="org.ruster.editor"})) do '
         f'if w.pid=={process.pid} then {command}; n=n+1 end end; assert(n==1)')
   answer=subprocess.check_output(['hyprctl','-i',instance,'eval',expr],text=True,timeout=10)
   assert not any(v in answer.lower() for v in ('error','warning')),answer
   guard()
  assert guard()['size']==[1400,1000]
  report['render_condition']='unique-tag render_unfocused' if args.render_unfocused else 'default compositor occlusion'
  if args.render_unfocused:
   guard();expr=('assert(hl.get_active_workspace() and hl.get_active_workspace().id~=2); local n=0; '
       'for _,w in ipairs(hl.get_windows({class="org.ruster.editor"})) do '
       f'if w.pid=={process.pid} then hl.dispatch(hl.dsp.window.tag({{tag="+{token}",window=w}})); n=n+1 end end; assert(n==1)')
   answer=subprocess.check_output(['hyprctl','-i',instance,'eval',expr],text=True,timeout=10)
   assert not any(v in answer.lower() for v in ('error','warning')),answer
   guard(); tagged=[c['pid'] for c in native.hypr(instance,'clients') if token in c.get('tags',[])]
   assert tagged==[process.pid] and CONF.read_bytes()==original and token.encode() not in original
   CONF.write_bytes(original+rule);rule_installed=True
   subprocess.run(['hyprctl','-i',instance,'reload','config-only'],check=True,stdout=subprocess.DEVNULL,timeout=15)
   assert subprocess.check_output(['hyprctl','-i',instance,'configerrors'],text=True,timeout=10).strip() in ('','ok')
   guard();report['render_rule']=rule.decode();save()
  driver=native.Driver(SimpleNamespace(pid=process.pid,instance=instance,port=PORT),BASE,BASE/'captures')
  async def tree(): return await asyncio.to_thread(driver.call,'GetTree')
  # Select uniquely identified hierarchy row; inspection sends only app-local events.
  row=driver.match({'role':'button','label':'left'}); assert visible(row)
  pos=driver.center({'role':'button','label':'left'})
  for pressed in (True,False):driver.pointer(pos,'Primary',pressed)
  initial=await tree(); (BASE/'preflight-initial-tree.json').write_text(json.dumps(initial,indent=2,default=str)+'\n')
  assert len(field(initial,'-2'))==1, 'selected X field is not uniquely visible'
  identity=field(initial,'-2')[0][-1]['children']; report['x_field_children']=identity
  def transform_pred(value):
   def check(t):
    v=field(t,value);return len(v)==1 and v[0][-1]['children']==identity
   return check
  with (BASE/'adapter.log').open('w') as adapter_log:
   async with stdio_client(StdioServerParameters(command=str(adapter),env={**env,'RUSTER_MCP_SOCKET':str(socket_path)}),errlog=adapter_log) as (rd,wr):
    async with ClientSession(rd,wr) as client:
     await asyncio.wait_for(client.initialize(),10)
     async def call(name,arguments=None):
      peer(); res=await asyncio.wait_for(client.call_tool(name,arguments or {}),12); val=res.structured_content
      report['trace'].append({'tool':name,'args':arguments or {},'response':val,'is_error':res.is_error});save()
      assert val and not res.is_error and val['ok'],val
      return val['result']
     scene=await call('scene_inspect'); assert not scene['drafts_pending'] and not scene['recovery_pending']
     obj=next(o for o in scene['objects'] if o['id']=='left'); original_transform=obj['transform']; expected={'expected_session_token':scene['session_token'],'expected_revision':scene['revision']}
     created=await call('behavior_create',{**expected,'source_id':'feedback-source','binding_id':'feedback-binding','object_id':'left','label':'Feedback behavior','language_id':'lua54','host_api_version':1,'text_base64':base64.b64encode(GOOD.encode()).decode()})
     expected['expected_revision']=created['revision']
     async def x_action(x):
      proposed=copy.deepcopy(original_transform);proposed['translation'][0]=x
      res=await call('scene_transform',{**expected,'object_id':'left','transform':proposed});assert res['changed'] and len(res['diff'])==1 and res['diff'][0]['after']==proposed
      expected['expected_revision']=res['revision'];return res
     last_runtime={}
     async def reset_action(source,terminal):
      changed=await call('behavior_source_set',{**expected,'source_id':'feedback-source','label':'Feedback behavior','language_id':'lua54','host_api_version':1,'text_base64':base64.b64encode(source.encode()).decode()})
      expected['expected_revision']=changed['revision']
      accepted=await call('behavior_runtime_reset',dict(expected));deadline=time.monotonic()+20
      while True:
       info=await call('behavior_runtime_inspect',{'operation_id':accepted['operation_id']});r=info['operation']
       assert r and r['operation_id']==accepted['operation_id'] and r['run_id']==accepted['run_id']
       if r['state'] in ('failed','completed','superseded'):break
       assert time.monotonic()<deadline;await asyncio.sleep(.05)
      assert r['state']==terminal and not info['busy'],info
      if terminal=='failed':
       d=info['diagnostic'];assert d and d['code']=='compile' and d['source_id']=='feedback-source' and 'syntax' in d['message'].lower()
       assert isinstance(info['stale'],bool) and not info['ready']
      else:assert info['ready'] and info['tick']=='0' and info['diagnostic'] is None and not info['stale']
      last_runtime.clear();last_runtime.update(info)
      return {'source':changed,'accepted':accepted,'receipt':info}
     async def settle(predicate):
      deadline=time.monotonic()+15
      while True:
       t=await tree()
       if predicate(t):return t
       assert time.monotonic()<deadline, 'specific feedback tree did not settle';await asyncio.sleep(.05)
     def error_pred(t):
      d=last_runtime.get('diagnostic'); stale=last_runtime.get('stale')
      if not d or not isinstance(stale,bool): return False
      prefix='Stale runtime' if stale else 'Runtime error'
      return len(labels(t,'Reset failed'))==1 and len(labels(t,prefix+': '+d['message']))==1
     def recovered_pred(t):
      return (last_runtime.get('diagnostic') is None and last_runtime.get('ready') is True and last_runtime.get('stale') is False
              and len(labels(t,'Runtime reset successfully'))==1 and len(labels(t,'Runtime error:'))==0 and len(labels(t,'Stale runtime:'))==0)
     # Untimed empirical preflight demonstrates both field identities and both feedback states.
     await x_action(-1.625); t=await settle(transform_pred('-1.625'));assert len(field(t,'-1.625'))==1
     await x_action(-2.0);await settle(transform_pred('-2'))
     await reset_action(BAD,'failed');err=await settle(error_pred)
     await reset_action(GOOD,'completed');ok=await settle(recovered_pred)
     for name,t in [('error',err),('recovered',ok)]: (BASE/f'preflight-{name}-tree.json').write_text(json.dumps(t,indent=2,default=str)+'\n')
     # A good reset establishes a live frame; Stop must restore authored display
     # before the transform sample (otherwise the viewport would be stale runtime).
     stopped=await call('behavior_runtime_stop',{**expected,'expected_run_id':last_runtime['run_id']})
     deadline=time.monotonic()+20
     while True:
      observed=await call('behavior_runtime_inspect',{'operation_id':stopped['operation_id']});receipt=observed['operation']
      assert receipt and receipt['operation_id']==stopped['operation_id'] and receipt['run_id']==stopped['run_id']
      if receipt['state'] in ('failed','completed','superseded'):break
      assert time.monotonic()<deadline;await asyncio.sleep(.05)
     assert receipt['state']=='completed' and not any(observed[k] for k in ('visible','ready','playing','busy'))
     last_runtime.clear();last_runtime.update(observed)
     stopped_tree=await settle(lambda t:len(labels(t,'Stopped'))==1)
     (BASE/'preflight-stopped-tree.json').write_text(json.dumps(stopped_tree,indent=2,default=str)+'\n')
     report['preflight']='passed: exact field identity, distinct receipt/tree states, Stop returned authored view';report['stop_receipt']=observed;save()
     # Each repetition starts in opposite state and includes one warmup, then five observations.
     for i in range(6):
      x=-1.625 if i%2==0 else -2.0; value='-1.625' if i%2==0 else '-2'
      sample=await measure.capture_sample(driver,BASE/'captures',f'transform-{i}',lambda x=x:x_action(x),transform_pred(value));assert sample['status']=='captured_pending_visual_review';report['samples'].append(sample);save()
     for i in range(6):
      sample=await measure.capture_sample(driver,BASE/'captures',f'error-{i}',lambda:reset_action(BAD,'failed'),error_pred);assert sample['status']=='captured_pending_visual_review';report['samples'].append(sample);save()
      sample=await measure.capture_sample(driver,BASE/'captures',f'recovery-{i}',lambda:reset_action(GOOD,'completed'),recovered_pred);assert sample['status']=='captured_pending_visual_review';report['samples'].append(sample);save()
     for kind in ('transform','error','recovery'):
      vals=[s['elapsed_ms'] for s in report['samples'] if s['label'].startswith(kind+'-') and not s['label'].endswith('-0')]
      assert len(vals)==5
      report.setdefault('summary',{})[kind]={'raw_ms':vals,'median_ms':statistics.median(vals),'max_ms':max(vals)}
     report['status']='captured_pending_visual_review';save()
 except BaseException as exc:
  report['status']='failed';report['error']=repr(exc);report['traceback']=traceback.format_exc();save();raise
 finally:
  if driver:driver.sock.close()
  if process and process.poll() is None:
   try:
    guard()
    # Dirty disposable scene: exact-owned SIGTERM, explicitly not a normal close.
    process.terminate();report['cleanup']={'method':'owned SIGTERM; dirty fixture','exit':await asyncio.to_thread(process.wait,10)}
   except BaseException as e:report['cleanup']={'method':'deferred_or_failed','error':repr(e)}
  if log:log.close()
  if rule_installed:
   try:
    current=CONF.read_bytes();assert current.count(rule)==1
    CONF.write_bytes(current.replace(rule,b'',1))
    subprocess.run(['hyprctl','-i',instance,'reload','config-only'],check=True,stdout=subprocess.DEVNULL,timeout=15)
    assert subprocess.check_output(['hyprctl','-i',instance,'configerrors'],text=True,timeout=10).strip() in ('','ok')
    report['temporary_rule_removed']=True
   except BaseException as e:report['rule_cleanup_error']=repr(e)
  report['final_active_workspace']=native.hypr(instance,'activeworkspace')['id']
  report['final_inventory']=[c for c in native.hypr(instance,'clients') if c['class']=='org.ruster.editor']
  report['config_equal']=CONF.read_bytes()==original;save()

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--render-unfocused',action='store_true');p.add_argument('--binary',type=Path);p.add_argument('--adapter',type=Path);p.add_argument('--binary-sha256');p.add_argument('--adapter-sha256');p.add_argument('--instance');a=p.parse_args()
 if not a.execute: print('Prepared only; no launch.')
 else:
  assert all((a.binary,a.adapter,a.binary_sha256,a.adapter_sha256,a.instance));asyncio.run(main(a))

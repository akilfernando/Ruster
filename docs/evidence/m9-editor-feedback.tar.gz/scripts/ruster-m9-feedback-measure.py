#!/usr/bin/env python3
"""Measurement primitive only; import into explicitly granted exact-PID session.

No launch, network, UI calls or file writes occur on import or direct execution.
Caller supplies its existing guarded Driver, async MCP action/receipt verifier,
and a predicate checking the actual inspection tree. A captured image is still
subject to independent visual verification; this helper cannot certify pixels.
"""
import asyncio
import hashlib
import json
import time
from pathlib import Path

async def capture_sample(driver, artifact, label, action, matches_tree, timeout=15):
    """Time from immediately before action() to PNG response; preserve all failures.

    action must await an MCP operation plus any required exact receipt, verify its
    semantic result, and return JSON-safe details. matches_tree inspects the full
    decoded GetTree reply for a specific expected state, not merely any tree.
    Caller must isolate/guard the same process for both protocols and authorize UI.
    """
    artifact=Path(artifact)
    assert artifact.is_dir() and artifact.resolve().is_relative_to(Path('/tmp'))
    assert label and all(c.isalnum() or c in '-_' for c in label)
    out=artifact/(label+'.json'); image_file=artifact/(label+'.png')
    assert not out.exists() and not image_file.exists()
    sample={'label':label,'clock':'time.monotonic_ns', 'status':'started',
            'interpretation':'agent action through MCP, tree polling and screenshot callback/PNG transport; not physical input-to-photon or GPU submit',
            'frame_visual_review':'pending', 'tree_checks':[]}
    def save(): out.write_text(json.dumps(sample,indent=2,default=str)+'\n')
    try:
        driver.guard()
        start=time.monotonic_ns(); sample['start_ns']=start
        sample['action_receipt']=await asyncio.wait_for(action(), timeout=timeout)
        sample['receipt_ns']=time.monotonic_ns()
        deadline=time.monotonic()+timeout
        while True:
            tree=await asyncio.to_thread(driver.call,'GetTree')
            now=time.monotonic_ns(); matches=bool(matches_tree(tree))
            sample['tree_checks'].append({'received_ns':now,'matched':matches})
            if matches: break
            if time.monotonic()>=deadline: raise TimeoutError('Expected specific UI state did not appear')
            await asyncio.sleep(.05)
        sample['matching_tree_ns']=now
        (artifact/(label+'-tree.json')).write_text(json.dumps(tree,indent=2,default=str)+'\n')
        reply=await asyncio.to_thread(driver.call,{'GetScreenshot':{'pixels_per_point':1.0}})
        end=time.monotonic_ns(); sample['end_ns']=end
        dimensions, png = reply['Screenshot']; png=bytes(png)
        assert png.startswith(b'\x89PNG\r\n\x1a\n') and len(png)>100
        image_file.write_bytes(png)
        sample.update(status='captured_pending_visual_review',dimensions=dimensions,
                      png_sha256=hashlib.sha256(png).hexdigest(),
                      elapsed_ms=(end-start)/1e6,receipt_ms=(sample['receipt_ns']-start)/1e6,
                      tree_ms=(now-start)/1e6,capture_after_tree_ms=(end-now)/1e6)
        # This further check is outside the timed interval and detects an intervening change.
        after=await asyncio.to_thread(driver.call,'GetTree')
        (artifact/(label+'-after-tree.json')).write_text(json.dumps(after,indent=2,default=str)+'\n')
        sample['post_capture_tree_matches']=bool(matches_tree(after))
        if not sample['post_capture_tree_matches']: sample['status']='invalid_state_changed_during_capture'
    except BaseException as exc:
        sample['status']='failed'; sample['error']=repr(exc); sample['failure_ns']=time.monotonic_ns()
        save(); raise
    save(); return sample

if __name__=='__main__':
    print('Measurement helper only: no launch or measurement performed.')
